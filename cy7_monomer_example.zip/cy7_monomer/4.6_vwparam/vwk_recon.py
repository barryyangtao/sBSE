import sys
import math

def read_params(fname):
    theta = []
    with open(fname, "r") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            parts = s.split()
            if len(parts) >= 2:
                theta.append(float(parts[1]))
    return theta

def basis_value(ibasis, kx, ky, kz):
    k2 = kx * kx + ky * ky + kz * kz
    if ibasis == 1:
        return math.exp(-k2 / 0.10)
    elif ibasis == 2:
        return math.exp(-k2 / 0.30)
    elif ibasis == 3:
        return math.exp(-k2 / 1.00)
    elif ibasis == 4:
        return math.exp(-k2 / 3.00)
    elif ibasis == 5:
        return (kx * kx) * math.exp(-k2 / 0.30)
    elif ibasis == 6:
        return (ky * ky) * math.exp(-k2 / 0.30)
    elif ibasis == 7:
        return (kz * kz) * math.exp(-k2 / 0.30)
    elif ibasis == 8:
        return (kx * kx) * math.exp(-k2 / 1.00)
    elif ibasis == 9:
        return (ky * ky) * math.exp(-k2 / 1.00)
    elif ibasis == 10:
        return (kz * kz) * math.exp(-k2 / 1.00)
    elif ibasis == 11:
        return (kx ** 4) * math.exp(-k2 / 1.00)
    elif ibasis == 12:
        return (ky ** 4) * math.exp(-k2 / 1.00)
    elif ibasis == 13:
        return (kz ** 4) * math.exp(-k2 / 1.00)
    elif ibasis == 14:
        return (kx * kx) * (ky * ky) * math.exp(-k2 / 1.00)
    elif ibasis == 15:
        return (kx * kx) * (kz * kz) * math.exp(-k2 / 1.00)
    elif ibasis == 16:
        return (ky * ky) * (kz * kz) * math.exp(-k2 / 1.00)
    else:
        return 0.0

def epsinv_filter(eps_in, alpha_filter=16.0):
    eps1 = eps_in - 0.5 * (eps_in - 1.0) * (1.0 + math.erf(alpha_filter * (eps_in - 1.0)))
    eps_out = eps1 - 0.5 * eps1 * (1.0 - math.erf(alpha_filter * eps1))
    return eps_out

def g_value(theta, kx, ky, kz):
    val = 0.0
    for ibasis, coeff in enumerate(theta, start=1):
        val += coeff * basis_value(ibasis, kx, ky, kz)
    return val

def vwk_model_value(theta, kx, ky, kz):
    k2 = kx * kx + ky * ky + kz * kz
    eps_raw = 1.0 + g_value(theta, kx, ky, kz)
    eps_filt = epsinv_filter(eps_raw, 16.0)
    g_filt = eps_filt - 1.0
    if k2 > 1.0e-14:
        return (4.0 * math.pi / k2) * g_filt
    else:
        return 0.0

def k_component(ii, nbase, d, scale_vh, periodic):
    pi = math.pi
    if periodic:
        nfull = nbase
        if ii <= nfull // 2 + 1:
            return 2.0 * pi * float(ii - 1) / (d * float(nbase))
        else:
            return 2.0 * pi * float(ii - nfull - 1) / (d * float(nbase))
    else:
        nfull = 2 * nbase
        if ii <= nbase:
            return pi * float(ii - 1) / (d * float(nbase))
        else:
            return pi * float(ii - nfull - 1) / (d * float(nbase))

def write_vwk(theta, nx, ny, nz, dx, dy, dz, scale_vh, out_file):
    periodic = (scale_vh == 1)
    nxh = nx * scale_vh
    nyh = ny * scale_vh
    nzh = nz * scale_vh
    idx = 0
    with open(out_file, "w") as f:
        f.write(
            f"#"
            f"{nx:12d}{ny:12d}{nz:12d}"
            f"{dx:20.16f}{dy:20.16f}{dz:20.16f}"
            f"{scale_vh:8d}   nxyz, dxyz, scale_vh\n"
        )
        # fortran ordering: i fastest, then j, then k
        for k in range(1, nzh + 1):
            kz = k_component(k, nz, dz, scale_vh, periodic)
            for j in range(1, nyh + 1):
                ky = k_component(j, ny, dy, scale_vh, periodic)
                for i in range(1, nxh + 1):
                    kx = k_component(i, nx, dx, scale_vh, periodic)
                    idx += 1
                    v = vwk_model_value(theta, kx, ky, kz)
                    f.write(f"{idx:10d} {v:24.16e}\n")
    print(f"wrote {out_file}")
    print(f"full grid written = ({nxh}, {nyh}, {nzh})")

def main():
    if len(sys.argv) != 8:
        print("usage: python3 vwk_recon.py nx ny nz dx dy dz scale_vh")
        sys.exit(1)

    param_file = "vwk_param.dat"
    nx = int(sys.argv[1])
    ny = int(sys.argv[2])
    nz = int(sys.argv[3])
    dx = float(sys.argv[4])
    dy = float(sys.argv[5])
    dz = float(sys.argv[6])
    scale_vh = int(sys.argv[7])

    if scale_vh not in (1, 2):
        raise ValueError("scale_vh must be 1 (periodic) or 2 (nonperiodic)")

    theta = read_params(param_file)
    if len(theta) != 16:
        raise ValueError(f"expected 16 parameters, found {len(theta)}")

    out_file = "vwk_recon.txt"
    write_vwk(theta, nx, ny, nz, dx, dy, dz, scale_vh, out_file)

if __name__ == "__main__":
    main()

    
