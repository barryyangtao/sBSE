import numpy as np
import sys

# check for correct number of arguments
if len(sys.argv) != 3:
    print("use: python3 vwr.py <input_file> <output_file>")
    sys.exit(1)

# command-line arguments
input_file = sys.argv[1]
output_file = sys.argv[2]

# step 1: Read and process the input file
with open(input_file, "r") as file:
    # Read and parse the header
    header = file.readline().split()
    nx, ny, nz = map(int, header[1:4])
    dx, dy, dz = map(float, header[4:7])
    n = nx * ny * nz

    # Read the data into vwk array
    vwk = np.zeros((8 * n))
    for i in range(8 * n):
        line = file.readline()
        vwk[i] = float(line.split()[1])

# reshape and perform FFT
vwk = np.reshape(vwk, (2 * nx, 2 * ny, 2 * nz), order='F')
vwr = np.fft.fftn(vwk)
vwr /= (8 * nx * ny * nz * dx**3)

# step 2: extract slices
vx = vwr[0:100, 0, 0]
vy = vwr[0, 0:100, 0]
vz = vwr[0, 0, 0:100]

# extract real parts
vx_real = np.real(vx)
vy_real = np.real(vy)
vz_real = np.real(vz)

# combine vx_real, vy_real, vz_real into a single matrix
matrix = np.column_stack((vx_real, vy_real, vz_real))

# save the matrix to the output file
np.savetxt(output_file, matrix, fmt='%.18e', delimiter=' ')

print(f"matrix saved to {output_file}")
