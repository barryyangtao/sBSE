module lda_modu
  implicit none
  save
  integer,parameter   :: ma=60000 ! DN. Note; use more points for higher acc.
  real*8, parameter   :: rhomin = 1d-12, rhomax=1d8
  logical             :: first_lda_exc=.true., flushlda=.false.
  real*8, allocatable :: logrhoa(:), vcna(:), elca(:)
  real*8              :: rm, logrm, logrmin
contains
  subroutine prep_lda_exc
    use mpi_lib_ours, only : rank
    implicit none
    integer i
    real*8, external ::   elc, n_delc_dn
    real*8           ::   r
    first_lda_exc = .false.
    call check_real_le(rhomin, rhomax, ' rmin, rmax    ')
    rm = (rhomax/rhomin)**(1d0/(ma-1d0))
    logrm = log(rm)
    logrmin  = log(rhomin)
    
    call check_le(2,ma,' two, ma  ')
    allocate(logrhoa(ma),stat=i); if(i/=0) stop ' vcn logrhoa problems '
    allocate( vcna(ma),stat=i); if(i/=0) stop ' vcn vvcna problems '
    allocate( elca(ma),stat=i); if(i/=0) stop ' vcn vvcna problems '
    
    if(rank==0.and.flushlda) open(50512,file='lda_exc.txt',status='replace')
    do i=1,ma
       logrhoa(i)   = logrmin + (i-1)*logrm
       r          = exp(logrhoa(i))
       elca(i)    =  elc(r) 
       vcna(i)    =  elca(i) + n_delc_dn(r)
       if(rank==0.and.flushlda) write(50512,"(' ',4e18.8)") r,logrhoa(i),vcna(i),elca(i)
    enddo
    if(rank==0.and.flushlda)call flush(50512) 
  end subroutine prep_lda_exc
end module lda_modu

!
! exchange-correlation energy. First: just exchange; add later correlation.
!
function ex_lda(nn, ng, dv)
  implicit none
  integer ng
  real*8 ex_lda, nn(ng), dv
  ex_lda = -0.738558766382 * sum(dv*(max(nn,1e-20))**(4.d0/3.d0))
end function ex_lda

function ex_gamma_spin(nn, ng, nsp, dv, gamma)
  implicit none
  integer ng, nsp, st
  real*8  ex_gamma_spin, nn(ng, nsp), dv, gamma
  real*8, external :: ex_gamma
  real*8, allocatable :: nn1(:)

  select case(nsp)
  case(1)
     ex_gamma_spin = ex_gamma(nn, ng, dv, gamma)
  case(2)
     allocate(nn1(ng), stat=st);     call check0(st,' nn1 ')

     nn1 = nn(:,1)*2d0
     ex_gamma_spin = 0.5d0*ex_gamma(nn1, ng, dv, gamma)

     nn1 = nn(:,2)*2d0
     ex_gamma_spin = ex_gamma_spin + 0.5d0*ex_gamma(nn1,ng,dv, gamma)

     deallocate(nn1)
  case default
     stop ' problem with nsp '
  end select
  
end function ex_gamma_spin


function ex_gamma(dens, ng, dv, gamma)
  implicit none
  integer ng, ig
  real*8 ex_gamma, ex_sum, dens(ng), dv, gamma
  real*8, external :: exg_pp
  ex_sum = 0d0
  do ig=1,ng
     ex_sum = ex_sum + exg_pp(dens(ig), gamma)*dens(ig)*dv
  enddo
  ex_gamma = ex_sum
end function ex_gamma


subroutine get_Vx(nn, ng, VX)
  implicit none

  integer ng
  real*8 nn(Ng), &
         VX(Ng)

  Vx = -0.738558766382022046 * 4.d0/3.d0* (max(nn,1e-20))**(1.d0/3.d0)

end subroutine get_Vx

module lda_x_gamma_modu
  implicit none
  save
  real*8 :: drho_sml= 1d-5
  real*8, parameter :: qcut = 3

end module lda_x_gamma_modu

real*8 function vx_gamma_old(rho, g)
  use lda_x_gamma_modu, only : del => drho_sml
  implicit none
  real*8 rho, g, rhop, rhom
  real*8, parameter :: rho_min = 1d-11
  real*8,  external :: exg_pp

  if(rho<rho_min) then
     vx_gamma_old = 0d0
     return
  endif

  rhop = rho*(1+del)
  rhom = rho*(1-del)
  vx_gamma_old = (exg_pp(rhop, g)*rhop - exg_pp(rhom, g)*rhom)/ (rhop-rhom)
end function vx_gamma_old

real*8 function vx_gamma(rho, gamma) ! roi and esti, 2007,  pccp eq. 8 -- after Savin
  implicit none
  real*8 rho, gamma, q, pi, kf
  real*8, external :: uq, exg_pp
  pi = dacos(-1d0)
  kf = (3d0*(2d0*pi)**3/8d0/pi * rho)**(1d0/3d0)
  q  = gamma/kf  
  vx_gamma = exg_pp(rho, gamma) + 1d0/3d0 * kf/(2d0*pi) * uq(q) 
  
  ! v = drho*e/drho =  (rho==r)
  !  but e= kf/2pi f(q), q==ga/kf so 
  ! v = r de/dr + e
  !  = e + r de/dkf dkf/dr = e + r de/dkf 1/3 kf/r = e + 1/3 kf de/dkf 
  !  = e + 1/3 kf d( kf/2pi f)/dkf
  !  = e + 1/3 kf (f/2pi) + 1/3 kf/2pi df/dq dq/dkf
  !  = e + 1/3 kf (f/2pi) - q/2pi df/dq 
  !  = e + 1/3 kf / (2pi) (f-q df/dq) 
  ! v = e + 1/3/2pi u

end function vx_gamma

real*8 function exg_pp(rho, gamma) ! roi and esti, 2007,  pccp eq. 8 -- after Savin
  use lda_x_gamma_modu, only : qcut
  implicit none
  real*8 rho, gamma, q, pi, kf, fq
  real*8, external :: fq_full, fq_taylor
  pi = dacos(-1d0)
  kf = (3d0*(2d0*pi)**3/8d0/pi * rho)**(1d0/3d0)
  q  = gamma/kf
  
  if(q<qcut) then
     fq = fq_full(q)
  else
     fq = fq_taylor(q)
  end if
  exg_pp = kf/2d0/pi * fq
end function exg_pp

real*8 function uq(q)
  use lda_x_gamma_modu, only : qcut
  implicit none
  real*8 q, uq_full, uq_taylor
  
  if(q<qcut) then
     uq = uq_full(q)
  else
     uq = uq_taylor(q)
  end if
end function uq

real*8 function fq_full(q)
  implicit none
  real*8 q, pi
  pi = dacos(-1d0)
  fq_full = q**2*(2*sqrt(pi)/q*erf(1d0/q) - 1d0 + (q**2d0-2d0)*(1d0-exp(-1d0/q**2)))-3d0/2d0
end function fq_full

real*8 function fq_taylor(q)
  implicit none
  real*8 q
  fq_taylor = -1d0/(6d0*q**2 )+1d0/(40d0*q**4 )-1d0/(280d0*q**6 )+&
               1d0/(2160d0*q**8 )-1d0/(18480d0*q**10 )+1d0/(174720d0*q**12 ) 
end function fq_taylor

real*8 function uq_full(q) ! = f - q df/dq
  use lda_x_gamma_modu, only : del => drho_sml
  implicit none
  real*8 q, qp, qm, fp, fm
  real*8, external :: fq_full
  
  qp = (1d0+del)*q
  qm = (1d0-del)*q

  fp = fq_full(qp)
  fm = fq_full(qm)

  uq_full = ( fp + fm )/2d0 - q * ( fp - fm )/ ( qp - qm ) 
end function uq_full

real*8 function uq_taylor(q)  ! = f - q df/dq
  implicit none
  real*8 q
  uq_taylor = -3d0/(6d0*q**2 )+5d0/(40d0*q**4 )-7d0/(280d0*q**6 )+&
               9d0/(2160d0*q**8 )-11d0/(18480d0*q**10 )+13d0/(174720d0*q**12 ) 
end function uq_taylor

real*8 function exg_pp_full_old(rho, gamma) ! roi and esti, 2007,  pccp eq. 8 -- after Savin
  implicit none
  real*8 rho, gamma, pi, kf, q
  pi = dacos(-1d0)
  kf = (3d0*(2d0*pi)**3/8d0/pi * rho)**(1d0/3d0)
  q  = gamma/kf

  exg_pp_full_old = kf/(2d0*pi)* &
       (q**2*(2*sqrt(pi)/q*erf(1d0/q) - 1d0 + (q**2d0-2d0)*(1d0-exp(-1d0/q**2))) &
       -3d0/2d0)
end function exg_pp_full_old

function ex_spin(nn, ng, nspin, dv)
  implicit none
  integer ng, nspin, st
  real*8  ex_spin, nn(ng, nspin), dv
  real*8, external :: ex_lda
  real*8, allocatable :: nn1(:)

  select case(nspin)
  case(1)
     ex_spin = ex_lda(nn, ng, dv)
  case(2)
     allocate(nn1(ng), stat=st);     call check0(st,' nn1 ')

     nn1 = nn(:,1)*2d0
     ex_spin = 0.5d0*ex_lda(nn1, ng, dv)

     nn1 = nn(:,2)*2d0
     ex_spin = ex_spin + 0.5d0*ex_lda(nn1,ng,dv)

     deallocate(nn1)
  case default
     stop ' problem with nspin '
  end select
  
end function ex_spin

subroutine get_vx_spin(nn, ng, nspin, vx)
  implicit none
  integer ng, st, nspin, is
  real*8  nn(ng, nspin), vx(ng, nspin)
  real*8, allocatable :: nn1(:)

  select case(nspin)
  case(1)
     call get_vx(nn, ng, vx)
  case(2)
     allocate(nn1(ng), stat=st)
     call check0(st,' nn1 ')
     do is=1,nspin
        nn1 = 2d0* nn(:,is)
        call get_vx(nn1, ng, vx(1,is))
     enddo
     deallocate(nn1)
  case default
     stop ' problem with nspin '
  end select
  
end subroutine get_vx_spin

subroutine get_vx_gamma_spin(nn, ng, nsp, vx, gamma)
  implicit none
  integer ng, ig, nsp, is, st
  real*8  nn(ng, nsp), vx(ng, nsp), gamma
  real*8, allocatable :: nn1(:)

  select case(nsp)
  case(1)
     call get_vx_gamma(nn, ng, vx, gamma)
  case(2)
     allocate(nn1(ng), stat=st)
     call check0(st,' nn1 ')

     do is=1,nsp
        nn1 = 2d0* nn(:,is)
        call get_vx_gamma(nn1, ng, vx(1,is), gamma)
     enddo

     deallocate(nn1)
  case default
     stop ' problem with nsp '
  end select
  
end subroutine get_vx_gamma_spin

subroutine get_vx_gamma(nn, ng, vx, gamma)
  implicit none
  integer ng, ig
  real*8  nn(ng), vx(ng), gamma
  real*8, external :: vx_gamma

  do ig=1,ng
     vx(ig) = vx_gamma(nn(ig), gamma)
  enddo
end subroutine get_vx_gamma


function eec_pwlda( nn , ng, dv) 
  implicit none
  
  integer ig, ng
  real*8 eec_pwlda, nn(Ng), dv, esum, elcf
  
  esum = 0.d0
  do ig=1, ng
     esum = esum + elcf(nn(ig))* nn(ig) * dv
  end do

  eec_pwlda = esum
end function eec_pwlda
  
function eec_spin_pwlda(nn, ng, nspin, dv)
  implicit none
  integer ng, nspin, ig
  real*8 eec_spin_pwlda, dv, esum, nn(ng, nspin), n1, n2,trm
  real*8, external :: ec_pw, eec_pwlda

  select case(nspin)
  case(1)
     eec_spin_pwlda = eec_pwlda(nn, ng, dv)
  case(2)
     esum = 0d0
     do ig=1,ng
        n1 = max(1e-20,nn(ig,1))
        n2 = max(1e-20,nn(ig,2))
        trm = ec_pw( n1,n2) * (n1+n2) * dv
        esum = esum + trm
     enddo
     eec_spin_pwlda = esum 
  case default
     stop ' nspin in eec_spin '
  end select
end function eec_spin_pwlda

subroutine get_vcn_spin(nn, ng, nspin, vc)
  implicit none
  integer ng, nspin, ig, is
  real*8 nn(ng, nspin), vc(ng, nspin), n1, n2, dn, nnn, e0, de1, de2
  real*8, external :: ec_pw

  select case(nspin)
  case(1)
     !call get_vcn(nn, ng, vc)
     do ig=1,ng
        n1 = max(1e-20,nn(ig,1)/2d0 )
        n2 = n1
        nnn = n1+n2
        e0  = ec_pw(n1,n2)
        dn = 1e-5 * nnn
        !de1 = (ec_pw(n1+dn,n2   )-e0)/dn
        de1 = (ec_pw(n1+dn/2d0,n2+dn/2d0)-e0)/dn
        vc(ig,1) = e0 + nnn*de1
     enddo
  case(2)
     do ig=1,ng
        !
        ! vc(ig,1) = d( e(n1,n2)*(nnn) )/ dn1 = e(n1,n2) + nnn*de(n1,n2)/dn1
        !
        n1 = max(1e-20,nn(ig,1))
        n2 = max(1e-20,nn(ig,2))
        nnn = n1+n2
        e0  = ec_pw(n1,n2)
        dn = 1e-5 * nnn
        de1 = (ec_pw(n1+dn,n2   )-e0)/dn
        de2 = (ec_pw(n1,   n2+dn)-e0)/dn
        vc(ig,1) = e0 + nnn*de1
        vc(ig,2) = e0 + nnn*de2
     end do
  case default
     stop ' nspin in vcn_spin '
  end select
end subroutine get_vcn_spin

subroutine get_Vcn(nn , ng, Vc)
  implicit none
  integer ng
  real*8 Vc(ng), nn(ng),  nl, vcnf
  integer ig

  do ig=1, ng
     nl = nn(ig)
     Vc(ig) = vcnf(nl) 
  end do
end subroutine get_Vcn

function vcnf(nl)
  use lda_modu, only : rhomin,rhomax, logrhoa, ma,  vcna, first_lda_exc, logrm, prep_lda_exc
  implicit none
  integer i
  real*8 nl, vcnf, a, x, lognl

  if(first_lda_exc) then
     call prep_lda_exc
  endif

  if(nl<rhomin) then
     vcnf=vcna(1)
     return
  endif

  lognl = log(nl)
  a = (lognl-logrhoa(1))/logrm 
  i = int(a)
  x = a-i

  if(i<1) then
     vcnf = vcna(1)
  else if(i>ma-1) then
     vcnf = vcna(ma)
  else 
     vcnf = x*vcna(i+1)+(1d0-x)*vcna(i)
  endif     
end function vcnf

function elcf(nl)
  use lda_modu, only : rhomin, rhomax,logrhoa,ma,  elca, first_lda_exc, logrm, prep_lda_exc
  implicit none
  integer i
  real*8 nl,elcf, a, x, lognl 

  if(first_lda_exc) then
     call prep_lda_exc
  endif

  if(nl<rhomin) then
     elcf=elca(1)
     return
  endif

  lognl = log(nl)
  a = (lognl-logrhoa(1))/logrm 
  i = int(a)
  x = a-i

  if(i<1) then
     elcf = elca(1)
  else if(i>ma-1) then
     elcf = elca(ma)
  else !if(i==1.or.i==ma-1) then
     elcf = x*elca(i+1)+(1d0-x)*elca(i)
  endif     
end function elcf

function n_delc_dn( ntot)
  implicit none
  real*8 n_delc_dn, ntot, elc
  
  real*8, parameter :: ddn = 1d-6

  if(ntot<1.d-10) then
     n_delc_dn = 0d0
     return
  end if
  
  n_delc_dn = &
              (elc( ntot *(1+ddn)) -   &
               elc( ntot *(1-ddn)))   &
               / 2.d0 / ddn

end function n_delc_dn
  
!
! Checks eLC, vs. PW 1991 (Perdew Wang 1991, PRB 13298), Table III
!
subroutine check_elc
  implicit none
  real*8 rs, pi, ntot, term, elc
  
99 write(6,*)' rs '
  read( 5,*) rs
  if(rs<0) return
  
  pi = dacos(-1.d0)
  ntot = 1.d0/ ( 4*pi*rs**3/3.d0)                      ! Jelium density
  
  term = elc(ntot)

  write(6,*)' rs, ntot ',real(rs),real(ntot),' elc(mRY) ',real(term)*(-2000)
  goto 99
end subroutine check_elc

  
function elc( ntot) 
!
! Local (spin-unpolarized) function 
!
  implicit none
  real*8 elc, ntot, ec_pw
 
  if(ntot<1.d-10) then
     elc = 0d0
     return
  end if
  elc = ec_pw(ntot/2.d0, ntot/2.d0)    ! contributions of up+ cont.of dn

end function elc

!
! Perdeow and Wang, PRB 45, p. 13244, 1992, eqs. 1,2,10
!

function ec_pw( nup, ndn)
  implicit none

  real*8 nup, ndn, rs, z, pi
  real*8 ec0, ec1, ac, fz, ec_pw, gf

  real*8, parameter :: fdd =   1.709921; 

  !
  ! Table I, pw, last 3 columns
  !
  real*8, parameter ::   &
       A0 = 0.031091,  A1 = 0.015545,  A2 = 0.016887,  &
       a10 = 0.21370,  a11 = 0.20548,  a12 = 0.11125,  &
       b10 = 7.5957,   b11 =14.1189,   b12 =10.357,    &
       b20 = 3.5876,   b21 = 6.1977,   b22 = 3.6231,   &
       b30 = 1.6382,   b31 = 3.3662,   b32 = 0.88026,  &
       b40 = 0.49294,  b41 = 0.62517,  b42 = 0.49671

  pi = dacos(-1.d0)
  
  rs = (3.d0/(4.d0*pi*(nup+ndn)))**(1.d0/3.d0)
  
  z  = (nup-ndn)/(nup+ndn)
  
  !
  !
  ! eq. 10, pw  (p=1)
  !

  ec0 = Gf(rs, A0, a10, b10, b20, b30, b40)
  ec1 = Gf(rs, A1, a11, b11, b21, b31, b41)
  ac  = Gf(rs, A2, a12, b12, b22, b32, b42)
  
  !
  ! eq. 9,8, pw
  !

  fz  = ((1d0+z)**(4.d0/3.d0) + (1d0-z)**(4.d0/3.d0) -2d0 )/  &
       ( 2**(4.d0/3.d0)-2d0)                           

  !  ec_pw  = ec0 + ac * fz / fdd *(1-z**4) + (ec1-ec0)*fz*z**4   ! pre-corrected
     ec_pw  = ec0 - ac * fz / fdd *(1-z**4) + (ec1-ec0)*fz*z**4   ! corrected
end function ec_pw
   
function Gf(rs, A, a1, b1, b2, b3, b4)   !perdew-wang 1992, eq. 10, p=1
  implicit none

  real*8 Gf, rs, A, a1, b1, b2, b3, b4, term


  term = 2*A*(b1* rs**0.5d0 + b2 * rs + b3 * rs **1.5d0 + b4 * rs**2)

  Gf  = -2d0*A*(1d0 + a1 * rs)* log(1d0 + 1.d0/term)
end function Gf

