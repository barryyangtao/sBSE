integer function integer_rand(n) ! integer from 1 to n, chosen randonmly
  implicit none
  integer  n, i
  integer, parameter :: nskip=50
  real*8   :: rv(nskip), wg
  
  call rand88_pv(rv, size(rv), 1d0)

  i = 1 +n*rv(nskip/2) !
  if(i<1) i=1
  if(i>n) i=n
  
  integer_rand = i
end function integer_rand
