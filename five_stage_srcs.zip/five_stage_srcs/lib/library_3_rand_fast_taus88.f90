MODULE Ecuyer_random_modified ! MODIFIED, DN, 2018
  ! L'Ecuyer's 1996 random number generator.
  ! Fortran version by Alan.Miller @ vic.cmis.csiro.au
  ! N.B. This version is compatible with Lahey's ELF90
  ! http://www.ozemail.com.au/~milleraj
  ! Latest revision - 30 March 1999
  
  IMPLICIT NONE
  save
  INTEGER(KIND=4), PARAMETER :: dp = SELECTED_REAL_KIND(14, 60)
  ! These are unsigned integers in the C version
  INTEGER(KIND=4) :: s1, s2, s3, s4 
CONTAINS
  
  SUBROUTINE init_seeds(i1, i2, i3, i4)
    IMPLICIT NONE
    
    INTEGER(KIND=4), INTENT(IN) :: i1, i2, i3, i4
    
    s1 = i1
    s2 = i2
    s3 = i3
    s4 = i4
  END SUBROUTINE init_seeds
  
  subroutine i_rand_fast_array_inmodule(i_a, n)
    ! Previously Generated a random number between 0 and 1. 
    ! Modified to generate list of random integers between -2^31 and 2^31
    ! Translated from C function in:
    ! Reference:
    ! L'Ecuyer, P. (1996) `Maximally equidistributed combined Tausworthe
    ! generators', Math. of Comput., 65, 203-213.
    
    IMPLICIT NONE
    integer :: n, i, i_a(n)
    INTEGER(KIND=4) :: b
    
    ! N.B. ISHFT(i,j) is a bitwise (non-circular) shift operation;
    !      to the left if j > 0, otherwise to the right.
    
    do i=1,n

       
       IF (IAND(s1,  -2) == 0) s1 = s1 - 1023
       IF (IAND(s2,  -8) == 0) s2 = s2 - 1023
       IF (IAND(s3, -16) == 0) s3 = s3 - 1023
       IF (IAND(s4,-128) == 0) s4 = s4 - 1023

       b  = ISHFT( IEOR( ISHFT(s1,6), s1), -13)
       s1 = IEOR( ISHFT( IAND(s1,-2), 18), b)
       b  = ISHFT( IEOR( ISHFT(s2,2), s2), -27)
       s2 = IEOR( ISHFT( IAND(s2,-8), 2), b)
       b  = ISHFT( IEOR( ISHFT(s3,13), s3), -21)
       s3 = IEOR( ISHFT( IAND(s3,-16), 7), b)
       b  = ISHFT( IEOR( ISHFT(s4,3), s4), -12)
       s4 = IEOR( ISHFT( IAND(s4,-128), 13), b)
       
       i_a(i)= IEOR( IEOR( IEOR(s1,s2), s3), s4)
    enddo
  end subroutine i_rand_fast_array_inmodule
  
END MODULE Ecuyer_random_modified

