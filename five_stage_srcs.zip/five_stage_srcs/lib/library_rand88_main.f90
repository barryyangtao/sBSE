module rand88_fast_module
  implicit none
  save
  logical :: called_prep_rand88 = .false.
  integer :: seed(4), seed0(4)
  integer :: rank_dep
end module rand88_fast_module

subroutine prep_rand88
  use rand88_fast_module, only : called_prep_rand88, seed
  use Ecuyer_random_modified, only : init_seeds
  implicit none
  called_prep_rand88 = .true.
  call read_seed0_fast
  call init_seeds(seed(1), seed(2), seed(3), seed(4)) ! maybe needed? not sure - DN
end subroutine prep_rand88

subroutine read_seed0_fast
  use rand88_fast_module, only : seed, seed0, rank_dep
  use simple_mpi, only : rank, bcast_i, bcast_scalar_i
  implicit none
  integer :: k, i, i15
  integer, save :: i1=1
  integer*8 :: m(4), i31
  character*10 ch

  if(i1/=1) return; i1=-1

  i31 = 2**16; i31 = i31*(2**15)
  i15 = 2**15
  !write(6,*)' i31 ',i31
  call check_le(i15,i15*i15,' i15, i30 ')

  if(.not.(i15*i15<i31))stop ' i15, i31 problems '
  call check(size(m),size(seed0),' szm, szseed0 ')

  if(rank==0) then
     open(4,file='random88.inp',status='old')! dont erase: need counter.inp too.
     !do k=1,6
     !   read(4,*)
     !enddo

     read(4,*)ch,m(:),rank_dep
     call check_lele(0,rank_dep,1,' zero-rank_dep-one ')

     if(ch/='taus88')then
        stop ' ERROR, stopping. 7th line in fort.4 should start with taus88 '
     end if

     do i=1,size(m)
        m(i) = mod(m(i),i31)
        seed0(i) = m(i)
     enddo

     close(4)
  end if

  call bcast_scalar_i(rank_dep)
  call bcast_i(seed0, size(seed0), 0)

  if(rank_dep==1) then
     m = seed0
     do i=1,size(m)
        m(i) = m(i) + 27397*i*sqrt(rank*23d0) + 84937*mod((i+rank)**2+rank**2,2289103)
        m(i) = mod(m(i),i31)
        seed0(i)=m(i)
     enddo
  end if
  seed = seed0
end subroutine read_seed0_fast
  
subroutine assign_seed(j)
  use rand88_fast_module, only : seed0, seed
  use rand88_fast_module, only : called_prep_rand88
  use Ecuyer_random_modified, only : s1, s2, s3, s4
  use simple_mpi, only : rank, bcast_i
  implicit none
  integer st, j
  integer, external :: is_it_power2
  integer*8 m(4), i31, k1, k2, k3, k4, j8

  if(.not.called_prep_rand88)call prep_rand88

  i31 = 2**16; i31 = i31*(2**15)  ! 2^31 safely
  call check(size(m),size(seed0),' szm, szseed0 ')

  s1 = seed0(1)
  s2 = seed0(2)
  s3 = seed0(3)
  s4 = seed0(4)
  
  j8=j
  k1=17287
  k2=38478
  k3=93043
  k4=45588
  
  m(1) = s1 + k1*j8            ; seed(1)=mod(m(1),i31)
  m(2) = s2 + k2*j8 + k3*j8*j8 ; seed(2)=mod(m(2),i31)
  m(3) = s3 +         k4*j8*j8 ; seed(3)=mod(m(3),i31)
  m(4) = s4 +(k3-0.4d0*k1)*j8*j8 ; seed(4)=mod(m(4),i31)

end subroutine assign_seed

subroutine rand88_i_pm1(i_vec, m)
  use rand88_fast_module, only : called_prep_rand88
  implicit none
  integer, parameter :: step=10
  integer m,st,mbig
  integer i_vec(m)
  integer, allocatable :: i_big(:,:)
  if(log(real(m))+log(real(step))>31*log(2d0)) stop  ' m*step too big '

  mbig = m*step
  allocate(i_big(step,m),stat=st)
  if(st/=0) stop ' i_vec '

  if(.not.called_prep_rand88) stop ' prep_rand88 not called ! '

  call i_rand88_fast_array(i_big, size(i_big)) ! rand88 # -2^31 to 2^31
  where(i_big(1,:)>0) 
     i_vec = 1
  elsewhere
     i_vec = -1
  end where
end subroutine rand88_i_pm1

subroutine rand88_pv(rv, m, wg) ! postive real*8 [0:1]
  use rand88_fast_module, only : called_prep_rand88
  implicit none
  integer    m, st, i
  integer, allocatable :: i_a(:)
  real*8     a, wg
  real*8    rv(m)
  if(.not.called_prep_rand88) stop ' prep_rand88 not called ! '

  allocate(i_a(m), stat=st)
  call check0(st,' i_apt ')

  a = 2d0**(-32d0)
  call i_rand88_fast_array(i_a, size(i_a)) ! rand88 # -2^31 to 2^31
  do i=1,m
     rv(i) = a*dble(i_a(i))+0.5d0   
  enddo

  !write(6,*)' i_a, wg ',minval(dble(i_a)),maxval(dble(i_a)), wg
  !write(6,*)' z   ',maxval(abs(z))
  deallocate(i_a)
end subroutine rand88_pv

subroutine rand88_rv(rv, m, wg)  ! real*8 [-1:1]
  use rand88_fast_module, only : called_prep_rand88
  implicit none
  integer    m, st, i
  integer, allocatable :: i_a(:)
  real*8     a, wg
  real*8    rv(m)
  if(.not.called_prep_rand88) stop ' prep_rand88 not called ! '

  allocate(i_a(m), stat=st)
  call check0(st,' i_apt ')

  a = 2d0**(-32d0)
  call i_rand88_fast_array(i_a, size(i_a)) ! rand88 # -2^31 to 2^31
  do i=1,m
     rv(i) = (2d0*a)*dble(i_a(i))   
  enddo

  !write(6,*)' i_a, wg ',minval(dble(i_a)),maxval(dble(i_a)), wg
  !write(6,*)' z   ',maxval(abs(z))
  deallocate(i_a)
end subroutine rand88_rv

subroutine rand88_zv(z, m, wg)
  use rand88_fast_module, only : called_prep_rand88
  implicit none
  integer    m, st, i
  integer, allocatable :: i_a(:)
  real*8     a, pi, wg
  complex*16 ci, z(m)
  if(.not.called_prep_rand88) stop ' prep_rand88 not called ! '

  allocate(i_a(m), stat=st)
  call check0(st,' i_apt ')
  !write(6,*)' m, size(i_a) ',m, size(i_a)

  a = 2d0**(-32d0)
  pi = dacos(-1d0)
  ci = dcmplx(0d0,1d0)
  call i_rand88_fast_array(i_a, size(i_a)) ! rand88 # -2^31 to 2^31
  !write(6,*)' i_a ',i_a
  do i=1,m
     z(i) = exp( ci * 2d0* pi * (dble(i_a(i))* a + 0.5d0))/sqrt(wg)  ! r\in [0,1]
  enddo
  !write(6,*)' i_a, wg ',minval(dble(i_a)),maxval(dble(i_a)), wg
  !write(6,*)' z   ',maxval(abs(z))
  deallocate(i_a)
end subroutine rand88_zv

subroutine  i_rand88_fast_array(i_a, n) ! rand88 # list, -2^31 to 2^31
  use Ecuyer_random_modified, only : i_rand_fast_array_inmodule , s1, s2, s3, s4, init_seeds
  use rand88_fast_module, only : seed
  use simple_mpi, only : rank
  implicit none
  integer  n, i_a(n)
  !write(76000+rank,*)' s1, s2, s3, rank ',s1,s2,s3,s4,rank
  !call flush(76000+rank)
  call init_seeds(seed(1), seed(2), seed(3), seed(4)) ! maybe needed? not sure - DN
  !if(rank==2) then
  !   write(6,*)' s1, s2, s3, s4, pre ',s1,s2,s3, s4
  !endif
  call i_rand_fast_array_inmodule(i_a, n)
  !if(rank==2) then
  !   write(6,*)' s1, s2, s3, s4, post ',s1,s2,s3,s4
  !endif
  seed = (/ s1, s2, s3, s4 /)
end subroutine i_rand88_fast_array

subroutine set_random88_wf_r8(u,ng,i)
  use simple_mpi, only : rank, nodes
  implicit none
  integer ng, i, ifull, nds
  real*8 u(ng)
  nds = max(nodes,1)
  ifull = rank+1+(i-1)*nds ! if nodes=10 and rank==0, ifull =1, 11, 21, ...
  call assign_seed(ifull)
  call rand88_rv(u, ng, 1d0)
end subroutine set_random88_wf_r8

subroutine set_random88_wf_c16(u,ng,i)
  use simple_mpi, only : rank, nodes
  implicit none
  integer ng, i, ifull, nds
  complex*16 u(ng)
  nds = max(nodes,1)
  ifull = rank+1+(i-1)*nds   ! if nodes=10 and rank==0, ifull =1, 11, 21, ...
  call assign_seed(ifull)
  call rand88_zv(u, ng, 1d0)
end subroutine set_random88_wf_c16

