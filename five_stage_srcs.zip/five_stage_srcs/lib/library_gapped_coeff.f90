! given havg,dL,homo,lumo and nchhb,  the output is co0(0:nchb) and nchbtop.

subroutine gapped_filter_coef_new(nchb, havg, DL, co0, nchbtop, homo, lumo)
  use mat_module, only : mat_diag
  implicit none

  integer nchb, ip, nchbtop, nplot ! nchbtop: output
  real*8  temperature, havg, dl, co0(0:nchb), homo, lumo! co is output

  integer i, j, m, N
  real*8  pi, th, x, D, dx, homo_s, lumo_s, alpha, c, toll
  real*8  gap, shift, factor, theta_l, theta_h
  real*8, allocatable :: fm(:), mat(:,:), minv(:,:), b(:), co(:), tn(:,:), vec(:,:), eig(:)
  real*8, allocatable :: fapprox(:), foriginal(:), fexact(:)
  complex*16, allocatable :: w(:), f0(:), f1(:)

  if(lumo<homo) then
    write(6,*) 'gapped_filtering_coef lumo<homo'
    write(6,*) 'homo, lumo', homo, lumo
    stop
  endif

  nplot = 100000
  factor = 1d-2
  homo_s = (homo-havg)/dl
  lumo_s = (lumo-havg)/dl
  shift = (lumo_s - homo_s)*factor
  pi = dacos(-1.d0)
  homo_s = homo_s + shift/2d0
  lumo_s = lumo_s - shift/2d0
  !if (nchb > 1000) then
  !  toll = 1d-10
  !else
  !  toll = 1d-12
  !endif
  toll = 1d-10

  write(6,*) 'toll', toll
  write(6,*) 'homo_s, lumo_s', homo_s, lumo_s
  write(6,*) 'dh, havg', dl, havg

  theta_h = acos(homo_s)
  theta_l = acos(lumo_s)
  write(6,*) 'theta_h, theta_l', theta_h, theta_l

  allocate(mat(0:nchb,0:nchb), stat=i); call check(i,0,' mat alloc  ')
  allocate(b(0:nchb), stat=i); call check(i,0,' b alloc  ')
  allocate(minv(0:nchb,0:nchb), stat=i); call check(i,0,' mat_inv alloc  ')
  allocate(vec(0:nchb,0:nchb), eig(0:nchb), stat=i); call check(i,0,' vec alloc  ')
  allocate(w(nplot),stat=i); call check(i,0,' w alloc  ')
  allocate(co(0:nchb),stat=i); call check(i,0,' co alloc  ')

  do i=0,nchb
    do j=0,nchb
      mat(i,j) = f(pi,theta_h)+f(theta_l,0d0)
    enddo
  enddo

  b(0) = pi - theta_h
  do i=1,nchb
    b(i) = -sin(i*theta_h)/i
  enddo

  write(6,*) 'sum b', sum(b)

  call mat_diag(mat,vec,eig)
  
  write(6,*)'eig(0:4)  ',real(eig(0:4))
  write(6,*)'eig(nchb-4:nchb)',real(eig(nchb-4:nchb))
  !if(minval(eig).le.0) stop ' eig problem '
  if(minval(eig).le.0) write(6,*) 'negative eigvalue present'
  write(6,*)' maxval(eig)/minval(eig)', maxval(eig)/minval(eig)

  do i=0,nchb
    if(eig(i)>toll) then
      vec(:,i) = vec(:,i)/sqrt(eig(i))
    else
      vec(:,i)= 0d0
    endif
  end do
  minv= matmul(vec,transpose(vec))
  co0=matmul(minv,b)

  maxneed : do i=nchb,10,-1
     if(abs(co0(i))>toll) exit maxneed 
  enddo maxneed
  nchbtop =i

  contains
    real*8  function f(ty,tz)
      real*8 ty,tz
      f = g(ty)-g(tz)
    end function f

    real*8 function g(t)
      real*8 t
      if(i==j.and.i==0) g = t
      if(i==j.and.i>0)  g = t/2 + sin(2*i*t)/(4*i)
      if(i.ne.j)        g = sin((i-j)*t)/(2*(i-j)) + sin((i+j)*t)/(2*(i+j))
    end function g

    subroutine make_b
      b(0) = pi - theta_h
      do i=0+1,n-1
        b(i) = -sin(i*theta_h)/i
      enddo
    end subroutine make_b
  end subroutine gapped_filter_coef_new

subroutine gapped_filter_coef_new_qp(nchb, Temperature, havg, DL, co0, nchbtop, homo, lumo)
  !quadrulple precision 
  use mat_module
  implicit none

  integer, parameter :: qp = selected_real_kind ( 33, 4931 )
  integer nchb, ip, nchbtop, nplot ! nchbtop: output
  real*8  temperature, havg, dl, co0(0:nchb), homo, lumo! co is output

  integer i, j, m, N
  real(kind=qp)  pi, th, x, D, dx,  alpha, c, toll, rcond
  real(kind=qp)  gap, shift, factor, theta_l_qp, theta_h_qp, det(2)
  real(kind=qp), allocatable :: work(:), z(:)
  integer(kind=4), allocatable :: ipvt(:)
  real(kind=qp)  :: homo_s, lumo_s, theta_l, theta_h
  real(kind=qp), allocatable :: fm(:), mat(:,:), minv(:,:), b(:), co(:), tn(:,:), vec(:,:), eig(:)
  real(kind=qp), allocatable :: fapprox(:), foriginal(:), fexact(:)
  complex*16, allocatable :: w(:), f0(:), f1(:)

  nplot = 100000
  if(lumo<homo) then
    write(6,*) 'gapped_filtering_coef lumo<homo'
    write(6,*) 'homo, lumo', homo, lumo
    stop
  endif
  factor = 1d-2
  homo_s = (homo-havg)/dl
  lumo_s = (lumo-havg)/dl
  shift = (lumo_s - homo_s)*factor
  pi = acos(-1.q0)
  homo_s = homo_s + shift/2d0
  lumo_s = lumo_s - shift/2d0
  !if (nchb > 1000) then
  !  toll = 1q-10
  !else
  !  toll = 1q-12
  !endif
    toll = 1q-10


  write(6,*) 'toll', toll
  write(6,*) 'homo_s, lumo_s', homo_s, lumo_s
  write(6,*) 'dh, havg', dl, havg

  theta_h_qp = acos(homo_s)
  theta_l_qp = acos(lumo_s)
  theta_h = theta_h_qp
  theta_l = theta_l_qp
  write(6,*) 'theta_h, theta_l', dble(theta_h_qp), dble(theta_l)

  allocate(mat(0:nchb,0:nchb), stat=i); call check(i,0,' mat alloc  ')
  allocate(minv(0:nchb,0:nchb), stat=i); call check(i,0,' mat_inv alloc  ')
  allocate(b(0:nchb), stat=i); call check(i,0,' b alloc  ')
  allocate(vec(0:nchb,0:nchb), eig(0:nchb), stat=i); call check(i,0,' vec alloc  ')
  allocate(w(nplot),stat=i); call check(i,0,' w alloc  ')
  allocate(co(0:nchb),stat=i); call check(i,0,' co alloc  ')
  allocate(ipvt(0:nchb),stat=i); call check(i,0,' tmp alloc  ')
  allocate(z(0:nchb),stat=i); call check(i,0,' tmp2 alloc  ')
  allocate(work(0:nchb),stat=i); call check(i,0,' tmp2 alloc  ')

  do i=0,nchb
    do j=0,nchb
      mat(i,j) = f(pi,theta_h_qp)+f(theta_l_qp,0q0)
    enddo
  enddo

  b(0) = pi - theta_h_qp
  do i=1,nchb
    b(i) = -sin(dble(i)*theta_h_qp)/dble(i)
  enddo

  write(6,*) 'sum b', sum(b)
  write(6,*) 'pre qpgeco'
  call qgeco(mat,nchb+1,nchb+1,ipvt,rcond,z)
  write(6,*) 'post qpgeco'
  call qgedi(mat,nchb+1,nchb+1,ipvt,det,work,01)
  write(6,*) 'post qpgedi'
  minv = mat

  co0=matmul(minv,b)

  maxneed : do i=nchb,10,-1
     if(abs(co0(i))>toll) exit maxneed 
  enddo maxneed
  nchbtop =i
contains
  real(kind=qp)  function f(ty,tz)
    real(kind=qp) ty,tz
    f = g(ty)-g(tz)
  end function f
  
  real(kind=qp) function g(t)
    real(kind=qp) t
    if(i==j.and.i==0) g = t
    if(i==j.and.i>0)  g = t/2 + sin(2*i*t)/(4*i)
    if(i.ne.j)        g = sin((i-j)*t)/(2*(i-j)) + sin((i+j)*t)/(2*(i+j))
  end function g
  
  subroutine make_b
    b(0) = pi - theta_h
    do i=0+1,n-1
       b(i) = -sin(i*theta_h)/i
    enddo
  end subroutine make_b
end subroutine gapped_filter_coef_new_qp
