subroutine set_rvec_ran_pm1(beta, ntot)
  implicit none
  integer ntot, i
  real*8  beta(ntot)
  real*8, external :: ran_pm1
  
  do i=1,ntot
     beta(i) = ran_pm1()
  enddo
end subroutine set_rvec_ran_pm1
