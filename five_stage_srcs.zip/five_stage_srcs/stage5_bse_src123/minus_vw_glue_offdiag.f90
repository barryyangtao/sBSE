! y=y_offdiag (= the part of "u=Lf" that's calculated here
! y(a,i,iq) = -sum_(j,b,:) conjg(rhoaj(:))*rhobi(:) f(b,j, offq)   ! offq=3-iq = 2,1 for iq=1,2
!
! For each iq=1,2,
!   Define g(:,i,j) = sum_b rhoib(:) f(b,j,offq),
!   Then 
!   y(a,i,iq) = -sum_j conjg(rhooaj(:)) g(:,i,j)
!
! In practice each rank does it on a "strip" of ":" on this core,
!and the results are then summed over

subroutine minus_vw_glue_offdiag(f,u,is)
  use jr
  use simple_mpi, only : rank, nodes, allsum_r4
  implicit none
  integer i, j,  st, iq, ioffq, is
  integer, save :: counter=0
  real*8 t0, t1, t2, t3

  real*8 f(nc, nv, nq)
  real*8 u(nc, nv, nq)

  real(kind=kind_gamma), allocatable :: y(:,:)
  complex(kind=kind_gamma_c), allocatable :: g(:)

  counter=counter+1

  if(nv_band==0.or.nc_band==0) return ! fixed
  
  allocate(y(nc_band, nv_band), stat=st)
  call check0(st,' y ')

  call check(ncomb1, size(rhobi1,1),' ncomb1, size ')
 
  allocate(g(ncomb1), stat=st)
  
  call cpu_time(t0)

  call check(nq,2,' nq,2 ')
  do iq=1,nq
     ioffq= 3-iq ! 1,2 --> 2,1
     y=0
     do j=1,nv_band
        do i=1,nv_band
           g(:) =  matmul(rhobi1(:,:,i,is),f(1:nc_band,j,ioffq))  ! g(:,i,j)
           y(:,i) = y(:,i) - matmul(g(:),conjg(rhobi1(:,:,j,is)))
        enddo
     enddo
     call cpu_time(t1)

     select case(kind_gamma)
     case(4);   call allsum_r4(y, size(y))
     case default; stop 'kind_gamma minus_vw_glue '
     end select
     
     u(1:nc_band,1:nv_band,iq) = &
     u(1:nc_band,1:nv_band,iq) + y(:,:)

     call cpu_time(t2)
     
     if(counter.le.1.and.rank==0) then
        write(6,*) ' minus_vw_glue timings: 1st loop,  allsum ',&
             real(t1-t0),real(t2-t1)
        call flush(6)
     endif

  enddo
     
end subroutine minus_vw_glue_offdiag
