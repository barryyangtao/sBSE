subroutine debug_diag_L(u)
  use jr
  use simple_mpi, only : rank
  use mat_module, only : mat_diag
  integer ia, jb, st
  real*8 u(nm*nv)
  real*8, allocatable :: f(:), Lm(:,:), Lv(:,:), Lw(:)
  
  call check(nm,nc,' nm, nc')
  if(nc*nv>1000) return ! only debug small systems

  allocate(f(nc*nv*nsp), Lm(nc*nv*nsp, nc*nv*nsp), Lv(nc*nv*nsp, nc*nv*nsp), Lw(nc*nv*nsp), &
       stat=st)
  call check0(st,' f Lm ')

  ia=0
  do is=1,nsp
     do ivd=1,nv
        do iad=1,nc
           ia=ia+1
           f=0
           f(ia)=1
           call Lsub(f, Lm(:,ia))
        enddo
     enddo
  end do
  
  do ia=1,nm*nv*nsp
     write(6,*)' ia, L(ia,ia) ',ia,real(Lm(ia,ia))
  enddo
  
  call mat_diag(Lm, Lv, Lw)

  do ia=1,nc*nv*nsp
     write(6,*)ia,real(Lw(ia)),real(Lw(ia)*27.2114),real(sum(u*Lv(:,ia))**2),&
                                               ' M w(au) w(eV) |<f0|M>|^2 '
  enddo
  stop ' finished eigenvalue for L '
end subroutine debug_diag_L
