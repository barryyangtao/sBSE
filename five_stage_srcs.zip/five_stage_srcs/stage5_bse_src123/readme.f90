subroutine readme
  implicit none
end subroutine readme

! Here we put comments on the program.
!
! There's an inherent indexing issue for charged and/or triplet systems.
! Example: naphtalene(nocc_neutral=24).
!     Consider naph^--, triplet.
!     Then chargeU=-2,  chargeD = 0
!     Say i input nv=10, nc=20.  This means for neutral
!     that i input to the program to consider states 15:24 (occupied), 25:44 virtual
!
!     But in naph-- states 26,25 are occupied(up) and unocc(down).
!
!     So we'll define nv=10+2=12,  nc=20
!     for v states: States 1,2,3,...,12, is=1 will be 26,25,24,...,15
!                   States     3,...,12  is=2 will be       24,...,15
!                   States 1,2 for is=2  will have i_participate=0,
!                   those states will be zeroed out
!  
!     Anagolously for the nc states.
!
! src115: fix weights in cheby.f90
