subroutine minus_vw_diag_exband(f,u,is)
  use jr
  use simple_mpi, only : rank, nodes, allsum_r4
  implicit none
  integer is, iq, iv, ic
  real*8 f(nc, nv, nq), u(nc, nv, nq)

  ! diagonal exchange minused for states outside the band

  do iq=1,nq
     do iv=1,nv
        do ic=1,nc
           if(ic>nc_band.or.iv>nv_band) then
              u(ic, iv, iq) = u(ic, iv, iq) - vw_diag(ic,iv,is)*f(ic,iv, iq)
           end if
        end do
     end do
  end do
end subroutine minus_vw_diag_exband
