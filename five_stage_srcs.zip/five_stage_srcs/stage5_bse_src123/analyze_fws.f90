subroutine analyze_fws
  use jr
  use simple_mpi, only : rank, nodes, bcast_r8
  implicit none
  integer nds, i, st
  real*8 fLf, ff
  real*8, allocatable :: f(:,:,:,:), u(:,:,:,:)

  if(nsp/=1) stop ' analyze_fws only for nsp=1 for now '
  
  allocate(f(nc,nv,nq,nsp), stat=st)
  call check0(st,' f-analz ')
  
  allocate(u(nc,nv,nq,nsp), stat=st)
  call check0(st,' u-analz ')
  
  nds=max(nodes,1)

  do i=1,nw_anlz
     if(rank==0) then
        write(6,*)' shape(f)   ',shape(f)
        write(6,*)' shape(fws) ',shape(fws)
        call flush(6)
        f=fws(:,:,:,:,i)
     end if
     call bcast_r8(f,size(f),0)
     call Lsub_b(f,u)
     fLf = sum(u*f)
     ff = sum(f*f)
     if(rank==0) then
        write(6,*)real(Har*w_anlz(i)), real(Har*fLf/ff), real(Har*(fLf/ff-w_anlz(i))),real(ff), &
          ' w, <fLf>/<ff>, diff, <f|f> '
        call flush(6)
     endif
  end do
end subroutine analyze_fws
