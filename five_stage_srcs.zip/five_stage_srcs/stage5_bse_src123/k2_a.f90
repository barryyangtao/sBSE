subroutine make_k2_a
  use jr
  implicit none
  integer ix,iy,iz, ik, st
  integer mx,my,mz
  real*8  pi
  real*8  dkx, dky, dkz
  real*8  kx,   ky,  kz
  
  pi = dacos(-1d0)
  
  allocate(k2_a(nk), stat=st) ! k2_a(n) or k2_a(8n)
  call check0(st,' k2_a')
  
  mx = nx*scale_vh
  my = ny*scale_vh
  mz = nz*scale_vh
  
  dkx = 2*pi/(mx*dx)
  dky = 2*pi/(my*dy)
  dkz = 2*pi/(mz*dz)
  
  ik=0
  do iz=1,mz
     do iy=1,my
        do ix=1,mx
           
           ik=ik+1
           
           kx = dble(ix-1)* dkx
           ky = dble(iy-1)* dky
           kz = dble(iz-1)* dkz
           
           if(kx>pi/dx) kx = kx-2d0*pi/dx  
           if(ky>pi/dy) ky = ky-2d0*pi/dy
           if(kz>pi/dz) kz = kz-2d0*pi/dz
           
           k2_a(ik) = kx**2+ky**2+kz**2
        enddo
     enddo
  enddo
end subroutine make_k2_a
