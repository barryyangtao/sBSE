subroutine W_map
  use jr
  implicit none
  integer ib, jb, i, j, st
  integer, allocatable :: Wmap(:,:)
  if(nv.le.nv_D) then ! usual deterministic case
     if(nv<nv_D.and.SR_beta) stop ' not built for SR_beta=.true'
     call W_map_detonly
  else
     call W_map_det_and_stoch
  endif
  
contains
  subroutine W_map_detonly
    integer shft

    if(nbe_D==0) return
    allocate(Wmap(nv,nv), Windx(2,nbe_D),stat=st)
    call check0(st,' Wmap ')

    shft = nv_D -nv    

    Wmap = 0
    do ib=1,nbe_D
       call find_indx(ib,b1b_D(shft+1:shft+nv,ib),i)
       call find_indx(ib,b2b_D(shft+1:shft+nv,ib),j)
       if(Wmap(i,j)/=0) stop ' Wmap preppupulated '
       if(Wmap(j,i)/=0) stop ' Wmap preppupulated '
       Wmap(i,j) = ib
       Wmap(j,i) = ib
       Windx(:,ib) = (/ i, j /)
    enddo
    
    do ib=1,nbe_D
       i= Windx(1,ib)
       j= Windx(2,ib)
       Wbe_D(:,:,ib) = Wbe_D(:,:,ib)*b1b_D(shft+i,ib)*b2b_D(shft+j,ib) 
       if(abs(b1b_D(shft+i,ib)-1)>1d-4) stop ' b1b_D '
       if(abs(b2b_D(shft+j,ib)-1)>1d-4) stop ' b2b_D '
       ! reverse signs.  check later DN
    end do
    
    b1b_D = abs(b1b_D)
    b2b_D = abs(b2b_D)
    if(any(Wmap==0)) stop ' Wmap not set properly '
    call check_lelele(1,minval(Windx),maxval(Windx),nv,' 1-minWindx-maxWindx-nv ')

  end subroutine W_map_detonly

  subroutine W_map_det_and_stoch
    allocate(Wmap(nv_D,nv_D), Windx(2,nbe_D),stat=st)
    call check0(st,' Wmap ')
    call check(nbe_D, (nv_D*(nv_D+1))/2, ' nbe_D nvD*nvDp1/2 ')
    Wmap = 0
    do ib=1,nbe_D
       call find_indx_2(ib,b1b_D(1:nv_D,ib),i)
       call find_indx_2(ib,b2b_D(1:nv_D,ib),j)
       if(Wmap(i,j)/=0) stop ' Wmap preppupulated '
       if(Wmap(j,i)/=0) stop ' Wmap preppupulated '
       Wmap(i,j) = ib
       Wmap(j,i) = ib
       Windx(:,ib) = (/ i, j /)
    enddo
    
    do ib=1,nbe_D
       i= Windx(1,ib)
       j= Windx(2,ib)
       Wbe_D(:,:,ib) = Wbe_D(:,:,ib)*b1b_D(i,ib)*b2b_D(j,ib) ! reverse signs.  check later DN
    end do
    if(any(Wmap==0)) stop ' Wmap not set properly '

    b1b_D = abs(b1b_D)
    b2b_D = abs(b2b_D)
    
    ! now change Windx, since nv_D may be smaller than nv
    Windx = Windx + nv-nv_D ! nv=30, nv_D=10; the 1:10 states in Windx really refer to 21:30
  end subroutine W_map_det_and_stoch

  subroutine find_indx(ib, b, i)
    implicit none
    integer i, ib,  m
    real*4 b(nv)

    m = sum(abs(nint(b)))
    if(m/=1) stop ' beta isnt determinisitc '

    m = maxval(abs(nint(b)))
    if(m/=1) stop ' beta isnt deterministic p2 '

    i = product(maxloc(abs(nint(b))))

    m = abs(b(i))
    if(m/=1) stop ' beta isnt deterministic p3 '

  end subroutine find_indx

  subroutine find_indx_2(ib, b, i)
    implicit none
    integer i, ib,  m
    real*4 b(1:nv_D)

    m = sum(abs(nint(b)))
    if(m/=1) stop ' f2: beta isnt determinisitc '

    m = maxval(abs(nint(b)))
    if(m/=1) stop ' f2: beta isnt deterministic p2 '

    i = product(maxloc(abs(nint(b))))
    call check_lele(1+nv_D-nv,i,nv_D,' 1+nvD-nv,i,nvD ')
    
    m = abs(b(i))
    if(m/=1) stop ' f2: beta isnt deterministic p3 '

  end subroutine find_indx_2

  
end subroutine W_map
