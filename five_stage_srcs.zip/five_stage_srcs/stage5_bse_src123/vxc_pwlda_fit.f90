module vxc_fit_modu
  implicit none
  save
  integer, parameter :: nfit=3000
  real*8,  parameter :: dens_min=1d-8, dens_max = 1d3
  real*8, allocatable :: dens_g(:), vxc_g(:)
  real*8  :: dns_log_step, dens_min_log, inv_dns_log_step, dns_log
contains
  subroutine vxc_fit_prep
    use simple_mpi, only : rank
    implicit none
    integer st, i
    integer, save :: i1=1
    real*8 dens1

    if(i1/=1) return
    i1=-1
    
    allocate(dens_g(nfit), vxc_g(nfit), stat=st)
    call check(st,0,' st 0 vxc_fit_prep ')

    dns_log_step = (log(dens_max)-log(dens_min))/dble(nfit-1)
    inv_dns_log_step = 1d0/dns_log_step
    dens_min_log = log(dens_min)
    
    do i=1,nfit
       dns_log = dens_min_log+dble(i-1)*dns_log_step
       dens_g(i) = exp(dns_log)
       call vxc_spin_pwlda(dens_g(i), vxc_g(i), 1, 1) ! n=1,nspin=1
       write(30000,*)i,dens_g(i),vxc_g(i)  ! erase
    enddo
    if(rank==0) then
       write(6,*)' minval maxval dens_g ',minval(dens_g),maxval(dens_g)
       write(6,*)' minval maxval  vxc_g ',minval( vxc_g),maxval( vxc_g)
    endif
  end subroutine vxc_fit_prep
    
  subroutine vxc_fit(dens1, vxc1)
    implicit none
    integer i
    real*8 dens1, vxc1, dens1_log, a, da
    dens1_log = log(dens1)

    a = 1+ (dens1_log-dens_min_log)*inv_dns_log_step

    i = a
    da = a-i
    i=max(1,min(i,nfit-1))
    vxc1= vxc_g(i+1)*da + vxc_g(i)*(1d0-da)

  end subroutine vxc_fit
end module vxc_fit_modu
  
subroutine vxc_spin_pwlda_fit(dens, vxc, n, nspin)
  use vxc_fit_modu
  use simple_mpi, only : rank, sync_mpi
  implicit none
  integer :: n, nspin, i
  integer,save :: i1=1
  integer, parameter :: ifit=1 ! 0 or 1
  real*8 dens(n, nspin), vxc(n, nspin)
  
  if(nspin==2.or.ifit/=1) then
     call vxc_spin_pwlda(dens, vxc, n, nspin)
     return
  end if

  call check(nspin,1,' nspin-1 ')

  if(i1==1) then
     i1=-1
     call vxc_fit_prep
  endif

  call flush(6)
  call sync_mpi
  if(minval(dens).le.0) then 
     write(6,*)' rank,minval(dens),maxval(dens) ',rank,minval(dens),maxval(dens)
     stop
  endif
  call sync_mpi
    
  do i=1,n
     call vxc_fit(dens(i,1), vxc(i,1))
  enddo
end subroutine vxc_spin_pwlda_fit
