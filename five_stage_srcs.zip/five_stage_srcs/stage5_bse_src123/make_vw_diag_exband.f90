subroutine make_vw_diag
  use jr
  use simple_mpi, only : rank, nodes, scatter_r8, gather_r8, allsum_r8
  implicit none
  integer ic, iv, is, st, nv_loc, nds
  integer nxb,nyb,nzb
  real*8, allocatable :: dns(:), dnsb(:), pv_loc(:,:), vv_loc(:,:), vv1(:,:)
  complex*16, allocatable :: uk(:)
  nxb=nx*scale_vh
  nyb=ny*scale_vh
  nzb=nz*scale_vh

  nds = max(nodes,1)
  call alloc_vw_diag
  call make_nv_loc
  
  call check(nk,n*scale_vh**3,' nk,n*scale_vh**3 ')
  
  allocate(dns(n), dnsb(nk), uk(nk), vv_loc(n,nv_loc), vv1(n1,nv), stat=st) ;
  call check0(st,' dns_dnsb_uk ')

  allocate(pv_loc(n,nv_loc), stat=st)
  call check0(st,' pv_loc ')
  
  do is=1,nsp
     call gather_pv_loc
     do iv=1,nv_loc
        dns = pv_loc(:,iv)**2
        call dns_to_vwdns(vv_loc(:,iv))
     enddo
     call scatter_vv_loc
     call dot_vv
  end do
     
  call allsum_r8(vw_diag,size(vw_diag))
        
contains
  subroutine alloc_vw_diag
    allocate(vw_diag(nc, nv, nsp), stat=st)
    call check0(st,' vw_diag ')
  end subroutine alloc_vw_diag
  
  subroutine gather_pv_loc
    integer i, j, jr
    real*8, allocatable :: p(:)

    allocate(p(nn), stat=st)
    call check0(st,' gather_pv_loc ')
    
    i=0
    do j=1,nv 
       jr = mod(j-1,nds)
       call gather_r8(pv1(:,is,j), p, n1, jr)
       if(rank==jr) then
          i=i+1
          pv_loc(:,i) = p(1:n)
       endif
    end do
    
    call time_print('  rhobi post-gather ')
  end subroutine gather_pv_loc

  subroutine dns_to_vwdns(vdns)
    implicit none
    real*8 vdns(n)
    call broaden_dns_to_dnsb ! puts dns on bigger grid
    call fft_dnsb_to_uk
    call uk_times_vwktot
    call fft_uk_back
    call check_real(uk,size(uk))
    call narrow_c_to_v(uk,vdns)
  end subroutine dns_to_vwdns
  
  subroutine fft_dnsb_to_uk
    uk = dnsb
    call fft3d_forward(nxb, nyb, nzb, uk, uk)
  end subroutine fft_dnsb_to_uk

  subroutine fft_uk_back
    call fft3d_backward(nxb, nyb, nzb, uk, uk)
  end subroutine fft_uk_back
  
  subroutine uk_times_vwktot
    call check(size(uk), size(vwktot),' size_u_vwktot ')
    !    uk = uk * sign(sqrt(abs(vwktot(:))),vwktot(:))*  sqrt(dv/dble(nk))
    uk = uk* vwktot/nk
  end subroutine uk_times_vwktot

  subroutine broaden_dns_to_dnsb
    if(mod(nx ,2)/=0.or.mod(ny ,2)/=0.or.mod(nz ,2)/=0) stop ' make nx ,ny ,nz  all even '

    select case(scale_vh)
    case(2); call dns_to_dnsb(dns,dnsb)
    case(1); dnsb= dns
    case default; stop 'scale_vh problem '
    end select
  end subroutine broaden_dns_to_dnsb

  subroutine dns_to_dnsb(dns,dnsb)
    implicit none
    real*8  dns( nx, ny, nz)
    real*8  dnsb(nx*2,ny*2,nz*2)
    integer mx,my,mz,px,py,pz
    call check(scale_vh, 2, 'scale_vh vs. 2 ')

    dnsb = 0d0
    
    mx= 1 + nx - nx/2
    px=     nx + nx/2

    my= 1 + ny - ny/2
    py=     ny + ny/2

    mz= 1 + nz - nz/2
    pz=     nz + nz/2

    dnsb(mx:px,my:py,mz:pz) = dns
  end subroutine dns_to_dnsb

  subroutine  narrow_c_to_v(c,v)
    implicit none
    integer mx, my, mz
    integer px, py, pz
    complex*16 c(nxb, nyb, nzb)
    real*8     v(nx,    ny,    nz)
    nxb=nx*scale_vh
    nyb=ny*scale_vh
    nzb=nz*scale_vh

    if(scale_vh==1) then
       v = c
       return
    endif

    call check(scale_vh,2,' scale_vh vs two ')
    
    mx= 1 + nx - nx/2
    px=     nx + nx/2
    
    my= 1 + ny - ny/2
    py=     ny + ny/2  
    
    mz= 1 + nz - nz/2
    pz=     nz + nz/2
    
    v = c(mx:px,my:py,mz:pz)
  end subroutine narrow_c_to_v

  subroutine scatter_vv_loc
    integer i, j, jr
    real*8, allocatable :: pp(:)
    
    allocate(pp(nn), stat=st)
    call check0(st,' gather_pv_loc ')
    
    pp = 0
    i=0
    do j=1,nv 
       jr = mod(j-1,nds)
       if(rank==jr) then
          i=i+1
          pp(1:n) = vv_loc(:,i)
       end if
       
       call scatter_r8(pp, vv1(:,j), n1, jr)
    end do

  end subroutine scatter_vv_loc

  subroutine dot_vv
    vw_diag(:,:,is) = matmul(transpose(pc1(:,is,:)**2),vv1(:,:))*dv
  end subroutine dot_vv

  subroutine make_nv_loc
    integer i, j, jr
    i=0
    do j=1,nv
       jr=mod(j-1,nds)
       if(rank==jr)i=i+1
    enddo
    nv_loc = i
  end subroutine make_nv_loc

end subroutine make_vw_diag
