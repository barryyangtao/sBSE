module jr
  implicit none
  save
  real*8, parameter :: Har = 27.211396
  integer, parameter :: kind_gamma=4
  integer, parameter :: kind_gamma_c = kind_gamma
  ! complex(kind=4) is the same as complex*8
  ! complex(kind=8) is the same as complex*16
  
  logical, parameter :: exciton_txt_printing = .true.  ! DN 04/19/2024
  logical, parameter :: read_nvkeep = .false.
  logical, parameter :: hermiticize_eta = .false.
  real*8, parameter :: big = 1d10
  !logical :: diag_remove = .false. ! .true.
  logical :: tddft_flg
  integer iad, ivd ! debug, erase

  character*30, parameter :: functional='lda'
  character*30 vwtype
  character*30 wfsrc ! wf or wfhybrid, for reading from wf.bin or wfhybrid.bin
  character*30 offdiag ! TDA (TammDancoff), vw, or Wvw(later)
  character*30 action_rhoij
  character*30, parameter :: scratch_dir='rho_storage' ! doesnt have to exist, will be made.
                             ! doesnt need to be common, could be a different one for each core
  
  !logical compare
  logical :: flg_rhoij
  logical :: flg_gamma
  logical :: use_vwk_fit = .true.
  logical :: mixrep
  logical :: periodic
  logical :: bin_out = .true.
  logical :: det_beta
  logical :: stoch_beta
  logical :: SR_beta
  logical :: using_beta
  logical :: wf_sprt ! separate reading of ocucpied
  logical :: vw_stoch
  logical :: simple_cheby
  logical :: igv_igc_sampling_fixed
  logical :: alpha_compression
  logical :: flg_band
  
  integer nq ! 2 for full L, 1 for tamm dancoff.
  integer nx, ny, nz,  nw_anlz
  integer n1, nn, n
  integer nk1, nnk, nk, n8
  integer nm ! nc for basis, n/nds=ngrd/nds for grid.
  integer nv, nc, mc, nsp, nvextra, ncextra, ivbot, ivtop,icbot,ictop
  integer nv_band, nc_band
  integer nv_vw, nij, nab
  integer nv_D, nv_stoch, nv_SR
  integer nvkeep_D, nvkeep_SR !, nvkeep_stoch
  integer nvs, ncs, ncs_i ! sampled nv, nc, nc per node
  integer nws,nwstot,iwskip,iws_start
  ! sampled frequencies for f(b,j,wsampled)
  integer nw, ncheby, ncheby_max, icheby
  integer scale_vh
  integer nbe_D,     nbemax_D
  integer nbe_stoch, nbemax_stoch
  integer nbe_SR,    nbemax_SR
  !integer neta
  integer nk_low ! number of low-kterms in nvw
  integer nk_high ! number of high-kterms in nvw
  integer ngam_vw ! number of gamma terms in vw
  integer ngam_vw_core ! ngam_vw per core
  integer ngam_smpl ! number of gamma sampling
  integer nalpha !# of stochastic compression vec
  integer ncomb, ncomb1,nncomb ! ncomb=nk_low+nalpha; ncomb1=ncomb/nds (+1); nncomb = ncomb1*nds
  integer l_alpha ! length of each alpha-vector
  integer ipol !1 for x, 2 for y, 3 for z

  integer, allocatable :: nocc_a(:)
  integer, allocatable :: imapvw(:), jmapvw(:)
  integer, allocatable :: imap(:), jmap(:), ijmap(:,:)
  integer, allocatable :: amap(:), bmap(:), abmap(:,:)
  integer, allocatable :: icoef_eta(:,:)
  integer, allocatable :: map_vwklow(:)
  integer, allocatable :: map_vwkhigh(:)

  integer, allocatable :: i_participate(:,:) ! 1 for real states, 0 for non-real, see readme.f90

  integer, allocatable :: alpha(:,:) ! compression
  integer, allocatable :: istart(:)
  integer, allocatable :: Windx(:,:)
  integer, allocatable :: mapiws(:)

  integer, allocatable :: g1vw(:,:)
  integer, allocatable :: g2vw(:,:)
  integer, allocatable :: g3vw(:,:)
  integer, allocatable :: g4vw(:,:)

  integer, allocatable :: igv_sample(:)
  integer, allocatable :: igc_sample(:)

  integer, allocatable :: itrue_v(:,:), itrue_c(:,:) ! see readme.f90
  
  real*4, allocatable ::  Wbe_D(:,:,:),    b1b_D(:,:),   b2b_D(:,:)
  real*4, allocatable ::  Wbe_stoch(:,:,:),  b1b_stoch(:,:), b2b_stoch(:,:)
  real*4, allocatable ::  Wbe_SR(:,:,:),     b1b_SR(:,:),    b2b_SR(:,:)
  real*4, allocatable ::  vwij(:,:,:)

  real*4, allocatable ::  vwdiag1(:,:)
  
  real*8, allocatable ::  fflt(:,:,:,:)
  
!  real*8, parameter ::  ekcut = 25 ! read later
!  real*8, parameter ::  gam_bnl = 0d0
  real*8, parameter ::  toll_cheby = 1d-7 ! relative toll. for cheby. coeff. 
  real*8 fctrchby
  real*8 dx, dy, dz, dv
  real*8 charge, chargeU, chargeD

  real*8 wmax, dw, kappa
  real*8 wsmin, wsmax, dws ! w.f. are sampled stochastically at nws frequencies from wsmin to wsmax
  ! those frequencies may not be exactly equispaced, as they need to match
  ! the omega grid.
  real*8 scissors, scissors_shift_v0!, factor_shift
  real*8 Ltop, Lbot, dL, Lavg,  ewdth, f0_sq
  real*8 pot_shft
  real*8 ampW, gamW, ampbare
  real*8 kcut_vw  ! separates the two ways of sampling vw
  real*8 nalpha_factor ! nalpha = nalpha_factor * nk_low
  real*8 alpha_coverage

  ! each point is stochastically sampled alph.cov. times
  ! phi for chi0; pv for beta
  !  integer, allocatable :: map_ib(:,:)

  real*8, allocatable :: phiocc1(:,:), dens0(:,:)
  real*8, allocatable :: dens01(:,:), dens0core(:)
  real*8, allocatable :: pv1(:,:,:), ev(:,:)
  real*8, allocatable :: pc1(:,:,:), ec(:,:) ! pc1: pc scattered.
  real*8, allocatable :: wa(:), dipw(:,:)
  real*8, allocatable :: res(:,:), wg(:), wg_w(:)
  real*8, allocatable :: grd1(:,:) 
  real*8, allocatable :: f0b(:,:,:,:), fdb(:,:,:,:,:) ! r(pol)*phi_occ in basis, etc. 
  real*8, allocatable :: coef(:,:) ! chebyshev coef
  real*8, allocatable :: fws(:,:,:,:,:), ws(:)
  real*8, allocatable :: wstot(:)
  real*8, allocatable :: vk(:), vkb(:)
  real*8, allocatable :: vwk_fit(:) ! fit of the polarization part
  real*8, allocatable :: vwkpol(:)             ! "pol" -- polarization only. see below for "b"
  real*8, allocatable :: vwktot(:)            
  real*8, allocatable :: vwktot_low(:)         ! low-k sampling
  real*8, allocatable :: vwktot_high(:)         ! low-k sampling
  real*8, allocatable :: vw_diag(:,:,:)
  real*8, allocatable :: charge_a(:)
  real*8, allocatable :: k2_a(:)   ! k squared array, for usual or doubled grid
!  real*8, allocatable :: klow(:,:)
  real*8, allocatable :: w_anlz(:)
  !real(kind=8), allocatable :: eta(:,:)
  !real(kind=8), allocatable :: feta(:,:)

  complex(kind=kind_gamma_c), allocatable :: gvlow(:,:)
  complex(kind=kind_gamma_c), allocatable :: gclow(:,:)
  complex(kind=kind_gamma_c), allocatable :: gvalpha(:,:)
  complex(kind=kind_gamma_c), allocatable :: gcalpha(:,:)
  real(kind=kind_gamma), allocatable :: ovrlp_mtrx(:,:)
  complex(kind=kind_gamma_c), allocatable :: &
       rhoij1(:,:,:)  ! <k|phi_is_i phi_is_j>, for a strip of k,

  complex(kind=kind_gamma_c), allocatable :: &
       rhoab1(:,:,:)  ! <k|phi_is_i phi_is_j>, for a strip of k

  complex(kind=kind_gamma_c), allocatable :: &
       rhobi1(:,:,:,:)  ! <k|phi_is_b phi_is_i>, for a strip of k
end module jr
