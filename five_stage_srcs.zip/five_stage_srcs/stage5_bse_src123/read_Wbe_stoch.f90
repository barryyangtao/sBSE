subroutine read_Wbeta_stoch
  use jr
  use simple_mpi, only : rank, nodes, scatter_r4, bcast_r4
  implicit none

  integer ib, iib, ir, nds, st, is
  real*4, allocatable ::  b_raw(:,:), w1(:,:)

  if(nbe_stoch==0)return

  nds = max(nodes,1)
  
  allocate(b_raw(nv_stoch,2),stat=st); if(st/=0) stop ' b_raw'

  allocate(w1(nn, nsp), stat=st);
  call check0(st,' w1 ')
  w1=0d0
  
  allocate(Wbe_stoch(n1,nsp,nbe_stoch),stat=st)
  call check0(st,' Wbe ')

  allocate(b1b_stoch(nv_stoch,nbe_stoch), b2b_stoch(nv_stoch,nbe_stoch), stat=st);
  call check0(st,' b_stoch ')

  do ib=1,nbe_stoch
     rnk0 : if(rank==0) then
        read(30)iib
        call check(iib,ib,' stoch: iib b_b ')
        read(30)b_raw

        read(30)iib
        call check(iib,ib,' stoch: iib Wbeta ')
        read(30) w1(1:n,:)

        b1b_stoch(:,ib) = b_raw(:,1)
        b2b_stoch(:,ib) = b_raw(:,2)
        
        !if(stoch_analysis_Wk) call Wbeta_stoch_vk(w1, b_raw, ib, nbe_stoch)
     endif rnk0
     do is=1,nsp
        call scatter_r4(w1(:,is), Wbe_stoch(:,is,ib), n1, 0)
     end do
     call bcast_r4(b1b_stoch, size(b1b_stoch),0)
     call bcast_r4(b2b_stoch, size(b2b_stoch),0)
     deallocate(b_raw,w1)
  end do
end subroutine read_Wbeta_stoch
