subroutine read_Wbeta_det
  use jr
  use simple_mpi, only : rank, nodes, scatter_r4, gather_r4, bcast_r4
  implicit none

  integer ib, iib, ir, nds, st, m, is
  real*4, allocatable ::  b_raw(:,:), w_single(:,:)
  real*4, allocatable ::  beta_slice(:,:), beta(:,:), vbeta(:,:), vbeta_slice(:,:)
  nds = max(nodes,1)

  if(nbe_D==0)return
  
  allocate(b_raw(nv_D,2),stat=st); if(st/=0) stop ' b_raw'
  allocate(w_single(nn,nsp), beta_slice(n1,nsp), beta(nn,nsp), &
       vbeta(nn,nsp), vbeta_slice(n1,nsp), stat=st);
  call check0(st,' w_single ')
  w_single=0d0
  
  allocate(Wbe_D(n1,nsp,nbe_D),stat=st)
  call check0(st,' Wbe ')

  allocate(b1b_D(nv_D,nbe_D), b2b_D(nv_D,nbe_D), stat=st);
  call check0(st,' b_D ')

  if(rank==0) write(6,*)' nbe_D ',nbe_D
  do ib=1,nbe_D
     rnk0 : if(rank==0) then
        read(31)iib
        call check(iib,ib,' det: iib b_b ')
        read(31)b_raw
        read(31)iib
        call check(iib,ib,' det: iib Wbeta ')
        read(31) w_single(1:n,:)
        b1b_D(:,ib) = b_raw(:,1)
        b2b_D(:,ib) = b_raw(:,2)
     endif rnk0

     do is=1,nsp
        call scatter_r4(w_single(:,is), Wbe_D(:,is,ib), n1, 0)
     end do
  end do
  call bcast_r4(b1b_D, size(b1b_D),0)
  call bcast_r4(b2b_D, size(b2b_D),0)
  
  ! now: If not using W-v, add vbeta to Wbe_d. (If Wvw, then subtract vwpol only)
  if(vwtype.ne.'W') return
  
  !Subtract v in batches of size "nds", i.e., one beta for each core
  do m=1,nbe_D,nds
     do ib=m,min(m+nds-1,nbe_D)
        ir=ib-m
        call make_beta
        call gather_beta ! gathers beta to node ir (where ir is each of the nodes)
     enddo
     do ib=m,min(m+nds-1,nbe_D)
        call make_vbeta  ! in present node
     enddo
     do ib=m,min(m+nds-1,nbe_D)
        ir=ib-m
        do is=1,nsp
           call scatter_r4(vbeta(:,is), vbeta_slice(:,is), n1, ir)
           Wbe_D(:,is,ib) = Wbe_D(:,is,ib) + vbeta_slice(:,is)
        enddo
     enddo
  enddo
  
contains
  subroutine make_beta
    real*4, allocatable :: beta1(:,:), beta2(:,:)
    allocate(beta1(n1,nsp), beta2(n1,nsp), stat=st)
    call check0(st,' beta1 ')
    do is=1,nsp
       beta1(:,is) = matmul(pv1(:,is,:),b1b_D(:,ib))
       beta2(:,is) = matmul(pv1(:,is,:),b2b_D(:,ib))
    enddo
    beta_slice = beta1*beta2
  end subroutine make_beta

  subroutine gather_beta
    do is=1,nsp
       call gather_r4(beta_slice(:,is), beta(:,is), n1, ir)
    enddo
  end subroutine gather_beta

  subroutine make_vbeta
    real*8, allocatable :: dens(:), vh(:)
    allocate(dens(n), vh(n), stat=st)
    call check0(st,' vbeta ')
    do is=1,nsp
       dens = beta(1:n,is) ! dens is real*8, beta real*4
       call dens_to_vh(dens, vh)
       vbeta(:,is) = 0
       vbeta(1:n,is)= vh   !real*4 <-- real*8
    enddo
  end subroutine make_vbeta
end subroutine read_Wbeta_det
