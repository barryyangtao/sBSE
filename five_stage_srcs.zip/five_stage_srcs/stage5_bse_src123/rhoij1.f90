subroutine rhoij1_make
  use jr
  use simple_mpi, only : rank, nodes, gather_r8
  use simple_mpi, only : bcast_r8, scatter_c8, bcast_scalar_general_i, sync_mpi
  implicit none
  integer iv, jv, ir, j_r, jvloc, nvloc, nvloc_ofjr, is
  integer i, ij, st, nds
  integer ip
  integer, allocatable :: map_iv(:)
  real*8 :: t0, t1
  real*8 :: tbcast=0, tfft=0, tsclspl=0, tcmprss=0, tbcast2=0, tscatter=0
  real*8, allocatable  :: pv_loc(:,:), p(:)
  real*8, allocatable  :: dns(:), dnsb(:)
  complex*16, allocatable :: uk(:)
  complex(kind=kind_gamma_c), allocatable  :: uklow(:), ukhigh(:), ukalpha(:), ukglue(:)
  complex(kind=kind_gamma_c), allocatable  :: cp(:)
  complex(kind=kind_gamma_c), allocatable  :: rhoij_loc(:,:)
  
  ip = 76000+rank
  ! First check that you need to be here
  if(.not.flg_rhoij) return

  select case(vwtype)
  case('W','rpa','Rpa','RPA'); return
  case('Wvw','vw','vwk'); continue
  case default; stop ' vwtype_vwij '
  end select
  
  !if(diag_remove)stop ' dont use diag_remove '

  call time_print(' entering rhoij ')
  
  ! Now start
  nds=max(nodes,1)
  if(nv_band==0) return
  
  ! Assign the phi states, to the nodes, phi1 to node 0, phi2 to node 1, etc.
  ! For this you need maps.

  call make_map_iv
  call check(maxval(ijmap), nij,' maxval_ijmap nij ')
  
  ! now finished maps, allocate and gather the w.f.

  if(allocated(rhoij1)) deallocate(rhoij1)
  allocate(rhoij1(ncomb1,nij,nsp), stat=st)
  call check0(st,' rhoij1 ')

  allocate(rhoij_loc(ncomb, nvloc), stat=st)
  call check0(st,' rhoij_loc ')
  
  allocate(pv_loc(n,nvloc), p(nn), stat=st)
  call check0(st,' pv_loc ')

  allocate(dns(n), dnsb(nk), uk(nk), stat=st) 
  call check0(st,' dns ')

  if(flg_gamma) then
     call check(ncomb, nk_low,' ncomb, nk_low so no gluing ')
  else
     call check(ncomb, nk_low+ nalpha,' ncomb, ncw+low+n_alpha ')
  endif


  allocate(ukhigh(nk_high), uklow(nk_low), ukglue(ncomb), cp(nncomb), stat=st)
  call check0(st,' uksplit ')

  allocate(ukalpha(nalpha), stat=st)
  call check0(st,' ukalpha ')

  cp = 0 ! important for scatter
  
  ! main loop, bcast, fft, and dot product.  But first allocate

  isloop : do is=1,nsp
     call gather_pv_loc
     
     if(allocated(p)) deallocate(p)
     allocate(p(n), stat=st)
     call check0(st,' p ')
     i=0
     mainloop : do iv=1,nv_band
        ! first send the iv'th w.f. from its rank
        ir = mod(iv-1,nds)
        if(rank==ir)then 
           i=i+1
           p=pv_loc(:,i)
        endif
        call cpu_time(t0)
        call bcast_r8(p, size(p), ir)
        call cpu_time(t1); tbcast = tbcast+(t1-t0)
        ! now loop over all exisiting w.f.
        do jvloc=1,nvloc
           call cpu_time(t0)
           jv= map_iv(jvloc)
           ij= ijmap(iv,jv)
           dns = p*pv_loc(:,jvloc) ! phi(:,iv)*phi(:,jv)
           call broaden_dns_to_dnsb ! puts dns on bigger grid
           call fft_dnsb_to_uk   ! clear by name
           call cpu_time(t1);    tfft = tfft + t1-t0; t0=t1
           call scale_right_uk   ! uk--> const*sqrt(vwktot)*uk
           call split_uk         ! splits to uklow, ukhigh
           call cpu_time(t1);    tsclspl = tsclspl + t1-t0; t0=t1
           if(.not.flg_gamma) call compress_kind_g_c(ukhigh, ukalpha) ! makes uk_alpha
           call glue_uklow_ukalpha ! makes ukglue
           call assign_ukglue_to_rhoij_loc
           call cpu_time(t1);    tcmprss = tcmprss + t1-t0; t0=t1
        enddo
        
        ! now bcast the calculated rhoij
        
        !nvloc_ofjr = -99
        jrloop : do j_r=0,nds-1
           
           if(j_r==rank) nvloc_ofjr= nvloc
           
           call cpu_time(t0);    
           call bcast_scalar_general_i(nvloc_ofjr, j_r)
           call cpu_time(t1);    tbcast2 = tbcast2 + t1-t0; t0=t1
           
           call cpu_time(t0);    
           jvloc_loop : do jvloc =1,nvloc_ofjr
              !jv = -99
              !ij = -99
              if(j_r==rank) then
                 jv= map_iv(jvloc)
                 ij= ijmap(iv,jv)
                 !cp(1:ncomb) = ukglue(:)
                 cp(1:ncomb) = rhoij_loc(:,jvloc) 
              endif
              call bcast_scalar_general_i(ij, j_r)
              
              call scatter_c8(cp, rhoij1(:,ij,is), ncomb1, j_r)
              call cpu_time(t1);    tscatter = tscatter + t1-t0; t0=t1
              
           end do jvloc_loop
        end do jrloop
     end do mainloop
  end do isloop

  if(rank==0) then
     write(6,*)' tbcast, tfft, tsclspl, tcmprss, tbcast2, tscatter '
     write(6,*)real(tbcast),real(tfft),real(tsclspl), real(tcmprss), &
          real(tbcast2), real(tscatter)
     call flush(6)
  end if
  call time_print(' finished rhoij ')
  !call debug
  
contains
  
  subroutine make_map_iv
    i=0
    do iv=1,nv_band
       ir=mod(iv-1,nds)
       if(rank==ir)i=i+1
    enddo
    
    nvloc = i

    allocate(map_iv(nvloc), stat=st)
    call check0(st,' map_iv ')
    
    i=0
    do iv=1,nv_band
       ir=mod(iv-1,nds)
       if(rank==ir) then
          i=i+1
          map_iv(i) = iv
       endif
    enddo
  end subroutine make_map_iv

  subroutine gather_pv_loc
    if(allocated(p)) deallocate(p)
    allocate(p(nn),stat=st)
    call check0(st,' p  ')

    i=0
    do iv=1,nv_band
       ir = mod(iv-1,nds)
       call gather_r8(pv1(:,is,iv), p, n1, ir)
       if(rank==ir) then
          i=i+1
          pv_loc(:,i) = p(1:n)
       endif
    end do
    
    call time_print('  rhoij post-gather ')
  end subroutine gather_pv_loc
    
  subroutine fft_dnsb_to_uk
    uk = dnsb
    call fft3d_forward(nx*scale_vh, ny*scale_vh, nz*scale_vh, uk, uk)
  end subroutine fft_dnsb_to_uk

  subroutine scale_right_uk
    call check(size(uk), size(vwktot),' size_u_vwktot ')
    uk = uk * sqrt(abs(vwktot(:)))*  sqrt(dv/dble(nk))
  end subroutine scale_right_uk

  subroutine split_uk ! splits to uklow, ukhigh
    uklow  = uk(map_vwklow(:))
    ukhigh = uk(map_vwkhigh(:))
  end subroutine split_uk

  subroutine glue_uklow_ukalpha
    ukglue(1:size(uklow))= uklow
    if(.not.flg_gamma) ukglue(size(uklow)+1:size(uklow)+nalpha) = ukalpha
  end subroutine glue_uklow_ukalpha

  subroutine assign_ukglue_to_rhoij_loc
    rhoij_loc(:,jvloc) = ukglue(:)
  end subroutine assign_ukglue_to_rhoij_loc
  
  subroutine broaden_dns_to_dnsb
    if(mod(nx ,2)/=0.or.mod(ny ,2)/=0.or.mod(nz ,2)/=0) stop ' make nx ,ny ,nz  all even '

    select case(scale_vh)
    case(2); call dns_to_dnsb(dns,dnsb)
    case(1); dnsb= dns
    case default; stop 'scale_vh problem '
    end select
  end subroutine broaden_dns_to_dnsb

  subroutine dns_to_dnsb(dns,dnsb)
    implicit none
    real*8  dns( nx, ny, nz)
    real*8  dnsb(nx*2,ny*2,nz*2)
    integer mx,my,mz,px,py,pz
    call check(scale_vh, 2, 'scale_vh vs. 2 ')

    dnsb = 0d0
    
    mx= 1 + nx - nx/2
    px=     nx + nx/2

    my= 1 + ny - ny/2
    py=     ny + ny/2

    mz= 1 + nz - nz/2
    pz=     nz + nz/2

    dnsb(mx:px,my:py,mz:pz) = dns
  end subroutine dns_to_dnsb

  subroutine debug
    use simple_mpi, only : allsum_scalar_r8
    real*8 sum_check
    sum_check = sum(abs(rhoij1**2))
    write(ip,*)' rhoij1_norm2 ',sum_check
    call flush(ip)
  end subroutine debug

end subroutine rhoij1_make

