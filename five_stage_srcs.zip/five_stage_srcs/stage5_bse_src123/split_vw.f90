subroutine split_vw
  use jr
  use simple_mpi, only : rank
  implicit none
  integer st

  call map_vwk_low_high
  
  allocate(vwktot_low(nk_low), stat=st)
  call check0(st,' vwktot_low ')

  allocate(vwktot_high(nk_high), stat=st)
  call check0(st,' vwktot_high ')

  if(periodic) then
     call split_vw_inside(vwktot, vwktot_low, vwktot_high)
  else
     call split_vw_inside(vwktot, vwktot_low, vwktot_high)
  end if

  if(rank==0) write(6,*)' vwktot_low, vwktot_high ',sum(abs(vwktot_low)), sum(abs(vwktot_high))
  
end subroutine split_vw

subroutine map_vwk_low_high
  use jr
  use simple_mpi, only : rank
  implicit none
  integer i, j, ik, irep, st
!un-erase, put here rather than 0*0  real*8, allocatable :: k2_a(:)   ! k squared array, for usual or doubled grid
  !call make_k2_a
  
  i=0
  j=0
  do ik=1,size(k2_a)
     if(sqrt(k2_a(ik))<kcut_vw) then
        i=i+1
     else
        j=j+1
     end if
  enddo
  nk_low = i
  nk_high = j
  
  allocate(map_vwklow(nk_low), stat=st)
  call check0(st,' map_nk_low ')

  allocate(map_vwkhigh(nk_high), stat=st)
  call check0(st,' map_nk_high ')

  i=0
  j=0
  do ik=1,size(k2_a)
     if(sqrt(k2_a(ik))<kcut_vw) then
        i=i+1
        map_vwklow(i) = ik
     else
        j=j+1
        map_vwkhigh(j) = ik
     end if
  enddo

  call check(i,nk_low,' i, nk_low')
  call check(j,nk_high,' j, nk_high')
  call check(nk_low+nk_high,size(k2_a),' nvw low plus high vs. size(k2_a) ')

  !call debug
  
contains

  subroutine debug
    implicit none
    integer ik
    if(scale_vh==2) then
       write(6,*)' maxval,maxloc vwktot_low ',&
            maxval(abs(vwktot(map_vwklow(:)))), &
            maxloc(abs(vwktot(map_vwklow(:))))
       ik = product( maxloc(abs(vwktot(map_vwklow(:)))))
       write(6,*)' maxvwlow: ik, k2_a ',ik,k2_a(ik)
    
       write(6,*)' maxval,maxloc vwktot_high ',&
            maxval(abs(vwktot(map_vwkhigh(:)))), &
            maxloc(abs(vwktot(map_vwkhigh(:))))
       ik = product( maxloc(abs(vwktot(map_vwkhigh(:)))))
       write(6,*)' maxvwhigh: ik, k2_a ',ik,k2_a(ik)
    endif
  end subroutine debug
end subroutine map_vwk_low_high
  
subroutine split_vw_inside( vwk, vwk_low, vwk_high)
  use jr
  use simple_mpi, only : rank
  implicit none
  integer i,ik
  real*8 vwk(*), vwk_low(nk_low), vwk_high(nk_high)

  if(rank==0) write(6,*)' vwk (pre-low) ',sum(vwk(1:n*scale_vh**3)) 
  vwk_high(:) = vwk(map_vwkhigh(:))
  vwk_low(:) = vwk(map_vwklow(:))

  !if(neta.ne.0) then ! if using eta, zero vwk in its low parts, as eta is using vwk, not vwk_high
  !   stop ' need to modify vwklow if neta=0 '
  !   vwk(map_vwklow(:)) = 0
  !endif

  if(rank==0) then
     write(6,*)' vwk_high ',sum(vwk_high)
     write(6,*)' vwk_low ',sum(vwk_low)
     write(6,*)' nk_low ',nk_low
     write(6,*)' nk_high ',nk_high
  endif

end subroutine split_vw_inside
