subroutine prop_cheby
  use jr
  use simple_mpi, only : rank, nodes, sync_mpi, allsum_scalar_r8
  implicit none
  integer  st,nds
  real*8, allocatable :: u(:,:,:,:), u1(:,:,:,:), u2(:,:,:,:)

  call time_print(' entering prop_cheby')
  nds = max(nodes,1)

  allocate(u(nm,nv,nq,nsp), u1(nm,nv,nq,nsp), u2(nm,nv,nq,nsp), stat=st)

  dipw=0d0
  res=0d0
  !call check_hermiticity
  
  call time_print('post checking hermiticity.  pre cheby loop')
  do icheby=0,ncheby
     select case(icheby)
     case(0)
        call set_initial_state(u)
        u2=u
        !call debug_diag_L ! comment out later
     case(1)
        call L_scld(u2,u)
        u1=u
     case(2:)
        call L_scld(u1,u)
        u = 2d0*u - u2
        u2=u1
        u1=u
     end select
     
     call calc_res(icheby,u)
     call print_res
     call add_dipw
     call add_flts
     call progress_report
  end do

  deallocate(u,u1,u2)
  call time_print(' post prop_cheby ')
contains
  subroutine progress_report
    use simple_mpi, only : rank
    implicit none
    integer, external :: is_it_power2
    real*8 resmx
    if(rank/=0) return

    resmx  = maxval(abs(res(icheby,:)))

    if(is_it_power2(icheby+1)==1) then
       write(6,*)' i_cheby, res, res0 ',icheby,real(resmx),real(f0_sq)
       call flush(6)
    endif

  end subroutine progress_report
  
  subroutine L_scld(uin, uout)
    implicit none
    real*8 uin(nm,nv,nq,nsp), uout(nm,nv,nq,nsp)
    call Lsub(uin, uout)
    uout = uout/dL - (Lavg/dL)*uin
  end subroutine L_scld

  subroutine print_res
    implicit none
    logical, save:: first=.true.
    if(rank/=0) return
    if(first) then
       first=.false.
       open(34,file='res.txt',status='replace')
    end if
    write(34,*)icheby,real(res(icheby,:)),' i,res'
    call flush(34)
  end subroutine print_res

  subroutine add_dipw
    implicit none
    integer id, st
    real*8, allocatable ::  wscld(:), term(:)

    allocate(wscld(size(wa)), stat=st)
    call check0(st,' wscld ')

    wscld = (wa(:)-Lavg)/dL
    where(wscld<-1)
       wscld = -0.999999
    else where(wscld>1) 
       wscld = 0.999999
    end where

    if(rank/=0) return
    do id=1,3
       if(simple_cheby) then
          dipw(:,id)=  dipw(:,id) + &
             wg(icheby)*wg_w(:)*cos(icheby* acos(wscld))  *res(icheby,id)
       else
          dipw(:,id) = dipw(:,id) + coef(icheby,:)*res(icheby,id)
       endif
    enddo

  end subroutine add_dipw

  subroutine add_flts
    call add_flts_basis
  end subroutine add_flts
  
  subroutine add_flts_basis
    implicit none
    integer iws, iw
    real*8 wscld
    do iws=1,nws
       iw=mapiws(iws)
       if(simple_cheby) then

          wscld = (wa(iw)-Lavg)/dL
          if(wscld<-1) then
             wscld = -0.999999
          else if(wscld>1) then
             wscld = 0.999999
          end if

          fws(:,:,:,:,iws) = &
          fws(:,:,:,:,iws) + &
               wg(icheby)*wg_w(iw)*cos(icheby* acos(wscld))*u(:,:,:,:)
       else
          fws(:,:,:,:,iws) = &
          fws(:,:,:,:,iws)+ &
               coef(icheby,iw)*u(:,:,:,:)
       end if
    end do
  end subroutine add_flts_basis

  subroutine check_hermiticity
    implicit none
    integer i,iv,iq,is
    real*8  d, term1, term2
    d=0
    do is=1,nsp
       do iq=1,nq
          do iv=1,nv
             do i=1,size(u,1)
                d=d+0.3*(iv*i)+0.55*i+iq*73+is*(iv**2+iq+4)
                if(d>2236274)d= d-327286.31
                u(i,iv,iq,is) = cos(d*23+d*d*0.4828912)
                u1(i,iv,iq,is)= sin(d*34237+d*d*0.13829)
             enddo
          enddo
       end do
    enddo
    !if(mixrep) call clean(u)
    !if(mixrep) call clean(u1)
    call Lsub(u,u2)
    term1 = sum(u1*u2)!*dv
    call allsum_scalar_r8(term1)

    if(rank==0) write(6,*)' hermiticity: <u1|L|u> ',term1

    call Lsub(u1,u2)
    term2 = sum(u*u2)!*dv
    call allsum_scalar_r8(term2)

    if(rank==0) write(6,*)' hermiticity: <u|L|u1> ',term2

    call sync_mpi
    if(abs(term1-term2)/(abs(term1)+abs(term2)) >1d-8) stop ' term1, term2 '

  end subroutine check_hermiticity
    
end subroutine prop_cheby

