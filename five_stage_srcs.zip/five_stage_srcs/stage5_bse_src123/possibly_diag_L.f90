subroutine possibly_diag_L
  use jr
  use simple_mpi, only : rank
  use mat_module, only : mat_diag
  implicit none
  integer st, m, i
  real*8,     allocatable :: Lr(:,:), u(:)
  complex*16, allocatable :: Lc(:,:), Levc(:,:), Levl(:)

  m = nc*nv*nq*nsp
  if(m>2) return ! note : can adjust
  
  allocate(u(m), Lr(m,m), Lc(m,m), Levc(m,m), Levl(m), stat=st)
  call check0(st,' LrLc ')

  do i=1,m
     u=0
     u(i) = 1
     call Lsub_b(u, Lr(:,i))
  enddo

  if(rank==0) then
     write(6,*)' Lavg, dL ',real(Lavg), real(dL)

     
     if(size(Lr,1)>10) then
        write(6,*)' L_sub_diag '
        do i=1,min(5,nc*nv)
           write(6,*)real(Lr(i,1:min(5,nc*nv)))
        enddo
        write(6,*)
        if(nq==2) then
           write(6,*)' L_sub_offdiag_lowerleft(1:5,1:5) '
           do i=1,min(5,nc*nv)
              write(6,*)  real(Lr(nc*nv+i,1:min(5,nc*nv)))
           enddo
        end if
     else

        write(6,*)' ev ',real(ev)
        write(6,*)' ec ',real(ec)
        write(6,*)' L_sub '
        do i=1,size(Lr,1)
           write(6,*) real(Lr(i,:))
        enddo
     end if
  end if
     
  if(rank==0) then
     Lc = Lr
     call mat_diag(Lc, Levc, Levl)
     write(6,*)' minval, maxval(Levl_real) ',minval(real(Levl)), maxval(real(Levl))
     write(6,*)' minval, maxval(Levl_imag) ',minval(aimag(Levl)), maxval(aimag(Levl))
     write(6,*)' Levl '
     do i=1,size(Levl)
        write(6,*)i,Levl(i),' i, Levl(i) '
     enddo
  endif

end subroutine possibly_diag_L
  
     
    
     
