subroutine vwij_make
  use jr
  use simple_mpi, only : rank, nodes, bcast_r8, gather_r8, scatter_r4
  implicit none
  integer i, j, st, nds, ij, ir, iu, is
  real*4, allocatable :: vwd4(:)
  real*8, allocatable :: phi(:,:), u(:), d(:), vwd(:)

  if(vw_stoch) return
  select case(vwtype)
  case('W','rpa','Rpa','RPA'); return
  case('Wvw','vw','vwk'); continue
  case default; stop ' vwtype_vwij '
  end select

  nds=max(nodes,1)

  allocate( vwij(n1, nij,nsp), imapvw(nij), jmapvw(nij), stat=st)
  call check0(st,' vwij ')
  allocate( phi(n,nv_vw), u(nn), d(n), vwd(n),  vwd4(nn), stat=st)
  call check0(st,' phi ')

  call make_vwmap

  do is=1,nsp
     do i=1,nv_vw ! expensive in memory, will improve later
        call gather_r8(pv1(:,i,is), u,n1,0)
        call bcast_r8(u, size(u), 0)
        phi(:,i) = u(1:n)
     enddo
     
     do iu=0,nij-1,nds
        do ij=iu+1,min(iu+nds,nij)
           i=imapvw(ij)
           j=jmapvw(ij)
           ir=ij-iu-1
           if(ir==rank) then
              d = phi(:,i)*phi(:,j)
           endif
        enddo
        
        call dens_to_vwtot(d,vwd)
        vwd4(1:n)= vwd
        vwd4(n+1:nn)= 0d0
        
        do ij=iu+1,min(iu+nds,nij)
           i=imapvw(ij)
           j=jmapvw(ij)
           ir=ij-iu-1
           call scatter_r4(vwd4,vwij(:,ij,is),n1,ir)
        enddo
     enddo
  enddo
end subroutine vwij_make

