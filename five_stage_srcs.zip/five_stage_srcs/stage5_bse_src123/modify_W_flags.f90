subroutine modify_W_flags
  use jr
  implicit none
  if(vwtype.ne.'vw'.and.vwtype.ne.'vwk') return
  if(det_beta)   nbe_D=0
  if(stoch_beta) nbe_stoch=0
  if(SR_beta)  stop ' no SR_beta '!  nbe_SR=0
end subroutine modify_W_flags
  
