subroutine Lsub_b(f, u)
  use jr
  use simple_mpi, only : rank, allsum_r8
  use simple_mpi, only : scatter_r8, gather_r8
  implicit none
  integer iv, st, iq, is 
  real*8 f(nc, nv, nq, nsp), u(nc, nv, nq, nsp)
  real*8, allocatable :: fg1(:,:,:,:), ug1(:,:,:,:),dn(:,:), dn1(:,:), vxc1(:,:)

  call time_print(' entering Lsub ')

  allocate(fg1(n1, nv, nq, nsp), ug1(n1, nv, nq, nsp), stat=st)
  call check0(st,' fg1 ')
  ug1=0

  call time_print(' begin Lsub_b ')
  call filter_participate(f)
  call f_to_fg1_band
  call time_print(' post f to fg1 ')
  call minusWf
  call time_print(' post minusWf  ')
  call ug1_band_to_u

  ug1 = 0 ! reset
  call f_to_fg1_addnonband

  !call minusvwdiag
  call time_print(' post minusvwdiag  ')
  call kappaKx_hxc
  call ug1_loc_to_u_add

  call add_diag

  select case(vwtype)
  case('Wvw','vw')
     if(flg_rhoij) then
        do is=1,nsp
           call minus_vw_glue(f(:,:,:,is),u(:,:,:,is),is)
           call minus_vw_diag_exband(f(:,:,:,is),u(:,:,:,is),is)
        enddo
        call time_print(' post minus_vw_glue  ')
     end if
  end select

  call flip_sign_full_bse

  call filter_participate(u)
contains
    
  subroutine f_to_fg1_band
    fg1 = 0
    do is=1,nsp
       do iq=1,nq
          fg1(:,1:nv_band,iq,is) = matmul(pc1(:,is,1:nc_band),f(1:nc_band,1:nv_band,iq,is))
       enddo
    enddo
  end subroutine f_to_fg1_band

  subroutine f_to_fg1_addnonband  ! before we dealt with "sub-cube".  Now the full fg
    do is=1,nsp
       do iq=1,nq
          fg1(:,nv_band+1:,iq,is) = matmul(pc1(:,is,1:nc_band),f(1:nc_band,nv_band+1:,iq,is))
          fg1(:,:,iq,is) = fg1(:,:,iq,is)+ matmul(pc1(:,is,nc_band+1:),f(nc_band+1:,:,iq,is))
       enddo
    enddo
  end subroutine f_to_fg1_addnonband

  subroutine add_diag
    implicit none

    do is=1,nsp
       do iq=1,nq
          do iv=1,nv
             u(:,iv,iq,is) = u(:,iv,iq,is) +&
                  (ec(:,is) + scissors  + pot_shft-ev(iv,is))*f(:,iv,iq,is)
             !(ec(:) + scissors - scissors_shift_v0 + pot_shft-ev(iv))*f(:,iv,iq)
          enddo
       enddo
    enddo
  end subroutine add_diag

  subroutine kappaKx_hxc
    real*8, allocatable :: vh1(:), vh(:), dnsum(:), vcomb1(:,:)

    allocate(dn1(n1,nsp),dnsum(n), vh1(n1), dn(nn,nsp), vh(nn), vxc1(n1,nsp), vcomb1(n1,nsp), &
         stat=st)
    call check0(st,' dn1 ')

    dn = 0
    do is=1,nsp
       dn1(:,is) = sum(sum(fg1(:,:,:,is),dim=3)*pv1(:,is,:),dim=2) !XXX which terms to put here?
       call gather_r8(dn1(:,is), dn(:,is), n1, 0)
    enddo
    dnsum = sum(dn(1:n,:),dim=2) * kappa/nsp ! for nsp=2, we scale down.
    
    vh=0d0
    if(rank==0) call dens_to_vh(dnsum(1:n),vh(1:n))
    call scatter_r8(vh, vh1, n1, 0)

    if(tddft_flg) then 
       call tddft_xc
    else
       vxc1=0
    end if
    do is=1,nsp
       vcomb1(:,is) = vh1(:)+vxc1(:,is) 
    enddo

    do iq=1,nq
       do iv=1,nv
          ug1(:,iv,iq,:) = ug1(:,iv,iq,:) + vcomb1(:,:)* pv1(:,:,iv)
       enddo
    enddo
  end subroutine kappaKx_hxc

  subroutine tddft_xc
    ! xxx need to scatter dens0 to dens01
    real*8, parameter :: sml=1d-4, base=1d-9  ! base=min_density
    real*8, allocatable :: dens1(:,:)
    real*8, allocatable :: dens1_trans(:,:), vxc01_trans(:,:), vxc1_trans(:,:)

    allocate(dens1(n1,nsp),stat=st)
    call check0(st,' dens1 ')

    allocate(dens1_trans(nsp, n1),vxc01_trans(nsp, n1), vxc1_trans(nsp, n1), stat=st)
    call check0(st,' dens1_trans ')

    dens1 = dens01
    where(dens1.le.base) dens1=base

    dens1_trans = transpose(dens1)
    call vxc_spin_pwlda_fit(dens1_trans, vxc01_trans, n1, nsp) ! prepared only on subgrid

    !dens1 = dens01+kappa*sml*dn1  ! note the factor of kappa(=2), DN, corrected
    dens1 = dens01+sml*dn1*(kappa/nsp) ! divide by nsp
    where(dens1.le.base) dens1=base

    dens1_trans = transpose(dens1)
    call vxc_spin_pwlda_fit(dens1_trans,  vxc1_trans,  n1, nsp) ! prepared only on subgrid
    vxc1  = transpose((vxc1_trans-vxc01_trans)/sml)

    !write(6,*)' minmax vxc1 ',minval(vxc1),maxval(vxc1)
    where(dens1.le.base) vxc1=0
    !write(6,*)' post base minmax vxc1 ',minval(vxc1),maxval(vxc1)
  end subroutine tddft_xc
    
  
  subroutine minusWf
    select case(vwtype)
    case('W','Wvw')
       do is=1,nsp
          if(stoch_beta) call minusWf_stoch(fg1(:,:,:,is),ug1(:,:,:,is),is)
          if(det_beta)   call minusWf_det(fg1(:,:,:,is),ug1(:,:,:,is),is)
          if(SR_beta)    stop ' SR_beta ' !call plusWf_SR(fg1(:,:,:,is),ug1(:,:,:,is),is)
       enddo
    end select

!    select case(vwtype)
!    case('Wvw','vw')
!       call minus_vw_eta(fg1,ug1)
!    end select
  end subroutine minusWf

  subroutine ug1_band_to_u
    integer iv
    u = 0
    do is=1,nsp
       do iq=1,nq
          do iv=1,nv_band
             u(1:nc_band,iv,iq,is) = matmul( ug1(:,iv,iq,is),pc1(:,is,1:nc_band))*dv
             ! u(1:nc,1:nv) = matmul(transpose(pc1),ug1)*dv
          enddo
       enddo
    enddo
    !call allsum_r8(u,size(u)) -- done later
  end subroutine ug1_band_to_u

  subroutine ug1_loc_to_u_add       
    integer iv
    do is=1,nsp
       do iq=1,nq
          do iv=1,nv
             u(:,iv,iq,is) = u(:,iv,iq,is) + &
                  matmul( ug1(:,iv,iq,is),pc1(:,is,:))*dv
             ! u(1:nc,1:nv) = matmul(transpose(pc1),ug1)*dv
          enddo
       end do
    enddo
    call allsum_r8(u,size(u)) ! done now only
  end subroutine ug1_loc_to_u_add

  subroutine flip_sign_full_bse
    implicit none
    if(nq==2) then
       u(:,:,nq,:) = -u(:,:,nq,:)
    end if
  end subroutine flip_sign_full_bse

end subroutine Lsub_b

subroutine filter_participate(f)
  use jr
  implicit none
  integer iv, ic, is
  real*8 f(nc, nv, nq, nsp)

  do is=1,nsp
     do iv=1,nv
        f(:,iv,:,is) = f(:,iv,:,is)*itrue_v(iv,is)
     enddo
     do ic=1,nc
        f(ic,:,:,is) = f(ic,:,:,is)*itrue_c(ic,is)
     end do
  end do
end subroutine filter_participate
