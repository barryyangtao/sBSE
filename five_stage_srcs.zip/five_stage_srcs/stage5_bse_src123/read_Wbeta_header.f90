subroutine read_Wbeta_header
  use jr
  implicit none
  if(stoch_beta) call read_Wbeta_header_stoch
  if(det_beta)   call read_Wbeta_header_det
  if(SR_beta)    stop ' SR_beta ' ! call read_Wbeta_header_SR
end subroutine read_Wbeta_header

subroutine read_beta_Wbeta
  use jr
  implicit none
  call time_print(' pre read_Wbeta ')
  if(stoch_beta) call read_Wbeta_stoch
  if(det_beta)   call read_Wbeta_det
  if(SR_beta)    stop ' read_Wbeta_SR ' !call read_Wbeta_SR
end subroutine read_beta_Wbeta
