subroutine print_dip
  use jr
  use simple_mpi, only : rank
  implicit none
  integer iw
  real*8 accum(3)
  if(rank/=0) return
  open(36,file='dipw.txt',status='replace')
  open(360,file='accum_dipw.txt',status='replace')
  accum = 0d0
  do iw=1,nw
     write(36,*)wa(iw)*27.211396,real(dipw(iw,:))
     accum = accum + dipw(iw,:)*dw
     write(360,*)wa(iw)*27.211396,real(accum)
  enddo
  close(36)
  close(360)
end subroutine print_dip

subroutine print_exciton_w  ! I dont really use this.
  use jr
  use simple_mpi, only : rank, nodes
  use simple_mpi, only : sr_mpi_r8, sync_mpi
  implicit none
  integer ir,nds,iw,ic,ici,st
  real*8, allocatable :: f_s(:,:), f1(:,:,:)
 
  nds = max(nodes,1)

  if(rank==0) then
     open(37,file='exciton_w.txt',status='replace')
     write(37,*)nvs, ncs, nw, dw,' nvs,ncs, nw, dw '
  endif

  allocate(f_s(nvs,nq), f1(nvs, ncs,nq), stat=st)
  call check0(st,' y ')

  do iw=1,nw
     do ic=1,ncs
        ir=mod(ic-1,nds)
        ici = (ic-1)/nds + 1
        call check_le(ici,ncs_i,' ici, ncs_i ')
        
        call sync_mpi
        if(rank==ir) f_s= fflt(:,ici,:,iw)
        call sr_mpi_r8(f_s, size(f_s), ir, 0)
        call sync_mpi
        if(rank==0) f1(:,ic,:) = f_s
     enddo

     if(rank==0) then
        write(37,*)iw,iw*dw,iw*dw*27.211396,' iw, w(au) w(eV) '
        write(37,*)real(f1)
     endif
  enddo
  deallocate(f_s,f1)
  close(37)
end subroutine print_exciton_w

subroutine print_exciton_ws
  use jr
  use simple_mpi, only : rank, nodes, sr_mpi_r8, sr_mpi_scalar_r8, sync_mpi
  implicit none
  integer iws, nds, ir, st , i, icum, iwstot
  logical :: exctxt
  real*8 wprnt
  real*8, allocatable :: fws_tmp(:,:,:,:)
  exctxt = exciton_txt_printing
  nds = max(nodes,1)

  if(nwstot==0) return
  call check(mc,nc,' mc, nc ') ! important for fws size and allocation

  allocate(fws_tmp(nc,nv,nq,nsp),stat=st)
  call check0(st,' fws_tmp ')
  
  if(rank==0) then
     open(38,file='exciton.bin',form='unformatted',status='replace')
     write(38)nc, nv, nwstot, wsmin, dws, nds
     write(38)nx, ny, nz
     write(38)dx, dy, dz
  endif

  if(rank==0.and.exctxt) then
     open(380,file='exciton.txt',status='replace')
     write(380,*)nc, nv, nwstot, wsmin, dws, nds, ' nc, nv, nwstot, wsmin, dws, nds '
     write(380,*)nx, ny, nz,' nx, ny, nz '
     write(380,*)dx, dy, dz,' dx, dy, dz. Now list of  w, exciton(:,w) '
  endif

  i=0
  wprnt = -999
  do iwstot=1,nwstot
     call sync_mpi
     ir = mod(iwstot-1,nds)
     if(rank==ir) then
        i=i+1
        call check_le(i,nws,' i-nws ')
        fws_tmp = fws(:,:,:,:,i)
        wprnt = ws(i)
     endif
     call sync_mpi
     call sr_mpi_scalar_r8(wprnt,ir,0)
     call sr_mpi_r8(fws_tmp, size(fws_tmp), ir, 0)

     if(rank==0)  write(38)wprnt,fws_tmp
     if(rank==0.and.exctxt)  write(380,*)wprnt,fws_tmp
     
     if(rank==0)  write(6,*)real(Har*wprnt),real(sum(fws_tmp**2)),' i w <ff> '
     if(rank==0)  call flush(6)
  enddo
  if(rank==0)close(38)
  if(rank==0.and.exctxt) close(380)
end subroutine print_exciton_ws

