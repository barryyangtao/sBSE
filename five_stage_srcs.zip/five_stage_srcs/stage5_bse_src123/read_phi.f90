subroutine read_phieps
  use jr
  use simple_mpi, only : rank, bcast_r8
  implicit none
  integer m, st, inp, nvmax, ii, is
  real*8, allocatable :: e_big(:,:)
  
  if(nc<1) stop ' nc problem '
  allocate(ec(nc,nsp),    stat=st)
  call check0(st,' ev ')
  
  allocate(ev(nv,nsp), stat=st)
  call check0(st,' ev ')

  select case(vwtype)
  case('Wvw','W')
     usingbeta : if(using_beta) then
        rnk0 : if(rank==0) then
           if(stoch_beta) then
              inp = 30
              nvmax = nv_stoch
              write(6,*)' nvmax_s ',nvmax
              if(det_beta) call dummy_read_det
              if(SR_beta) call  dummy_read_SR
           else
              if(det_beta) then
                 inp = 31
                 nvmax = nv_D
                 write(6,*)' nvmax_d ',nvmax
              else
                 stop ' problem parameters on det_bneta, stoch_beta '
              end if
           endif
           allocate(e_big(nvmax,nsp),stat=st)
           call check0(st,' e_big ')
           call check_le(nv,nvmax,' nv, nvmax ')
           
           read(inp)m; call check(m,0,' m0 ')
           read(inp)e_big
           do is=1,nsp
              call check_decreasing_order(e_big(:,is),nvmax)
           enddo
           ev = e_big(1:nv,1:nsp)
           ! removed stop ' dont use beta till nvextra clarified there too '
           ec = 100000 ! erase
           !write(6,*)' ev ',ev ! debug, erase 
           if(rank==0) write(6,*)' max(ev) ',maxval(ev)
           read(inp)m; call check(m,1,' m1 ')     
           read(inp)
           read(inp)
           read(inp)
           read(inp)
           read(inp)
        endif rnk0
     end if usingbeta
  end select
  call read_e_p

contains
  subroutine dummy_read_det
    write(6,*)' nc= ',nc,' wf_sprt ',wf_sprt
    read(31)m; call check(m,0,' m0d ');
    read(31)
    read(31)m; call check(m,1,' m0d ');
    read(31)
    read(31)m; call check(m,2,' m2 ')     
    !if(nc>0) then
    read(31) 
    read(31)m; call check(m,3,' m3 ')     
    read(31) 
    !endif
  end subroutine dummy_read_det

  subroutine dummy_read_SR
    write(6,*)' nc= ',nc,' wf_sprt ',wf_sprt
    read(33)m; call check(m,0,' m0d ');
    read(33)
    read(33)m; call check(m,1,' m0d ');
    read(33)
    read(33)m; call check(m,2,' m2 ')     
    !if(nc>0) then
    read(33) 
    read(33)m; call check(m,3,' m3 ')     
    read(33) 
    !endif
  end subroutine dummy_read_SR

  subroutine check_decreasing_order(e_big, nvmax)
    implicit none
    integer nvmax, ie
    real*8 e_big(nvmax)
    do ie=1,nvmax-1
       if(e_big(ie)<e_big(ie+1)) stop 'e_big should be decreasing, not increasing '
    enddo
  end subroutine check_decreasing_order
  
end subroutine read_phieps


subroutine read_e_p
  use jr
  use simple_mpi, only : rank, nodes
  use simple_mpi, only : bcast_r8, scatter_r8, allsum_scalar_r8, bcast_scalar_r8, bcast_scalar_i
  use simple_mpi, only : scatterv_r8, bcast_i
  implicit none
  
  character*9 cha
  integer ns,nst,iomnwf,i,j,st, nds, is, js, iis
  integer nsp_in,ntotmax_in, ncore
  integer mx,my,mz
  integer iv,ic
  integer, allocatable :: icharge_a(:), moc_a(:) ! # of occ states above core, in each spin
  integer, allocatable :: nocc_a_old(:)
  real*8  ov, diff, focc
  real*8  tx,ty,tz
  real*8, allocatable :: eraw(:,:), p(:), eraw_transpose(:,:)

  nds = max(nodes,1)
  
  if(allocated(nocc_a))then
     allocate(nocc_a_old(size(nocc_a)), stat=st);  call check0(st)
     nocc_a_old = nocc_a
     deallocate(nocc_a)
  endif
     !stop ' nocc_a allocated too early '
  allocate(nocc_a(nsp), stat=st); call check0(st,' nocc_a ') 
  allocate(moc_a(nsp), stat=st); call check0(st,' moc_a ') 
  allocate(icharge_a(nsp),stat=st); call check0(st,' icharge_a ')

  
  select case(vwtype)
  case('W','Wvw')
     call store_nxyz_dxyz
  end select
  
  rnk0_a : if(rank==0) then
     select case(wfsrc)
     case('wf')
        open(441,file='wf.bin',form='unformatted',status='old')
     case('wfhybrid')
        open(441,file='wfhybrid.bin',form='unformatted',status='old')
     case default
        stop ' wfsrc error '
     end select
     rewind(441)
     
     !read(441)cha; write(6,*)'supposed to read nx; read: ',cha; call flush(6)
     !rewind(441)
     read(441)cha,nx; if(cha/='nx')stop ' didnt read nx from wf.bin ';write(6,*)' nx=',nx
     read(441)cha,ny; if(cha/='ny')stop ' didnt read ny from wf.bin ';write(6,*)' ny=',ny
     read(441)cha,nz; if(cha/='nz')stop ' didnt read nz from wf.bin ';write(6,*)' nz=',nz
     read(441)cha,dx; if(cha/='dx')stop ' didnt read dx from wf.bin ';write(6,*)' dx=',dx
     read(441)cha,dy; if(cha/='dy')stop ' didnt read dy from wf.bin ';write(6,*)' dy=',dy
     read(441)cha,dz; if(cha/='dz')stop ' didnt read dz from wf.bin ';write(6,*)' dz=',dz
     read(441)cha,ns; if(cha/='nsp')stop ' didnt read nsp from wf.bin ';write(6,*)' ns = ',ns
     read(441)cha,nst; if(cha/='nstates')stop ' didnt read nstates from wf.bin '; &
          write(6,*)' nstates=',nst
     read(441)cha,iomnwf; if(cha/='orbmn_wf')stop ' didnt read orbmn_wf from wf.bin '; &
          write(6,*)' orbmn_wf=',iomnwf
     
     read(441)cha,nocc_a,icharge_a(:)

     if(cha/='ihomo') then
        write(6,*)' error: read ',cha,' instead of ihomo'
        stop
     endif
     if(maxval(abs(charge_a-icharge_a))>1d-7) then
        write(6,*)' POSSIBLE ERROR: charge_a, icharge_a ',charge_a,icharge_a
        !stop
     endif

     write(6,*)' ihomo(1:nsp)=',nocc_a
     if(allocated(nocc_a_old)) then
        if(any(nocc_a/=nocc_a_old)) then
           write(6,*)' error, nocc_a ',nocc_a,' nocc_a_fromWbeta ',nocc_a_old
           stop
        endif
     end if
     
     ncore = iomnwf-1
     write(6,*)' nocc_a ',nocc_a,' ncore ',ncore,' nst ',nst
     moc_a = nocc_a - ncore
     write(6,*)' moc_a ( # occupied electrons above core) ',moc_a
     call check_lele(1,ncs,nst-maxval(moc_a),' one,ncs, nst-(nocc-ncore) ')
     
     select case(vwtype)
     case('W','Wvw')
        call check_nxyz_dxyz
     end select
        
     read(441)cha,nsp_in, ntotmax_in
     if(cha/='evls  ') then
        write(6,*)' problem. reading ',cha
        write(6,*)' rather than "evl" '
        stop
     endif
     write(6,*)' size_transpose_hevl ',nsp_in, ntotmax_in
     call flush(6)
     call check_lele(1,nv-nvextra + nc-ncextra,ntotmax_in,' 1,(nv+nc)(orig),ntotmax_in')
     call check(nsp,nsp_in,' nsp, nsp_read_hevl ')
     allocate(eraw(ntotmax_in,nsp), eraw_transpose(nsp,ntotmax_in),stat=st)
     call check0(st, ' eraw ')
     write(6,*)' shape(eraw_transpose) ',shape(eraw_transpose)
     read(441)eraw_transpose(:,:)
     eraw = transpose(eraw_transpose)
     
     !if(iomnwf/=1) then
     !   write(6,*)' problem iomnwf, should be 1 '
     !   stop
     !endif

     
     hybrid : if(wfsrc=='wfhybrid') then
        n=nx*ny*nz
        dv=dx*dy*dz
        write(6,*)' n= ',n
        allocate(dens0core(1:n), stat=st)
        call check0(st,' dens0core ')
        read(441)cha
        if(cha/='dens0core') then
           write(6,*)' wrong read from wfhybrid.bin ; should reead dens0core, instead:',cha
           stop
        endif

        dens0core=-999
        write(6,*)' cha,size(dens0core) ',cha,size(dens0core)
        read(441)dens0core
        write(6,*)' integral dens0core dv = ',sum(dens0core)*dv
     end if hybrid
     
     read(441)cha

     if(cha=='vxc0') then
        read(441)
        read(441)cha
        if(cha=='amps') then
           read(441)
           read(441)cha
        endif
     endif
     
     if(cha/='orbitals ') then
        write(6,*)' problem. reading ',cha
        write(6,*)' rather than "orbitals" '
        stop
     endif
  end if rnk0_a
 
  call bcast_scalar_i(ntotmax_in)
  if(rank/=0) then
     allocate(eraw(ntotmax_in,nsp), stat=st)
     call check0(st,' eraw ')
  endif
  call bcast_r8(eraw,size(eraw),0)

 
  ! bcast ev ec
  call bcast_scalar_r8(dx)
  call bcast_scalar_r8(dy)
  call bcast_scalar_r8(dz)
  dv=dx*dy*dz
  
  call bcast_scalar_i(nx)
  call bcast_scalar_i(ny)
  call bcast_scalar_i(nz) 

  call bcast_i(nocc_a,size(nocc_a),0)
  call bcast_i(moc_a,size(moc_a),0)
  
  ivbot = maxval(moc_a)-nv+1
  ivtop = maxval(moc_a)
  
  icbot = minval(moc_a)+1
  ictop = minval(moc_a)+nc
  if(rank==0) then
     write(6,*)' ivbot, ivtop ',ivbot,ivtop
     write(6,*)' icbot, ictop ',icbot,ictop
  endif

  
  
  n=nx*ny*nz
  n1 = n/nds
  if(n1*nds<n) n1=n1+1
  nn = n1*nds
  
  allocate(p(nn), stat=st); call check0(st,' p1 ')
  p=0d0

  allocate(pc1(n1, nsp, nc), stat=st)
  call check0(st,' pc ')
  
  allocate(pv1(n1,nsp, nv), stat=st)
  call check0(st,' pv1 ')
  if(.not.wf_sprt) stop ' problem reading'

  allocate(dens0(n, nsp), dens01(n1, nsp), stat=st)
  call check0(st,' phiocc1 ')
  dens0 = 0
  do is=1,nsp
     if(rank==0.and.wfsrc=='wfhybrid')dens0(:,is)=dens0core/nsp
  end do

  call make_participate_ev_ec
  !now read pv, pc
  
  do i=1,ictop
     do is=1,nsp
        rnk0_b : if(rank==0) then
           read(441)j,js,focc
           write(6,*)' j, js, focc ',j,js,focc; call flush(6)
           call check(is,js,' is-js in read_wf ')
           call check(i, j,' i-j in read_wf ')
           call check_r_lele(0d0,focc,1.0001d0,' 0-focc-1 ')
           if(i>moc_a(is)-nv) then  ! e.g., nocc=20, nv=4; i=17,...,20
              write(6,*)' i, moc_a(is), nv ',i,moc_a(is),nv; call flush(6)
              read(441)p(1:n)
              if(i.le.moc_a(is)) then
                 call check_r_le(0.95d0,focc,'0.95 vs focc ') 
                 dens0(:,is) = dens0(:,is) + 2d0/nsp*focc*abs(p(1:n))**2
                 call write_phieps_selected(i,is,p)
              else
                 call check_r_le(focc,0.05d0,' focc vs. 0.05 ')
              endif
           else
              read(441)
           end if

        endif rnk0_b

        
        ! dont erase, need to change, xxx
        !stop ' correct, dont erase. density xxx '

        if(i.ge.ivbot.and.i.le.ivtop) then ! put w.f. in orbitals if their occupation is 1 '
           iv=ivtop-i+1
           if(i.le.moc_a(is)) then
              if(rank==0) call check_r_le(0.95d0,focc,'0.95 vs focc ')
              call check_lele(1,iv,nv,' 1,iv,nv ')
              call check(itrue_v(iv,is),1,' itrue_iv_is , one ')
              call scatter_r8(p, pv1(:,is,iv), n1, 0)
           else
              if(rank==0) call check_r_le(focc,0.05d0,'focc vs 0.05')
              call check(itrue_v(iv,is),0,' itrue_iv_is , 0 ')
              pv1(:,is,iv) = 0
           end if
        end if

        if(i.ge.icbot.and.i.le.ictop) then
           ic=i-icbot+1
           if(i>moc_a(is)) then
              if(rank==0)call check_r_le(focc,0.05d0,'focc vs 0.05')
              call check(itrue_c(ic,is),1,' itrue_ic_is , one ')
              call scatter_r8(p, pc1(:,is,i-icbot+1), n1, 0)
           else
              if(rank==0)call check_r_le(0.95d0,focc,'0.95 vs focc ')
              call check(itrue_c(ic,is),0,' itrue_ic_is , 0 ')
              pc1(:,is,i-icbot+1) = 0
           end if
        end if
     enddo
  enddo

  do is=1,nsp
     call scatterv_r8(dens0(:,is), dens01(:,is), n1, 0)
  enddo

  ! now energies comparison

  if(using_beta.and.(vwtype=='W'.or.vwtype=='Wvw')) then
     do is=1,nsp
        !stop ' error, fix line below '
        diff = maxval(abs(ev(:,is)-eraw(moc_a(is):moc_a(is)-nv+1:-1,is)))
        if(diff>1d-6) then
           write(6,*)' ev diff ',diff
           write(6,*)' ev(1) vs. eraaw(nocc) ',ev(1,:),(eraw(moc_a(iis),iis),iis=1,nsp)
           stop ' ev problem '
        end if
     enddo
  endif
  
  call orthog_check
contains
  subroutine store_nxyz_dxyz
    mx=nx; my=ny; mz=nz
    tx=dx; ty=dy; tz=dz
  end subroutine store_nxyz_dxyz

  subroutine check_nxyz_dxyz
    call check(mx,nx,' nx from W*.bin, nx from wf.bin ')
    call check(my,ny,' ny from W*.bin, ny from wf.bin ')
    call check(mz,nz,' nz from W*.bin, nz from wf.bin ')
    call check_r(dx,tx,' tx from W*.bin, tx from wf.bin ')
    call check_r(dy,ty,' ty from W*.bin, ty from wf.bin ')
    call check_r(dz,tz,' tz from W*.bin, tz from wf.bin ')
  end subroutine check_nxyz_dxyz

  subroutine make_participate_ev_ec
    if(allocated(itrue_v))deallocate(itrue_v)
    if(allocated(itrue_c))deallocate(itrue_c)
    allocate(itrue_v(nv,nsp), stat=st); call check0(st,' itrue_v ')
    allocate(itrue_c(nc,nsp), stat=st); call check0(st,' itrue_c ')
    itrue_v = 0
    itrue_c = 0
    do is=1,nsp
       
       do i=ivbot,ivtop
          iv=ivtop-i+1
          if(i.le.moc_a(is)) then
             itrue_v(iv,is)=1
             ev(iv,is) = eraw(i,is) 
          else
             itrue_v(iv,is)=0
             ev(iv,is) =  -99999
          end if
       end do

       do i=icbot,ictop
          ic=i-icbot+1
          if(i>moc_a(is)) then
             itrue_c(ic,is) = 1
             ec(ic,is) = eraw(i,is)
          else
             itrue_c(ic,is) = 0
             ec(ic,is) = 99999 
          endif
       end do
       
    end do

    if(rank==0) then
       write(6,*)' ev, itrue_v '
       do iv=1,nv
          write(6,*)'iv, ev, itrue_v ',iv,real(ev(iv,:)),itrue_v(iv,:)
       enddo
       write(6,*)' ec first few '
       do ic=1,nc
          write(6,*)'ic, ec, itrue_c ',ic,real(ec(ic,:)),itrue_c(ic,:)
       enddo
    end if
  
    if(rank==0) then
       write(6,*)' ev(1), ev(nv) ',real(ev(1,:)),real(ev(nv,:))
       write(6,*)' ec(1), ec(nc) ',real(ec(1,:)),real(ec(nc,:))
    endif
    
  end subroutine make_participate_ev_ec

  subroutine orthog_check
    deallocate(eraw)

    !now checking
    
    if(rank==0) write(6,*)' n1 ',n1
    
    do is=1,nsp
       do i=1,nv
          do j=1,nv
             if(itrue_v(i,is)*itrue_v(j,is)==1) then
                ov = sum(pv1(:,is,i)*pv1(:,is,j))*dv
                call allsum_scalar_r8(ov)
                if(i==j) ov = ov-1d0
                if(rank==0.and.abs(ov)>1d-7) then
                   write(6,*)' problem. i,j, is, ov-delta ',i,j,is,ov
                   stop      ' phi_occ not orthogonal   '
                endif
             endif
          enddo
       enddo
    enddo
    
    !if(nc>0) then
    do is=1,nsp
       do i=1,nc
          do j=1,nc
             if(itrue_c(i,is)*itrue_c(j,is)==1) then
                ov = sum(pc1(:,is,i)*pc1(:,is,j))*dv
                call allsum_scalar_r8(ov)
                if(i==j) ov = ov-1d0
                if(abs(ov)>1d-7.and.rank==0) then
                   write(6,*)' problem. i,j,is,ov_pc1 - delta ',i,j,is,ov
                   stop ' pc1 not orthogonal '
                endif
             end if
          enddo
       enddo
    enddo
    
    do is=1,nsp
       do i=1,nc
          do j=1,nv
             if(itrue_c(i,is)*itrue_v(j,is)==1) then
                ov = sum(pc1(:,is,i)*pv1(:,is,j))*dv
                call allsum_scalar_r8(ov)
                if(abs(ov)>1d-7.and.rank==0) then
                   write(6,*)' problem. i,j,is,pc1phi ',i,j,is,ov
                   stop ' pcphi not orthogonal '
                endif
             endif
          enddo
       enddo
    enddo
  end subroutine orthog_check
end subroutine read_e_p
  
