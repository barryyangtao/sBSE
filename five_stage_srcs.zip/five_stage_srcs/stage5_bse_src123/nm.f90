subroutine set_nm
  use jr
  use simple_mpi, only : rank
  implicit none
  if(mixrep) then
     nm = n1
  else
     nm = nc
  end if
  
  if(rank==0) then
     write(6,*)' nm= ',nm
     call flush(6)
  end if
end subroutine set_nm
   
