program main
  implicit none
  call prepare_mpi
  call main_jr
  call finalize_mpi
end program main

subroutine main_jr
  use jr
  implicit none
  call time_print(' starting ')
  call read_and_process_param
  if(mixrep) stop ' not using mixrep now ' !call h_check
  call prep_rand88
  call seed_check
  call time_print(' pre-W ')
  write(6,*)' using_beta? ',using_beta ! erase
  if(using_beta) then
     call read_Wbeta_header;    call time_print(' post Wheader ')
     call modify_W_flags ! if 'vw' only
     call update_nv
  end if
  call read_phieps;           call time_print(' post phi ')
  call maps_ij_ab     ! maps i,j --> ij,  and   a,b --> ab
  call prep_grd
  call prep_nk
  call make_k2_a
  call time_print(' post grd ')
  call make_vk
  call split_vw   ! splits vw to low part, and high part where compression used.
  call set_ncomb
  call time_print(' post v, split ')
  call prep_alpha ! prepares alpha, the compression set
  call time_print(' post prep_alpha ')
  call set_nm
  call read_beta_Wbeta;      call time_print(' post read_beta_Wbeta ')
  call Wbeta_minus_vw;       call time_print(' post Wbeta_minus_vw ')
  call rho_ij_ab_prep_write_read
  if(action_rhoij=='prep')return
  if(det_beta) call W_map;   call time_print(' post W_map ')
  if(flg_band) call make_vw_diag
  call make_f0;              call time_print(' post f0 ')
  !call diag_small
  ! if diag_remove, add vwtot|i,i> analytically.  Here preps it.
  !call prep_vwdiag;          call time_print(' post vwdiag1 ')
  !call optimize_u
  !call Wbe_shift
  !call u_split
  if(nw_anlz>0.and.nsp==1) then
     stop ' need to make the read_fws routine, missing now '
     !call init_fws
     !call read_fws
     !call analyze_fws
  else
     call prep_cheby;           call time_print(' post prep_Cheby ')
     call init_fws;       
     call possibly_diag_L
     call prop_cheby
     call print_dip
     call print_exciton_w
     call print_exciton_ws 
  end if

end subroutine main_jr





  
