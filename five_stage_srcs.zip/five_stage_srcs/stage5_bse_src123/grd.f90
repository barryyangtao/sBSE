subroutine prep_nk
  use jr
  use simple_mpi, only : nodes
  implicit none
  integer nds
  ! goal: nk1, strip size, and nnk
  n8 = scale_vh**3*n
  nds = max(nodes,1)
  nk = n8
  nk1=nk/nds
  if(nk1*nds<nk) nk1=nk1+1
  nnk = nk1*nds ! may be bigger than nk
end subroutine prep_nk

subroutine prep_grd
  use jr
  use simple_mpi, only : rank, scatter_r8, nodes
  implicit none
  integer ix, iy, iz, i, id, st, nds
  real*8, allocatable :: grd(:,:)
  nds = max(nodes,1)
  
  n1 = n/nds
  if(n1*nds<n) n1=n1+1
  nn = n1*nds
  
  if(rank==0) then
     allocate(grd(nn,3), stat=st)
  else
     allocate(grd(1,3), stat=st)
  endif
  call check0(st,' grd ')
  grd =0d0
  
  allocate(grd1(n1,3), stat=st)
  call check0(st,' grd1 ')

  if(rank==0) then
     i=0
     do iz=1,nz
        do iy=1,ny
           do ix=1,nx
              i=i+1
              grd(i,:) = (/ (ix-1-nx/2d0)*dx, (iy-1-ny/2d0)*dy, (iz-1-nz/2d0)*dz /)
              !if(ix==1) grd(i,1) = 0d0 ! unerased
              !if(iy==1) grd(i,2) = 0d0
              !if(iz==1) grd(i,3) = 0d0
           enddo
        end do
     end do
     call check(i,n,' i-n ')
  endif

  do id=1,3
     call scatter_r8(grd(:, id), grd1(:, id), n1, 0)
  end do

  deallocate(grd)
end subroutine prep_grd
