subroutine vwk_fit_read
  use jr
  implicit none
  character*8 ch
  integer mx,my,mz,ik, nbig, dbl, st, jk
  real*8 ddx, ddy, ddz

  if(periodic) then
     call check(scale_vh,1,' scale_vh should be 1 for periodic ')
  else
     call check(scale_vh,2,' scale_vh should be 2 for periodic ')
  endif

  open(37,file='vwk_fit.txt',status='old')
  read(37,*)ch,mx,my,mz,ddx,ddy,ddz,dbl
  call check(nx,mx,' nx, mx vwk')
  call check(ny,my,' ny, my vwk ')
  call check(nz,mz,' nz, mz vwk ')
  call check_r(dx,ddx,' dx, ddx vwk ')
  call check_r(dy,ddy,' dy, ddy vwk ')
  call check_r(dz,ddz,' dz, ddz vwk ')
  call check(scale_vh, dbl, ' scale_vh, dbl vwk ')
  nbig= n*dbl**3

  allocate(vwk_fit(nbig), stat=st)
  call check0(st,' vwk_fit ')

  do ik=1,nbig
     read(37,*)jk,vwk_fit(ik)
     call check(ik,jk,'ik jk ')
  end do
  close(37)

  vwk_fit = vwk_fit*ampW
end subroutine vwk_fit_read
