subroutine Lsub(f, u)
  use jr
  implicit none
  real*8 f(*), u(*)
  if(mixrep) then
     stop ' removed Lsub_g '
     !call Lsub_g(f, u)
  else
     call Lsub_b(f, u)
  end if
end subroutine Lsub
