subroutine rho_ij_ab_bi_read
  implicit none
  call rhoij1_read;   call time_print(' post rhoij_read ')
  call rhoab1_read;   call time_print(' post rhoab_read ')
end subroutine rho_ij_ab_bi_read

subroutine rhoij1_read
  use jr
  use simple_mpi, only : nodes, rank, sync_mpi
  implicit none
  character(len=1024) char_rank,name
  integer nds, ip, st
  nds = max(nodes,1)
  ip=41

  call ensure_directory_rho_storage_exists

  call open_old_rhoij_file

  call rhoij1_read_header
  call rhoij1_read_in

  close(ip)
  
contains
  subroutine ensure_directory_rho_storage_exists
    logical dir_exists, dir_verify
    integer ir !
    
    do ir=0,nds-1 ! this loop ensures that if each core is
       !            connected to a different disk, it will be opened
           
       call sync_mpi
       if(rank==ir) then
          inquire(file='./'//trim(adjustl(scratch_dir)), exist=dir_exists)
          if(.not.dir_exists) stop ' scratch directory doesnt exist '
       end if
    end do
    call sync_mpi


  end subroutine ensure_directory_rho_storage_exists

  subroutine open_old_rhoij_file
    call cnvrt_number_1K_string(rank,char_rank)
    name = trim(adjustl(scratch_dir))//'/rhoij.'//trim(adjustl(char_rank))//'.bin'
    open(ip,file=trim(adjustl(name)),form='unformatted',status='old')
  end subroutine open_old_rhoij_file

  subroutine rhoij1_read_header
    integer mx,my,mz,mds,mv,mc,malpha,mcomb,mcomb1,mij,msp
    real*8  tx,ty,tz
    read(ip)mx,my,mz,tx,ty,tz,mds,mv,mc,malpha,mcomb,mcomb1,mij,msp
    call check(mx,nx,' mx-nx in rhoij ')
    call check(my,ny,' my-ny in rhoij ')
    call check(mz,nz,' mz-nz in rhoij ')
    call check_r(tx,dx,' tx-dx in rhoij ')
    call check_r(ty,dy,' ty-dy in rhoij ')
    call check_r(tz,dz,' tz-dz in rhoij ')
    call check(mds,nds,' mds, nds in rhoij ')
    call check(mv,nv_band,' mv-nv_band in rhoij ')
    call check(mc,nc_band,' mc-nc_band in rhoij ')
    call check(malpha,nalpha,' malpha-nalpha in rhoij ')
    call check(mcomb,ncomb,' mcomb-ncomb in rhoij ')
    call check(mcomb1,ncomb1,' mcomb1-ncomb1 in rhoij ')
    call check(mij,nij,' mij-nij in rhoij ')
    call check(msp,nsp,' msp, nsp in rhoij')
  end subroutine rhoij1_read_header

  subroutine rhoij1_read_in
    if(allocated(rhoij1)) deallocate(rhoij1)
    allocate(rhoij1(ncomb1,nij,nsp), stat=st)
    call check0(st,' rhoij1 read ')
    read(ip)rhoij1
    call flush(ip)
  end subroutine rhoij1_read_in
end subroutine rhoij1_read

subroutine rhoab1_read
  use jr
  use simple_mpi, only : nodes, rank, sync_mpi
  implicit none
  character(len=1024) char_rank,name
  integer nds, ip, st
  nds = max(nodes,1)
  ip=41

  call ensure_directory_rho_storage_exists

  call open_old_rhoab_file

  call rhoab1_read_header
  call rhoab1_read_in
  close(ip)
  
contains
  subroutine ensure_directory_rho_storage_exists
    logical dir_exists, dir_verify
    integer ir !
    
    do ir=0,nds-1 ! this loop ensures that if each core is
       !            connected to a different disk, it will be open

       call sync_mpi
       if(rank==ir) then
          inquire(file='./'//trim(adjustl(scratch_dir)), exist=dir_exists)
          if(.not.dir_exists) stop ' scratch directory doesnt exist '
       end if
    enddo
    call sync_mpi

  end subroutine ensure_directory_rho_storage_exists

  subroutine open_old_rhoab_file
    call cnvrt_number_1K_string(rank,char_rank)
    name = trim(adjustl(scratch_dir))//'/rhoab.'//trim(adjustl(char_rank))//'.bin'
    open(ip,file=trim(adjustl(name)),form='unformatted',status='old')
  end subroutine open_old_rhoab_file

  subroutine rhoab1_read_header
    integer mx,my,mz,mds,mv,mc,malpha,mcomb,mcomb1,mab,msp
    real*8  tx,ty,tz
    read(ip)mx,my,mz,tx,ty,tz,mds,mv,mc,malpha,mcomb,mcomb1,mab,msp
    call check(mx,nx,' mx-nx in rhoab ')
    call check(my,ny,' my-ny in rhoab ')
    call check(mz,nz,' mz-nz in rhoab ')
    call check_r(tx,dx,' tx-dx in rhoab ')
    call check_r(ty,dy,' ty-dy in rhoab ')
    call check_r(tz,dz,' tz-dz in rhoab ')
    call check(mds,nds,' mds, nds in rhoab ')
    call check(mv,nv_band,' mv-nv_band in rhoab ')
    call check(mc,nc_band,' mc-nc_band in rhoab ')
    call check(malpha,nalpha,' malpha-nalpha in rhoab ')
    call check(mcomb,ncomb,' mcomb-ncomb in rhoab ')
    call check(mcomb1,ncomb1,' mcomb1-ncomb1 in rhoab ')
    call check(mab,nab,' mab-nab in rhoab ')
    call check(msp,nsp,' msp, nsp in rhoab ')
  end subroutine rhoab1_read_header

  subroutine rhoab1_read_in
    if(allocated(rhoab1)) deallocate(rhoab1)
    allocate(rhoab1(ncomb1,nab,nsp), stat=st)
    call check0(st,' rhoab1 read ')
    read(ip)rhoab1
    call flush(ip)
  end subroutine rhoab1_read_in
end subroutine rhoab1_read

subroutine rhobi1_read
  use jr
  use simple_mpi, only : nodes, rank, sync_mpi
  implicit none
  character(len=1024) char_rank,name
  integer nds, ip, st
  nds = max(nodes,1)
  ip=41

  call ensure_directory_rho_storage_exists

  call open_old_rhobi_file

  call rhobi1_read_header
  call rhobi1_read_in
  close(ip)
  
contains
  subroutine ensure_directory_rho_storage_exists
    logical dir_exists, dir_verify
    integer ir !
    
    do ir=0,nds-1 ! this loop ensures that if each core is
       !            connected to a different disk, it will be open

       call sync_mpi
       if(rank==ir) then
          inquire(file='./'//trim(adjustl(scratch_dir)), exist=dir_exists)
          if(.not.dir_exists) stop ' scratch directory doesnt exist '
       end if
    enddo
    call sync_mpi

  end subroutine ensure_directory_rho_storage_exists

  subroutine open_old_rhobi_file
    call cnvrt_number_1K_string(rank,char_rank)
    name = trim(adjustl(scratch_dir))//'/rhobi.'//trim(adjustl(char_rank))//'.bin'
    open(ip,file=trim(adjustl(name)),form='unformatted',status='old')
  end subroutine open_old_rhobi_file

  subroutine rhobi1_read_header
    integer mx,my,mz,mds,mv,mc,malpha,mcomb,mcomb1,msp
    real*8  tx,ty,tz
    read(ip)mx,my,mz,tx,ty,tz,mds,mv,mc,malpha,mcomb,mcomb1,msp
    call check(mx,nx,' mx-nx in rhobi ')
    call check(my,ny,' my-ny in rhobi ')
    call check(mz,nz,' mz-nz in rhobi ')
    call check_r(tx,dx,' tx-dx in rhobi ')
    call check_r(ty,dy,' ty-dy in rhobi ')
    call check_r(tz,dz,' tz-dz in rhobi ')
    call check(mds,nds,' mds, nds in rhobi ')
    call check(mv,nv_band,' mv-nvband in rhobi ')
    call check(mc,nc_band,' mc-ncband in rhobi ')
    call check(malpha,nalpha,' malpha-nalpha in rhobi ')
    call check(mcomb,ncomb,' mcomb-ncomb in rhobi ')
    call check(mcomb1,ncomb1,' mcomb1-ncomb1 in rhobi ')
    call check(msp,nsp,' msp, nsp in rhobi')
  end subroutine rhobi1_read_header

  subroutine rhobi1_read_in
    if(allocated(rhobi1)) deallocate(rhobi1)
    if(nc_band>0.and.nv_band>0) then
       allocate(rhobi1(ncomb1,nc_band, nv_band, nsp), stat=st)
       call check0(st,' rhobi1 read ')
       read(ip)rhobi1
       call flush(ip)
    endif
  end subroutine rhobi1_read_in
end subroutine rhobi1_read
