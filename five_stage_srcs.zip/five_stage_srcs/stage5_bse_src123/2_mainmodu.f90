module mainparam
  use jr, only : nx,ny,nz,dx,dy,dz,n
  implicit none
  save
  real*8, parameter :: ekcut=100 ! leave it high
end module mainparam
