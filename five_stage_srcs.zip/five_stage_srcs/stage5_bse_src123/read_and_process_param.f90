subroutine read_and_process_param
  use jr
  use jr, only : fix => igv_igc_sampling_fixed
  use jr, only : acoverage=>alpha_coverage
  use jr, only : actionij =>action_rhoij
  use jr, only : scratch=>scratch_dir
  use simple_mpi, only : nodes, rank, bcast_r8, bcast_i, sync_mpi
  implicit none
  integer nds, st
  real*8 echeby
  nds = max(nodes,1)
  call read_pol
  call read_main
  call process_param
contains
  subroutine read_pol
    open(7,file='polarization.inp',status='old')
    call fetch_i(ipol,   'ipol     ',7)
    close(7)
  end subroutine read_pol

  subroutine read_main
    open(7,file='jr_cheby.inp',status='old')
    call fetch_L(wf_sprt,  'wf_sprt  ',7) ! wf separate read
    call fetch_r(scissors, 'scissors ',7)
    call fetch_i(nbe_stoch,'nbstoch  ',7)
    call fetch_L(SR_beta,  'SR       ',7)
    call fetch_ch(vwtype,  'vwtype   ',7)
    call fetch_ch(offdiag, 'OffDiag  ',7)
    !call fetch_i(neta,     'neta     ',7)
    !call fetch_r(factor_shift,'fctrshft ',7)
    call fetch_r(kcut_vw,  'kcut_vw  ',7)
    call fetch_L(flg_rhoij,'flgijk   ',7)
    call fetch_i(nalpha,   'nalpha   ',7)
    call fetch_r(acoverage,'acoverage',7)
    call fetch_i(ngam_smpl,'ngam_smpl',7)
    call fetch_i(ngam_vw,  'ngam_vw  ',7)
    call fetch_L(fix,      'smpl_fix ',7)
    call fetch_r(gamW,     'gammaW   ',7)
    call fetch_r(ampW,     'ampW     ',7)
    call fetch_r(ampbare,  'ampbare  ',7)
    call fetch_L(periodic, 'periodic ',7)
    call fetch_r(pot_shft, 'pot_shft ',7)
    call fetch_r(kappa,    'kappa    ',7)
    call fetch_L(tddft_flg,'tddft_flg',7)
    call fetch_i(nv,       'nv       ',7)
    call fetch_i(nc,       'nc       ',7)
    call fetch_i(nsp,      'nsp      ',7)
    call fetch_i(nv_band,  'nv_band  ',7)
    call fetch_i(nc_band,  'nc_band  ',7)
    select case(nsp);
    case(1)
       call fetch_r(charge,   'charge   ',7)
    case(2)
       call fetch_r(chargeU,  'chargeU  ',7)
       call fetch_r(chargeD,  'chargeD  ',7)
       charge = chargeU+chargeD
    case default
       stop ' nsp should be 1 or 2 '
    end select
    !call fetch_i(nvdiff,   'nvdiff   ',7)
    call fetch_ch(wfsrc,   'wfsrc    ',7)
    !call fetch_i(nv_vw,    'nv_vw    ',7)
    call fetch_i(nvs,      'nvsamp   ',7)
    call fetch_i(ncs,      'ncsamp   ',7)
    call fetch_r(wmax,     'wmax(eV) ',7); wmax = wmax/Har
    call fetch_i(nw,       'nw       ',7)
    call fetch_r(fctrchby, 'fctrchby ',7)
    call fetch_r(echeby,   'echeby   ',7)
    call fetch_i(nwstot,   'nwsamp   ',7)
    call check_le(nwstot,nw,' nws, nw  ')
    call fetch_r(wsmin,    'wsmin(eV) ',7); wsmin = wsmin/Har
    call fetch_r(wsmax,    'wsmax(eV) ',7); wsmax = wsmax/Har
    call fetch_i(nw_anlz,  'nw_anlz   ',7)

    if(flg_rhoij) call read_status
  end subroutine read_main

  subroutine read_status
    open(60,file='status.inp',status='old')
    call fetch_ch(actionij,'actionij ',60)
    close(60)
  end subroutine read_status
  
  subroutine process_param
    call check_lele(1,nsp,2,' one-nsp-two ')

    allocate(charge_a(nsp), stat=st); call check0(st,' charge_a ')
    select case(nsp)
    case(1)
       call check_int(-charge/2d0,' -charge/2 ')
       nvextra = nint(-charge/2d0)
       ncextra = -nvextra
       charge_a(1) = charge
    case(2)
       call check_int(-chargeU,' -chargeU ')
       call check_int(-chargeD,' -chargeD ')
       nvextra =  max(nint(-chargeU),nint(-chargeD)) ! cU=-2,cD=1 --> nvxtra=max(2,-1)=2
       ncextra = -min(nint(-chargeU),nint(-chargeD)) !                ncxtra=-min(2,-1)=-(-1)=1
       charge_a(:) = (/ chargeU, chargeD /)
    end select

    nv = nv+nvextra
    nc = nc+ncextra
    if(rank==0) then
       write(6,*)' nvextra, ncextra ',nvextra,ncextra
       write(6,*)' possibly updated nv, nc: ',nv,nc
    endif
       
    if(nw_anlz>0) then
       if(rank==0)write(6,*)' reading wanlz(ev) '
       allocate(w_anlz(nw_anlz), stat=st)
       call check0(st,' w_anlz ')
       read(7,*) w_anlz(:)
       if(rank==0) write(6,*)'= ',w_anlz
       w_anlz = w_anlz/Har
    end if
    
    if(nc>0) call check_le(ncs,nc,' ncs, nc ')
    mc = max(nc,ncs)
    
    if(nc>0) then; mixrep=.false.;
    else; mixrep=.true.; 
    endif
    
    select case(wfsrc)
    case('wf','wfhybrid')
    case default
       stop ' error, wfsrc should be wf or wfhybrid ' 
    end select
    
    if(vwtype.ne.'W'.and.vwtype.ne.'Wvw') then
       if(rank==0) write(6,*)' modifying nbe_stoch to 0 '
       nbe_stoch = 0
    endif

    if(echeby<0) then
       simple_cheby = .true.
       ncheby = nint(-echeby)
    else
       simple_cheby= .false.
       ewdth = echeby
    end if
    

    nvs = min(nvs,nv)
    if(abs(kappa*(kappa-1)*(kappa-2))>1d-8) &
         stop ' kappa should be 0, 1, 2 '
    
    nv_vw = nv   ! new
    if(nv_vw>nv) then
       if(rank==0) write(6,*)' reducing nv_vw=',nv_vw,' to be ',nv
       nv_vw = nv
    end if
    
    if(SR_beta) then
       nv=0
       if(rank==0) write(6,*)' using correlated sampling, nv to be updated to nvkeep later '
    endif
    
    call check_lele(1,ipol,3,' ipol ')
    call check_lele(1,nsp,2, ' nsp  ')
    
    if(periodic) then;     scale_vh=1
    else;      scale_vh=2
    end if
    
    nbe_SR = nbe_stoch
    select case(nbe_stoch)
    case(1:)
       stoch_beta = .true.
       det_beta=.false.
       using_beta = .true.
    case(0)
       det_beta = .false.
       stoch_beta = .false.
       SR_beta    = .false. ! override
       using_beta = .false.
    case(-1);
       det_beta = .true.
       stoch_beta = .false.
       SR_beta    = .false. ! override
       using_beta = .true.
    case default; stop  ' nbe_stoch ' 
    end select
    
    if(stoch_beta.and.SR_beta) det_beta = .true.
    
    if(vwtype=='W'.and.stoch_beta) stop ' dont use vwtype=W with stoch_beta '
    ! reason is that if there's deterministic beta, we print (v+Wpol)|beta>
    ! Otherwise, for stochastic beta, we print only Wpol|beta>, so we need to put the"v"
    ! factor, which we do by Wpol-vwpol+vwtot where vwtot=vwpol+v
    
    if(rank==0) then
       write(6,*)'   det_beta = ',  det_beta
       write(6,*)' stoch_beta = ',stoch_beta
       write(6,*)'    SR_beta = ',   SR_beta
    endif
    
    select case(vwtype)
    case('W','Wvw','vw','vwk','rpa','RPA','Rpa')
    case default; stop 'vwtype has wrong value '
    end select

    nq=-99
    select case(offdiag)
    case('TDA'); nq=1
    case('vwoffdiag'); nq=2
    case default; stop ' error: presently offdiag should be  "TDA" or "vwoffdiag"; stopping '
    end select
       
    !select case(neta)
    !case(-1)
    !   vw_stoch=.false.
    !case(0:)
    vw_stoch=.true.
    !case default
    !   stop ' error, neta  '
    !end select
    
    if(ngam_vw>0.and.ngam_smpl>0) then
       flg_gamma=.true.
       ! make ngam_vw commenusrate with # of cores
       ngam_vw_core = ngam_vw/nds
       if(ngam_vw_core*nds<ngam_vw) then
          ngam_vw_core = ngam_vw_core+1
          ngam_vw = ngam_vw_core*nds
       endif
    else
       flg_gamma=.false.
    endif

    if(.not.flg_gamma.and..not.flg_rhoij.and.(vwtype=='Www'.or.vwtype=='vw')) &
         stop ' need either gamma and/or ijk to run vw '

    if(nalpha==0) stop ' need to use alpha compression now '
    
    if(gamW<0) then
       use_vwk_fit=.true.
       gamW = 0 ! LDA
    else
       use_vwk_fit = .false.
    end if

    call process_ncs
    
    if(nw_anlz.le.0) then
       call set_w_ws
    endif
    
    select case(actionij)
    case('prep','preprun','prepwriterun','read'); continue
    case default; stop ' action_rhoij is wrong '
    end select

    flg_band=.false.
    if(nv_band==-1.or.nv_band>nv)nv_band=nv
    if(nc_band==-1.or.nc_band>nc)nc_band=nc
    
    if(nv_band<nv) flg_band = .true.
    if(nc_band<nc) flg_band = .true.

    if(rank==0) then
       write(6,*)' flg_band,nv_band,nc_band (possibly modified) ',flg_band,nv_band,nc_band
       write(6,*)
    endif

    if(flg_band) then
       select case(vwtype)
       case('Wvw','vw','vwk','rpa','RPA','Rpa')
       case('W'); stop 'vwtype is W but using flg_band, so error '
       case default; stop 'vwtype has wrong value, error '
       end select
    end if
  end subroutine process_param

  subroutine process_ncs
    use jr
    use simple_mpi, only : nodes
    implicit none
    integer nds
    nds = max(nodes,1)
    ncs_i = ncs/nds
    if(ncs_i*nds<ncs)ncs_i = ncs_i + 1
  end subroutine process_ncs

  subroutine set_w_ws
    use simple_mpi, only : bcast_scalar_i, bcast_scalar_r8,allsum_i,allsum_scalar_i
    implicit none
    integer  iw, iws, iwstot, st, nws_sum, ir
    integer iwmin, iwmax, iwskip
    real*8 tmp
  
    allocate(wa(nw), wg_w(nw), stat=st)
    call check0(st,' wa ')
    
    dw = wmax/max(nw,1)
    wa =(/(dw*iw, iw=1,nw)/)
    call bcast_r8(wa,size(wa),0)
    
    if(nwstot<1) return
    if(wsmax<wsmin) then
       tmp=wsmax
       wsmax=wsmin
       wsmin=tmp
    endif
    
    iwmin= product(minloc(abs(wsmin-wa(:))))
    iwmax= product(minloc(abs(wsmax-wa(:))))
    iwskip = (iwmax-iwmin)/max(nwstot-1,1)
    nwstot = (iwmax-iwmin)/iwskip + 1
    if((nwstot-1)*iwskip<iwmax-iwmin) then
       nwstot = nwstot+1
       call check_le(iwmax-iwmin,(nwstot-1)*iwskip,' iwmnnws ')
    endif
    
    iwmax = iwmin + (nwstot-1)*iwskip
    call bcast_scalar_i(iwmin)
    call bcast_scalar_i(iwmax)
    call bcast_scalar_i(nwstot)
    call bcast_scalar_i(iwskip)

    wsmin = wa(iwmin)
    wsmax = wa(iwmax)
    dws = (wsmax-wsmin)/(nwstot-1)
    
    allocate(wstot(nwstot), stat=st)
    call check0(st,' wstot 7 ')
    
    wstot    =  wa(iwmin:iwmax:iwskip)

    if(rank==0) then
       write(6,*)' modified sampling parameters : '
       write(6,*)' wsmin,wsmax dws nwstot iwskip  ',&
       real(wsmin*Har),real(wsmax*Har),real(dws*Har),nwstot,iwskip
    end if

    iws = 0
    iwstot = 0
    do iw=iwmin,iwmax,iwskip
       iwstot = iwstot+1
       ir = mod(iwstot-1,nds)
       if(ir==rank) iws=iws+1
    end do
    nws = iws
    
    allocate(mapiws(nws), ws(nws), stat=st)
    call check0(st,' mapiws, ws ')

    iws=0
    iwstot = 0
    do iw=iwmin,iwmax,iwskip
       iwstot = iwstot+1
       ir = mod(iwstot-1,nds)
       if(ir==rank) then
          iws=iws+1
          mapiws(iws) = iw
          ws(iws)=wa(iw)
       end if
    end do

    if(rank==0) write(6,*)' ws(1), ws(nws) (rank=0) ',real(ws(1)), real(ws(nws))
    
    nws_sum = nws
    call allsum_scalar_i(nws_sum)
    call check(nws_sum,nwstot,' smapnws ')
  end subroutine set_w_ws

end subroutine read_and_process_param
