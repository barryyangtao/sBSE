subroutine calc_res(i,uin)
  use jr
  use simple_mpi, only : rank, sync_mpi
  implicit none
  integer i, iv, id, st
  real*8 uin(nm, nv, nq, nsp)
  real*8, allocatable :: u(:,:,:,:)
  allocate(u(nm, nv, nq, nsp), stat=st)
  call check0(st,' u_calc_res ')
  u=uin
  if(nq==2) then
     u(:,:,nq,:)=-u(:,:,nq,:)
  endif

  if(i==0) f0_sq = sum(u**2)
  
  if(mixrep) then
     stop ' dont use mixrep '
     !do id=1,3
     !   t = sum(sum(pv1*u,dim=2)*grd1(:,id))*dv
     !   call allsum_scalar_r8(t)
     !   res(i,id) = t
     !end do
  else
     do id=1,3
        res(i,id) = sum(fdb(:,:,:,:,id)*u(:,:,:,:)) !*dv
     enddo
  endif
  
  if(i==0.and.rank==0) then
     write(6,*)' res(i=0)   ',real(res(i,:))
     call flush(6)
     !write(6,*)' fdb(:,:,1) ',real(fdb(:,:,1))
     !write(6,*)' u          ',real(u)
  endif

  call sync_mpi
  
  if(sum(u**2)>1000000*f0_sq) then
     if(rank==0) then
        write(6,*)' problem sum(u**2) > 1M* sum(u0**2) ',real(sum(u**2)),real(f0_sq)
        call flush(6)
        stop
     endif
  endif
  
end subroutine calc_res

