! loc means local, i.e., from relevant core (could be present core).

subroutine rhoab1_make
  use jr
  use simple_mpi, only : rank, nodes, gather_r8
  use simple_mpi, only : bcast_r8, scatter_c8, bcast_scalar_general_i
  implicit none
  integer ac, bc, ar, br, bcloc, ncloc, ncloc_of_br
  integer i, ab, st, nds, is
  integer, allocatable :: map_ac(:)
  real*8, allocatable  :: pc_loc(:,:), p(:)
  real*8, allocatable  :: dns(:), dnsb(:)
  complex*16, allocatable :: uk(:)
  complex(kind=kind_gamma_c), allocatable  :: uklow(:), ukhigh(:), ukalpha(:), ukglue(:)
  complex(kind=kind_gamma_c), allocatable  :: cp(:)
  complex(kind=kind_gamma_c), allocatable  :: rhoab_loc(:,:)
  
  ! First check that you need to be here
  if(.not.flg_rhoij) return

  if(nc_band==0) return
  select case(vwtype)
  case('W','rpa','Rpa','RPA'); return
  case('Wvw','vw','vwk'); continue
  case default; stop ' vwtype_vwab '
  end select
  
  !if(diag_remove)stop ' dont use diag_remove '
  
  call time_print(' entering rhoab ')

  ! Now start
  nds=max(nodes,1)

  ! Assign the phi states, to the nodes, phi1 to node 0, phi2 to node 1, etc.
  ! For this you need maps.

  call make_map_ac
  call check(maxval(abmap), nab,' maxval_abmap nab ')
  
  ! now finished maps, allocate and gather the w.f.

  if(allocated(rhoab1)) deallocate(rhoab1)
  allocate(rhoab1(ncomb1,nab,nsp), stat=st)
  call check0(st,' rhoab1 ')

  allocate(rhoab_loc(ncomb, ncloc), stat=st)
  call check0(st,' rhoab_loc ')
  
  allocate(pc_loc(n,ncloc), p(nn), stat=st)
  call check0(st,' pc_loc ')

  allocate(dns(n), dnsb(nk), uk(nk), stat=st) 
  call check0(st,' dns ')

  if(flg_gamma) then
     call check(ncomb, nk_low,' ncomb, nk_low so no gluing ')
  else
     call check(ncomb, nk_low+ nalpha,' ncomb, ncw+low+n_alpha ')
  endif
     
  allocate(ukhigh(nk_high), uklow(nk_low), ukalpha(nalpha), ukglue(ncomb), cp(nncomb), stat=st)
  call check0(st,' uksplit ')
  cp = 0 ! important for scatter
  
  ! main loop, bcast, fft, and dot product.  But first allocate
  spnloop: do is=1,nsp
     call gather_pc_loc
     
     if(allocated(p)) deallocate(p)
     allocate(p(n), stat=st)
     call check0(st,' p ')
     
     i=0
     mainloop : do ac=1,nc_band
        ! first send the ac'th w.f. from its rank
        ar = mod(ac-1,nds)
        if(rank==ar)then
           i=i+1
           p=pc_loc(:,i)
        endif
        call bcast_r8(p, size(p), ar)
        ! now loop over all exisiting w.f.
        do bcloc=1,ncloc
           bc= map_ac(bcloc)
           ab= abmap(ac,bc)
           dns = p*pc_loc(:,bcloc) ! phi(:,ac)*phi(:,bc)
           call broaden_dns_to_dnsb ! puts dns on bigger grid
           call fft_dnsb_to_uk   ! clear by name
           call scale_left_uk   ! uk--> const*sign(sqrt(vwktot),vwktot)*uk
           call split_uk         ! splits to uklow, ukhigh
           if(.not.flg_gamma) call compress_kind_g_c(ukhigh, ukalpha) ! makes uk_alpha
           call glue_uklow_ukalpha ! makes ukglue
           call assign_ukglue_to_rhoab_loc
        enddo
        
        ! now bcast the calculated rhoab
        brloop : do br=0,nds-1
           ncloc_of_br= -99
           if(br==rank) ncloc_of_br= ncloc
           call bcast_scalar_general_i(ncloc_of_br, br)
           
           bcloc_loop : do bcloc =1,ncloc_of_br
              bc = -99
              ab = -99
              if(br==rank) then
                 bc= map_ac(bcloc)
                 ab= abmap(ac,bc)
                 !cp(1:ncomb) = ukglue(:) mistake
                 cp(1:ncomb) = rhoab_loc(:,bcloc) 
              endif
              call bcast_scalar_general_i(ab, br)
              
              call scatter_c8(cp, rhoab1(:,ab,is), ncomb1, br)
           end do bcloc_loop
        end do brloop
     end do mainloop
  end do spnloop
  
  select case(action_rhoij)
  case('prep')
     !included already?  call rhoab_write
  end select
  
  call time_print(' post rhoab ')
contains
  
  subroutine make_map_ac
    i=0
    do ac=1,nc_band
       ar=mod(ac-1,nds)
       if(rank==ar)i=i+1
    enddo
    
    ncloc = i
    allocate(map_ac(ncloc), stat=st)
    call check0(st,' map_ac ')
    
    i=0
    do ac=1,nc_band
       ar=mod(ac-1,nds)
       if(rank==ar) then
          i=i+1
          map_ac(i) = ac
       endif
    enddo
  end subroutine make_map_ac

  subroutine gather_pc_loc

    real*8, allocatable :: pp(:)
    allocate(pp(nn), stat=st)
    call check0(st,' pp ')

    i=0
    do ac=1,nc_band 
       ar = mod(ac-1,nds)
       call gather_r8(pc1(:,is,ac), pp, n1, ar)
       if(rank==ar) then
          i=i+1
          pc_loc(:,i) = pp(1:n)
       endif
    end do
    
    call time_print('  rhoab post-gather ')
  end subroutine gather_pc_loc
    
  subroutine fft_dnsb_to_uk
    uk = dnsb
    call fft3d_forward(nx*scale_vh, ny*scale_vh, nz*scale_vh, uk, uk)
  end subroutine fft_dnsb_to_uk

  subroutine scale_left_uk
    call check(size(uk), size(vwktot),' size_u_vwktot ')
    uk = uk * sign(sqrt(abs(vwktot(:))),vwktot(:))*  sqrt(dv/dble(nk))
  end subroutine scale_left_uk

  subroutine split_uk ! splits to uklow, ukhigh
    uklow  = uk(map_vwklow(:))
    ukhigh = uk(map_vwkhigh(:))
  end subroutine split_uk

  subroutine glue_uklow_ukalpha
    ukglue(1:size(uklow))= uklow
    if(.not.flg_gamma) ukglue(size(uklow)+1:size(uklow)+nalpha) = ukalpha

  end subroutine glue_uklow_ukalpha

  subroutine assign_ukglue_to_rhoab_loc
    rhoab_loc(:,bcloc) = ukglue(:)
  end subroutine assign_ukglue_to_rhoab_loc
  
  subroutine broaden_dns_to_dnsb
    if(mod(nx ,2)/=0.or.mod(ny ,2)/=0.or.mod(nz ,2)/=0) stop ' make nx ,ny ,nz  all even '

    select case(scale_vh)
    case(2); call dns_to_dnsb(dns,dnsb)
    case(1); dnsb= dns
    case default; stop 'scale_vh problem '
    end select
  end subroutine broaden_dns_to_dnsb

  subroutine dns_to_dnsb(dns,dnsb)
    real*8  dns( nx, ny, nz)
    real*8  dnsb(nx*2,ny*2,nz*2)
    integer mx,my,mz,px,py,pz
    call check(scale_vh, 2, 'scale_vh vs. 2 ')

    dnsb = 0d0
    
    mx= 1 + nx - nx/2
    px=     nx + nx/2

    my= 1 + ny - ny/2
    py=     ny + ny/2

    mz= 1 + nz - nz/2
    pz=     nz + nz/2

    dnsb(mx:px,my:py,mz:pz) = dns
  end subroutine dns_to_dnsb

  subroutine debug
    use simple_mpi, only : allsum_scalar_r8
    real*8 sum_check
    sum_check = sum(abs(rhoab1**2))
    call allsum_scalar_r8(sum_check)
    if(rank==0) write(6,*)' rhoab1_norm2 ',sum_check
  end subroutine debug

end subroutine rhoab1_make

