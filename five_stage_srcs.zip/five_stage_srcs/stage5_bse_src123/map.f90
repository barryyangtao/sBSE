subroutine maps_ij_ab
  implicit none
  call imap_jmap_ijmap
  call amap_bmap_abmap
end subroutine maps_ij_ab
  
subroutine imap_jmap_ijmap
  use jr
  implicit none
  integer i, j, ij, st

  if(allocated(imap)) stop ' imap already allocated '
  if(allocated(jmap)) stop ' jmap already allocated '
  !write(6,*)' nv, nij ',nv,nij; call flush(6)

  nij = (nv_band*(nv_band+1))/2
  if(nv_band>0) then
     allocate(imap(nij), jmap(nij), ijmap(nv_band, nv_band), stat=st)
     call check0(st,' ijmap ')
  end if
     
  ij=0
  do i=1,nv_band
     do j=1,i
        ij=ij+1
        imap(ij) = i
        jmap(ij) = j
        ijmap(i,j) = ij
        ijmap(j,i) = ij
     enddo
  enddo
  call check(ij,nij,' ij, nij ')
end subroutine imap_jmap_ijmap

subroutine amap_bmap_abmap
  use jr
  implicit none
  integer a, b, ab, st

  nab = (nc_band*(nc_band+1))/2
  if(nc_band>0) then
     allocate(amap(nab), bmap(nab), abmap(nc_band, nc_band), stat=st)
     call check0(st,' abmap ')
  end if
     
  ab=0
  do a=1,nc_band
     do b=1,a
        ab=ab+1
        amap(ab) = a
        bmap(ab) = b
        abmap(a,b) = ab
        abmap(b,a) = ab
     enddo
  enddo
  call check(ab,nab,' ab, nab ')
end subroutine amap_bmap_abmap
