subroutine rho_ij_ab_prep_write_read
  use jr
  implicit none
  if(flg_rhoij)  then
     select case(action_rhoij)
     case('prep','prepwriterun')
        call rhoij1_make
        call rhoab1_make
        call rhobi1_make
        call rho_ij_ab_bi_write
     case('preprun')
        call rhoij1_make
        call rhoab1_make
        call rhobi1_make
        return
     case('read')
        call rho_ij_ab_bi_read
     case default;
        stop ' action_rhoij '
     end select

     !if(flg_band) then
        !call rhoij1_band_restrict
        !call rhoab1_band_restrict
        !call rhobi1_band_restrict
     !end if
  end if
end subroutine rho_ij_ab_prep_write_read


