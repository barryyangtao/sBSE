subroutine minusWf_det(fg, ug,is)
  use jr, only : n1, nv, nbe_D, Wbe_D, Windx, nsp
  use simple_mpi, only : nodes, rank
  implicit none
  integer i,j,ib,st,is
  real*8 fg(n1,nv), ug(n1,nv)
  real*8, allocatable :: Wf(:,:)

  allocate(Wf(n1,nv),stat=st)
  call check0(st,' Wf ')
  
  Wf = 0d0

  do ib=1,nbe_D
     i=Windx(1,ib)
     j=Windx(2,ib)
     Wf(:,i) = Wf(:,i) + Wbe_D(:,is,ib)*fg(:,j)
     if(i/=j) &
          Wf(:,j) = Wf(:,j) + Wbe_D(:,is,ib)*fg(:,i)

     !call debug_Wf_det
  enddo
  
  do i=1,nv
     ug(:,i) = ug(:,i) - Wf(:,i)
  enddo
  deallocate(Wf)

end subroutine minusWf_det



