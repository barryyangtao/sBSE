! loc means local, i.e., from relevant core (could be present core).

subroutine rhobi1_make
  use jr
  use simple_mpi, only : rank, nodes, gather_r8
  use simple_mpi, only : bcast_r8, scatter_c8, bcast_scalar_general_i
  implicit none
  integer iv, ir, nv_loc
  integer b, br, b_loc, nc_loc, nc_loc_of_br
  integer i, st, nds, is
  integer, allocatable :: map_b(:)
  real*8, allocatable  :: pc_loc(:,:)
  real*8, allocatable  :: pv_loc(:,:), p(:)
  real*8, allocatable  :: dns(:), dnsb(:)
  complex*16, allocatable :: uk(:)
  complex(kind=kind_gamma_c), allocatable  :: uklow(:), ukhigh(:), ukalpha(:), ukglue(:)
  complex(kind=kind_gamma_c), allocatable  :: cp(:)
  complex(kind=kind_gamma_c), allocatable  :: rhobi_loc(:,:) ! rhobi(1:ncomb, 1:nb, 
  
  ! First check that you need to be here
  if(.not.flg_rhoij) return
  if(nv_band==0.or.nc_band==0) return ! fixed

  select case(vwtype)
  case('W','rpa','Rpa','RPA'); return
  case('Wvw','vw','vwk'); continue
  case default; stop ' vwtype_vwbi '
  end select
  
  !if(diag_remove)stop ' dont use diag_remove '
  
  call time_print(' entering rhobi ')

  ! Now start
  nds=max(nodes,1)
  call make_nv_loc
  call make_nc_loc
  call make_map_b

  ! Assign the phi states, to the nodes, phi1 to node 0, phi2 to node 1, etc.
  ! For this you need maps.

  if(allocated(rhobi1)) deallocate(rhobi1)
  allocate(rhobi1(ncomb1,nc_band,nv_band,nsp), stat=st)
  call check0(st,' rhobi1 ')

  allocate(rhobi_loc(ncomb, nc_loc), stat=st)
  call check0(st,' rhobi_loc ')
  
  allocate(p(nn), stat=st)
  call check0(st,' p(nn) ')

  allocate(pv_loc(n,nv_loc), stat=st)
  call check0(st,' pv_loc ')

  allocate(pc_loc(n,nc_loc), stat=st)
  call check0(st,' pc_loc ')
  
  allocate(dns(n), dnsb(nk), uk(nk), stat=st) 
  call check0(st,' dns ')

  if(flg_gamma) then
     call check(ncomb, nk_low,' ncomb, nk_low so no gluing ')
  else
     call check(ncomb, nk_low+ nalpha,' ncomb, ncw+low+n_alpha ')
  endif
     
  allocate(ukhigh(nk_high), uklow(nk_low), ukalpha(nalpha), ukglue(ncomb), cp(nncomb), stat=st)
  call check0(st,' uksplit ')
  cp = 0 ! important for scatter

  ! main loop, bcast, fft, and dot product.  But first allocate

  spnloop: do is=1,nsp
     call gather_pv_loc
     call gather_pc_loc
     
     deallocate(p)
     allocate(p(n), stat=st)
     call check0(st,' p ')
  
     i=0
     mainloop : do iv=1,nv_band
        ! first send the ac'th w.f. from its rank
        ir = mod(iv-1,nds)
        if(rank==ir)then
           i=i+1
           p=pv_loc(:,i)
        endif
        call bcast_r8(p, size(p), ir)
        ! now loop over all exisiting w.f.
        do b_loc=1,nc_loc
           dns = p*pc_loc(:,b_loc) ! phi(:,iv)*phi(:,b)
           call broaden_dns_to_dnsb ! puts dns on bigger grid
           call fft_dnsb_to_uk   ! clear by name
           call scale_left_uk   ! uk--> const*sign(sqrt(vwktot),vwktot)*uk
           call split_uk         ! splits to uklow, ukhigh
           if(.not.flg_gamma) call compress_kind_g_c(ukhigh, ukalpha) ! makes uk_alpha
           call glue_uklow_ukalpha ! makes ukglue
           call assign_ukglue_to_rhobi_loc
        enddo
        
        ! now bcast the calculated rhobi
        brloop : do br=0,nds-1
           nc_loc_of_br= -99
           if(br==rank) nc_loc_of_br= nc_loc
           call bcast_scalar_general_i(nc_loc_of_br, br)
           
           b_loc_loop : do b_loc =1,nc_loc_of_br
              if(br==rank) then
                 b= map_b(b_loc)
                 cp(1:ncomb) = rhobi_loc(:,b_loc) 
              endif
              call bcast_scalar_general_i(b, br)
              
              call scatter_c8(cp, rhobi1(:,b,iv,is), ncomb1, br)
           end do b_loc_loop
        end do brloop
     end do mainloop
  end do spnloop
  !call debug
  
  select case(action_rhoij)
  case('prep')
     !call rhobi_write
  end select
  
  call time_print(' post rhobi ')
contains
  
  subroutine make_nv_loc
    integer j, jr
    i=0
    do j=1,nv_band
       jr=mod(j-1,nds)
       if(rank==jr)i=i+1
    enddo
    nv_loc = i
  end subroutine make_nv_loc

  subroutine make_nc_loc
    i=0
    do b=1,nc_band
       br=mod(b-1,nds)
       if(rank==br)i=i+1
    enddo
    
    nc_loc = i
  end subroutine make_nc_loc

  subroutine make_map_b
    allocate(map_b(nc_loc), stat=st)
    call check0(st,' map_b ')
    i=0
    do b=1,nc_band
       br=mod(b-1,nds)
       if(rank==br) then
          i=i+1
          map_b(i) = b
       endif
    enddo
  end subroutine make_map_b

  subroutine gather_pv_loc
    integer j, jr

    if(allocated(p)) deallocate(p)
    allocate(p(nn), stat=st)
    call check0(st,' gather_pv_loc ')

    i=0
    do j=1,nv_band 
       jr = mod(j-1,nds)
       call gather_r8(pv1(:,is,j), p, n1, jr)
       if(rank==jr) then
          i=i+1
          pv_loc(:,i) = p(1:n)
       endif
    end do
    
    call time_print('  rhobi post-gather ')
  end subroutine gather_pv_loc
  
  subroutine gather_pc_loc
    if(allocated(p)) deallocate(p)
    allocate(p(nn), stat=st)
    call check0(st,' gather_pv_loc ')

    i=0
    do b=1,nc_band 
       br = mod(b-1,nds)
       call gather_r8(pc1(:,is,b), p, n1, br)
       if(rank==br) then
          i=i+1
          pc_loc(:,i) = p(1:n)
       endif
    end do
    
    call time_print('  rhobi post-gather ')
  end subroutine gather_pc_loc

  subroutine fft_dnsb_to_uk
    uk = dnsb
    call fft3d_forward(nx*scale_vh, ny*scale_vh, nz*scale_vh, uk, uk)
  end subroutine fft_dnsb_to_uk

  subroutine scale_left_uk
    call check(size(uk), size(vwktot),' size_u_vwktot ')
    uk = uk * sign(sqrt(abs(vwktot(:))),vwktot(:))*  sqrt(dv/dble(nk))
  end subroutine scale_left_uk

  subroutine split_uk ! splits to uklow, ukhigh
    uklow  = uk(map_vwklow(:))
    ukhigh = uk(map_vwkhigh(:))
  end subroutine split_uk

  subroutine glue_uklow_ukalpha
    ukglue(1:size(uklow))= uklow
    if(.not.flg_gamma) ukglue(size(uklow)+1:size(uklow)+nalpha) = ukalpha

  end subroutine glue_uklow_ukalpha

  subroutine assign_ukglue_to_rhobi_loc
    rhobi_loc(:,b_loc) = ukglue(:)
  end subroutine assign_ukglue_to_rhobi_loc
  
  subroutine broaden_dns_to_dnsb
    if(mod(nx ,2)/=0.or.mod(ny ,2)/=0.or.mod(nz ,2)/=0) stop ' make nx ,ny ,nz  all even '

    select case(scale_vh)
    case(2); call dns_to_dnsb(dns,dnsb)
    case(1); dnsb= dns
    case default; stop 'scale_vh problem '
    end select
  end subroutine broaden_dns_to_dnsb

  subroutine dns_to_dnsb(dns,dnsb)
    real*8  dns( nx, ny, nz)
    real*8  dnsb(nx*2,ny*2,nz*2)
    integer mx,my,mz,px,py,pz
    call check(scale_vh, 2, 'scale_vh vs. 2 ')

    dnsb = 0d0
    
    mx= 1 + nx - nx/2
    px=     nx + nx/2

    my= 1 + ny - ny/2
    py=     ny + ny/2

    mz= 1 + nz - nz/2
    pz=     nz + nz/2

    dnsb(mx:px,my:py,mz:pz) = dns
  end subroutine dns_to_dnsb

  subroutine debug
    use simple_mpi, only : allsum_scalar_r8
    real*8 sum_check
    sum_check = sum(abs(rhobi1**2))
    call allsum_scalar_r8(sum_check)
    if(rank==0) write(6,*)' rhobi1_norm2 ',sum_check
  end subroutine debug

end subroutine rhobi1_make

