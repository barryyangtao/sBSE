subroutine init_fws
  use jr
  use simple_mpi, only : rank
  implicit none
  integer st
  if(nws<1) return
  !allocate(fws(n, nv, nws), stat=st)
  allocate(fws(mc, nv, nq, nsp, nws), stat=st) ! note
  call check0(st,' fws ')
  fws= 0d0
end subroutine init_fws
