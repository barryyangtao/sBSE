subroutine lda_sr_libxc(dens, n, nspin, vxc, exc, omega) ! sr = short range
  implicit none
  integer             :: n, n2, n3, nspin, st, i
  integer, parameter  :: one=1, two=2
  real*8              :: dens(nspin,n), vxc(nspin,n), exc(n), omega 

  !dummy local variables
  !real*8, allocatable :: sigma(:), ex(:), va(:)
  real*8, allocatable :: ex(:), ec(:), va(:,:)

  if (nspin==1) then
    allocate(ex(n), va(1,n), stat=st); if(st/=0) stop ' error lda_libxc '

    call libxc_drive_unpolarized_lda_sr(n,dens,ex,va,omega,one)
    exc(1:n)   = ex
    vxc(:,1:n) = va

    call libxc_drive_unpolarized_lda_sr(n,dens,ex,va,omega,two)
    exc(1:n)   = exc(1:n) + ex
    vxc(:,1:n) = vxc(:,1:n) + va
  else if (nspin==2) then
    allocate(ex(n), va(2,n), stat=st); if(st/=0) stop ' error lda_libxc '

    n2 = 2*n

    call libxc_drive_polarized_lda_sr(n,n2,dens,ex,va,omega,one)
    exc(1:n)   = ex
    vxc(:,1:n) = va

    call libxc_drive_polarized_lda_sr(n,n2,dens,ex,va,omega,two)
    exc(1:n)   = exc(1:n) + ex
    vxc(:,1:n) = vxc(:,1:n) + va
  endif
  
  deallocate(ex,va)
end subroutine

subroutine lda_sr_libxc_x(dens, n, nspin, vx, ex, omega) ! sr = short range
  implicit none
  integer             :: n, n2, n3, nspin, st, i
  integer, parameter  :: one=1, two=2
  real*8              :: dens(nspin,n), vx(nspin,n), ex(n), omega 

  if (nspin==1) then
    call libxc_drive_unpolarized_lda_sr(n,dens,ex,vx,omega,one)
  else if (nspin==2) then
    n2 = 2*n
    call libxc_drive_polarized_lda_sr(n,n2,dens,ex,vx,omega,one)
  endif
end subroutine

subroutine pbe_sr_libxc(dens, n, nspin, vxc, exc, omega)
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  use mpi_lib_ours, only : rank
  implicit none
  integer             :: n, nspin, st
  integer, parameter  :: one=1, two=2, three=3, four=4, five=5
  real*8              :: dens(nspin,n), vxc(nspin,n), exc(n)
  real*8,  parameter  :: toll_sigma = 1d-11
  real*8 :: omega

  !dummy local variables
  real*8, allocatable :: sigma(:,:), va(:,:), ex(:), dens_mix(:)
  if(nx*ny*nz/=n) stop "PROBLEM WITH THE GRID IN PBE_LIBXC!"
  

  if(nspin==1) then 
    allocate(sigma(1,n), va(1,n), ex(n), stat=st); if(st/=0) stop ' pbe_libxc alloc. error '
    call grad(nx, dx, ny, dy, nz, dz, dens, sigma)

    if(any(sigma/=sigma)) stop "NAN IN GRADS!"
    where(abs(sigma).lt.toll_sigma) sigma=0.d0 ! DN, abs needed
    sigma = sigma**2.d0 ! dont erase: maybe need to have 0.25
    !if(rank==0) write(6,*)' rank,sigma = ',rank,sum(sigma)

    call libxc_drive_unpolarized_pbe_sr(n,dens,sigma,ex,va,omega,one) 

    vxc = va
    exc = ex

    call libxc_drive_unpolarized_pbe_sr(n,dens,sigma,ex,va,omega,two)

    vxc = vxc + va
    exc = exc + ex
  else if(nspin==2) then
    allocate(sigma(3,n), va(2,n), ex(n), dens_mix(n), stat=st); if(st/=0) stop ' pbe_libxc alloc. error '
    dens_mix(:) = dens(1,:)*dens(1,:)
    call grad(nx, dx, ny, dy, nz, dz, dens_mix, sigma(1,:))
    dens_mix(:) = dens(1,:)*dens(2,:)
    call grad(nx, dx, ny, dy, nz, dz, dens_mix, sigma(2,:))
    dens_mix(:) = dens(2,:)*dens(2,:)
    call grad(nx, dx, ny, dy, nz, dz, dens_mix, sigma(3,:))
    
    call libxc_drive_polarized_pbe_sr(n,2*n,3*n,dens,sigma,ex,va,omega,one) 
    vxc = va
    exc = ex

    call libxc_drive_polarized_pbe_sr(n,2*n,3*n,dens,sigma,ex,va,omega,two) 
    vxc = vxc + va
    exc = exc + ex
    deallocate(dens_mix)
  endif
  deallocate(sigma, ex, va)
end subroutine pbe_sr_libxc

subroutine pbe_sr_libxc_x(dens, sigma, n, nsig, nspin, vx, ex, omega)
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  use mpi_lib_ours, only : rank
  implicit none
  integer             :: n, nspin, st, nsig
  integer, parameter  :: one=1, two=2, three=3, four=4, five=5
  real*8              :: dens(nspin,n), vx(nspin,n), ex(n), sigma(nsig,n)
  real*8,  parameter  :: toll_sigma = 1d-11
  real*8 :: omega

  if(nx*ny*nz/=n) stop "PROBLEM WITH THE GRID IN PBE_LIBXC_X_SR!"

  if(nspin==1) then 
    call check(1,nsig,'1,nsig nspin=1 pbe_sr')
    call libxc_drive_unpolarized_pbe_sr(n,dens,sigma,ex,vx,omega,one) 
  else if(nspin==2) then
    call check(3,nsig,'3,nsig nspin=2 pbe_sr')
    call libxc_drive_polarized_pbe_sr(n,2*n,3*n,dens,sigma,ex,vx,omega,one) 
  endif
end subroutine pbe_sr_libxc_x
