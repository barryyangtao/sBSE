subroutine libxc_drive_unpolarized(ngrp,dens,sigma,exc,vxc,func)
  use xc_f90_lib_m
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  use mpi_lib_ours, only : rank, sync_mpi
  implicit none

  !local dummy
  integer   :: ix, iy, iz, ii, st

  real*8 :: omega=0d0

  !from the DFT code
  integer :: ngrp
  integer*8 :: ngrp8
  real*8  :: dens(ngrp), sigma(ngrp), exc(ngrp), vxc(ngrp)
  ! modified -- allocatable

  real*8, allocatable :: v1mul(:), v2mul(:), vsigma(:), den_eps(:)
  integer :: func
  ! %% functional list allowed right now
  !    1 - LDAx
  !    2 - LDAc (Perdew & Wang) 
  !    3 - PBEx revised 
  !    4 - PBEc 
  !    5 - wPBEx



  !local vars for linking
  TYPE(xc_f90_func_t) :: xc_func
  TYPE(xc_f90_func_info_t) :: xc_info
  integer :: i, vmajor, vminor, vmicro, func_id 
  real*8 :: zero_r8=0.d0, one_r8=1.d0

  ngrp8 = ngrp
  select case(func)
  case(1)
    func_id=1
  case(2) 
    func_id=12
  case(3)
    func_id=101
  case(4)
    func_id=130
  case(5)
    func_id=524 
  case default
    write(*,*) 'func_id, ngrp', func_id, ngrp
    stop "WRONG SELECTION OF FUNCTIONAL IN LIBXC_DRIVER UNPOL!"
  end select

  allocate(v1mul(ngrp), v2mul(ngrp), vsigma(ngrp),den_eps(ngrp), stat=st)
  if(st/=0) stop ' libxc_driver allocation error1 '
  

  !call xc_f90_func_init(xc_func, xc_info, func_id, XC_UNPOLARIZED)
  call xc_f90_func_init(xc_func, func_id, XC_UNPOLARIZED)
  xc_info = xc_f90_func_get_info(xc_func)
  
  !write(6,*) "GAMM=",omega
  if(omega.gt.1e-6) then
    stop 'not using this part'
    if(rank==0) then; write(6,*)  "ENTER omega =",omega; call flush(6); end if
!    call xc_f90_gga_x_wpbeh_set_par(xc_func,omega)
    if(rank==0) then; write(6,*)  "Hybrid LIBXC!",omega; call flush(6); end if
    call sync_mpi
  end if
  
  select case (xc_f90_func_info_get_family(xc_info))
  case(XC_FAMILY_LDA)
     call xc_f90_lda_exc_vxc(xc_func, ngrp8, dens(1), exc(1),vxc(1))
  case(XC_FAMILY_GGA,XC_FAMILY_HYB_GGA)
     !  ! note the structure:
     !  vmul is the multiplicative part of the potential
     !  the total potential has another term: -2 Div* (vsigma*Grad(dens))
     !
     
     call xc_f90_gga_exc_vxc(xc_func, ngrp8, dens(1), sigma(1), exc(1), v1mul(1), vsigma(1))
     
     
     where(sigma==0) vsigma=0.d0
     den_eps = dens
     where(abs(den_eps).lt.1E-10) den_eps=0.d0
     
     call gga_pot2(ngrp, den_eps, vsigma,v2mul)
     
     vxc = v1mul + v2mul
     
  end select
  
  call xc_f90_func_end(xc_func)
  
  deallocate(v1mul, v2mul, vsigma, den_eps)
end subroutine libxc_drive_unpolarized

subroutine libxc_drive_polarized(ngrp,ngrp2,ngrp3,dens,sigma,exc,vxc,func)
  use xc_f90_lib_m
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  use mpi_lib_ours, only : rank, sync_mpi
  implicit none

  !local dummy
  integer   :: ix, iy, iz, ii, st

  real*8 :: omega=0d0

  !from the DFT code
  integer :: ngrp, ngrp2, ngrp3
  integer*8 :: ngrp8, ngrp28
  real*8  :: dens(ngrp2), sigma(ngrp3), exc(ngrp), vxc(ngrp2)
  ! modified -- allocatable

  real*8, allocatable :: v1mul(:), v2mul(:), vsigma(:), den_eps(:)
  integer :: func
  ! %% functional list allowed right now
  !    1 - LDAx
  !    2 - LDAc (Perdew & Wang) 
  !    3 - PBEx revised 
  !    4 - PBEc 
  !    5 - wPBEx



  !local vars for linking
  TYPE(xc_f90_func_t) :: xc_func
  TYPE(xc_f90_func_info_t) :: xc_info
  integer :: i, vmajor, vminor, vmicro, func_id 
  real*8 :: zero_r8=0.d0, one_r8=1.d0

  ngrp8 = ngrp
  select case(func)
  case(1)
    func_id=1
  case(2) 
    func_id=12
  case(3)
    func_id=101
  case(4)
    func_id=130
  case(5)
    func_id=524 
  case default
    stop "WRONG SELECTION OF FUNCTIONAL IN LIBXC_DRIVER POL!"
  end select

  allocate(v1mul(ngrp2), v2mul(ngrp2), vsigma(ngrp3),den_eps(ngrp), stat=st)
  !allocate(v1mul(ngrp), v2mul(ngrp), vsigma(ngrp3),den_eps(ngrp), stat=st)
  if(st/=0) stop ' libxc_driver allocation error2 '
  

  !call xc_f90_func_init(xc_func, xc_info, func_id, XC_POLARIZED)
  call xc_f90_func_init(xc_func, func_id, XC_POLARIZED)
  xc_info = xc_f90_func_get_info(xc_func)
  
  !write(6,*) "GAMM=",omega
  if(omega.gt.1e-6) then
    stop 'not using this part'
    if(rank==0) then; write(6,*)  "ENTER omega =",omega; call flush(6); end if
!    call xc_f90_gga_x_wpbeh_set_par(xc_func,omega)
    if(rank==0) then; write(6,*)  "Hybrid LIBXC!",omega; call flush(6); end if
    call sync_mpi
  end if
  
  select case (xc_f90_func_info_get_family(xc_info))
  case(XC_FAMILY_LDA)
     call xc_f90_lda_exc_vxc(xc_func, ngrp8, dens(1),exc(1),vxc(1))
  case(XC_FAMILY_GGA,XC_FAMILY_HYB_GGA)
     !  ! note the structure:
     !  vmul is the multiplicative part of the potential
     !  the total potential has another term: -2 Div* (vsigma*Grad(dens))
     !
     call xc_f90_gga_exc_vxc(xc_func, ngrp8, dens(1), sigma(1), exc(1), v1mul(1), vsigma(1))
     
     where(sigma==0) vsigma=0.d0
     den_eps = dens
     where(abs(den_eps).lt.1E-10) den_eps=0.d0
     
     call gga_pot2_pol(ngrp, den_eps, vsigma,v2mul)
    
     vxc = v1mul + v2mul
  end select
  
  call xc_f90_func_end(xc_func)
  
  deallocate(v1mul, v2mul, vsigma, den_eps)
end subroutine libxc_drive_polarized
!
! removed denshlf
!

! may need need to use  1/2 for dens if 0.25 in sigma
subroutine libxc_drive_unpolarized_lda_sr(ngrp,dens,exc,vxc,omega,func)
  use, intrinsic :: iso_c_binding
  use xc_f90_lib_m
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  use mpi_lib_ours, only : rank, sync_mpi
  implicit none

  !local dummy
  integer   :: ix, iy, iz, ii, st

  !from the DFT code
  integer(c_int) :: n_ext_params, num
  integer :: ngrp
  integer*8 :: ngrp8
  real*8  :: dens(ngrp), exc(ngrp), vxc(ngrp), omega
  real(c_double) :: omega_c(1)
  ! modified -- allocatable
  integer :: func
  ! %% functional list allowed right now
  !    1 - LDAx_sr
  !    2 - LDAc (Perdew & Wang) 

  !local vars for linking
  TYPE(xc_f90_func_t) :: xc_func
  TYPE(xc_f90_func_info_t) :: xc_info
  integer :: i, vmajor, vminor, vmicro, func_id 
  real*8 :: zero_r8=0.d0, one_r8=1.d0
  character(128) ext_param_name

  ngrp8 = ngrp
  select case(func)
  case(1)
    func_id=546
  case(2) 
    func_id=12
  case default
    stop "WRONG SELECTION OF FUNCTIONAL IN LIBXC_LDA_SR_DRIVER!"
  end select
  
  !if(st/=0) stop ' libxc_driver allocation error3 '
  

  !call xc_f90_func_init(xc_func, xc_info, func_id, XC_UNPOLARIZED)
  call xc_f90_func_init(xc_func, func_id, XC_UNPOLARIZED)
  xc_info = xc_f90_func_get_info(xc_func)

  if(func==1) then
    omega_c = omega
    call xc_f90_func_set_ext_params(xc_func,omega_c)
  endif
  
  select case (xc_f90_func_info_get_family(xc_info))
  case(XC_FAMILY_LDA)
     call xc_f90_lda_exc_vxc(xc_func, ngrp8, dens(1), exc(1),vxc(1))
  case(XC_FAMILY_GGA,XC_FAMILY_HYB_GGA)
  end select
  
  call xc_f90_func_end(xc_func)
end subroutine libxc_drive_unpolarized_lda_sr

subroutine libxc_drive_polarized_lda_sr(ngrp,ngrp2,dens,exc,vxc,omega,func)
  use, intrinsic :: iso_c_binding
  use xc_f90_lib_m
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  use mpi_lib_ours, only : rank, sync_mpi
  implicit none

  !local dummy
  integer   :: ix, iy, iz, ii, st

  !from the DFT code
  integer(c_int) :: n_ext_params, num
  integer :: ngrp, ngrp2
  integer*8 :: ngrp8
  real*8  :: dens(ngrp2), exc(ngrp), vxc(ngrp2), omega
  real(c_double) :: omega_c(1)
  ! modified -- allocatable
  integer :: func
  ! %% functional list allowed right now
  !    1 - LDAx_sr
  !    2 - LDAc (Perdew & Wang) 

  !local vars for linking
  TYPE(xc_f90_func_t) :: xc_func
  TYPE(xc_f90_func_info_t) :: xc_info
  integer :: i, vmajor, vminor, vmicro, func_id 
  real*8 :: zero_r8=0.d0, one_r8=1.d0
  character(128) ext_param_name

  ngrp8 = ngrp
  select case(func)
  case(1)
    func_id=546
  case(2) 
    func_id=12
  case default
    stop "WRONG SELECTION OF FUNCTIONAL IN LIBXC_LDA_SR_DRIVER!"
  end select

  !if(st/=0) stop ' libxc_driver allocation error4 '
  

  !call xc_f90_func_init(xc_func, xc_info, func_id, XC_UNPOLARIZED)
  call xc_f90_func_init(xc_func, func_id, XC_POLARIZED)
  xc_info = xc_f90_func_get_info(xc_func)

  if(func==1) then
    omega_c = omega
    call xc_f90_func_set_ext_params(xc_func,omega_c)
  endif
  
  select case (xc_f90_func_info_get_family(xc_info))
  case(XC_FAMILY_LDA)
     call xc_f90_lda_exc_vxc(xc_func, ngrp8, dens(1), exc(1),vxc(1))
  case(XC_FAMILY_GGA,XC_FAMILY_HYB_GGA)
     stop "GGA being called in LDA SR LIBXC_DRIVER"
  end select
  
  call xc_f90_func_end(xc_func)
end subroutine libxc_drive_polarized_lda_sr

subroutine libxc_drive_unpolarized_pbe_sr(ngrp,dens,sigma,exc,vxc,omega,func)
  use, intrinsic :: iso_c_binding
  use xc_f90_lib_m
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  use mpi_lib_ours, only : rank, sync_mpi
  implicit none

  !local dummy
  integer   :: ix, iy, iz, ii, st

  !from the DFT code
  integer(c_int) :: n_ext_params, num
  integer :: ngrp
  integer*8 :: ngrp8
  real*8  :: dens(ngrp), sigma(ngrp), exc(ngrp), vxc(ngrp), omega
  !real(c_double) :: omega_c(1)
  real(c_double) :: omega_c
  real(c_double), allocatable :: pbe_sr_params(:)
  real*8, allocatable :: v1mul(:), v2mul(:), vsigma(:), den_eps(:)
  ! modified -- allocatable
  integer :: func
  ! %% functional list allowed right now
  !    1 - PBEx_sr
  !    2 - PBEc



  !local vars for linking
  TYPE(xc_f90_func_t) :: xc_func
  TYPE(xc_f90_func_info_t) :: xc_info
  integer :: i, vmajor, vminor, vmicro, func_id 
  real*8 :: zero_r8=0.d0, one_r8=1.d0
  character(128), allocatable ::  ext_param_name(:)
  logical :: has_omega

  ngrp8 = ngrp
  select case(func)
  case(1)
    func_id=623
    !func_id=601 !gives similar results to the one above
    !func_id=524 !this one gives results very different than the other 2 above
  case(2) 
    func_id=130
  case default
    stop "WRONG SELECTION OF FUNCTIONAL IN LIBXC_PBE_SR_DRIVER!"
  end select

  !if(st/=0) stop ' libxc_driver allocation error5 '
  
  allocate(v1mul(ngrp), v2mul(ngrp), vsigma(ngrp),den_eps(ngrp), stat=st)
  if(st/=0) stop ' libxc_driver allocation error6 '

  !call xc_f90_func_init(xc_func, xc_info, func_id, XC_UNPOLARIZED)
  call xc_f90_func_init(xc_func, func_id, XC_UNPOLARIZED)
  xc_info = xc_f90_func_get_info(xc_func)

  if(func==1) then
    !has_omega = .false.
    !n_ext_params = xc_f90_func_info_get_n_ext_params(xc_info)
    !allocate(pbe_sr_params(n_ext_params),ext_param_name(n_ext_params),stat=st); if(st/=0) stop 'pbe_sr_params'
    !!write(6,*) 'n_ext_params_pbe', n_ext_params
    !do ii=1,n_ext_params
    !  ext_param_name(ii) = xc_f90_func_info_get_ext_params_name(xc_info,ii-1)
    !  pbe_sr_params(ii) = xc_f90_func_info_get_ext_params_default_value(xc_info,ii-1)
    !  !write(6,*) 'ii, ext_param_name, default value', ii, ext_param_name, pbe_sr_params(ii)
    !  if(trim(adjustl(ext_param_name(ii)))=='_omega') then
    !    pbe_sr_params(ii) = omega
    !    !write(6,*) 'changing omega to: ', omega
    !    has_omega = .true.
    !  endif
    !enddo
    !if(.not.has_omega) stop "couldn't find _omega input in pbe_sr"
    !call xc_f90_func_set_ext_params(xc_func,pbe_sr_params)
    omega_c = omega
    call xc_f90_func_set_ext_params_name(xc_func,'_omega',omega_c)
  endif
  
  select case (xc_f90_func_info_get_family(xc_info))
  case(XC_FAMILY_LDA)
     stop "lda being called in PBE SR LIBXC_DRIVER"
  case(XC_FAMILY_GGA,XC_FAMILY_HYB_GGA)
     call xc_f90_gga_exc_vxc(xc_func, ngrp8, dens(1), sigma(1), exc(1), v1mul(1), vsigma(1))
     
     where(sigma==0) vsigma=0.d0
     den_eps = dens
     where(abs(den_eps).lt.1E-10) den_eps=0.d0
     
     call gga_pot2(ngrp, den_eps, vsigma,v2mul)
     
     vxc = v1mul + v2mul
     
  end select
  
  call xc_f90_func_end(xc_func)
  deallocate(v1mul, v2mul, vsigma, den_eps)
end subroutine libxc_drive_unpolarized_pbe_sr

subroutine libxc_drive_polarized_pbe_sr(ngrp,ngrp2,ngrp3,dens,sigma,exc,vxc,omega,func)
  use, intrinsic :: iso_c_binding
  use xc_f90_lib_m
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  use mpi_lib_ours, only : rank, sync_mpi
  implicit none

  !local dummy
  integer   :: ix, iy, iz, ii, st

  !from the DFT code
  integer(c_int) :: n_ext_params, num
  integer :: ngrp,ngrp2,ngrp3
  integer*8 :: ngrp8
  real*8  :: dens(ngrp2), sigma(ngrp3), exc(ngrp), vxc(ngrp2), omega
  !real(c_double) :: omega_c(1)
  real(c_double) :: omega_c
  real(c_double), allocatable :: pbe_sr_params(:)
  real*8, allocatable :: v1mul(:), v2mul(:), vsigma(:), den_eps(:)
  ! modified -- allocatable
  integer :: func
  ! %% functional list allowed right now
  !    1 - PBEx_sr
  !    2 - PBEc



  !local vars for linking
  TYPE(xc_f90_func_t) :: xc_func
  TYPE(xc_f90_func_info_t) :: xc_info
  integer :: i, vmajor, vminor, vmicro, func_id 
  real*8 :: zero_r8=0.d0, one_r8=1.d0
  character(128), allocatable ::  ext_param_name(:)
  logical :: has_omega

  ngrp8 = ngrp
  select case(func)
  case(1)
    func_id=623
    !func_id=601 !gives similar results to the one above
    !func_id=524 !this one gives results very different than the other 2 above
  case(2) 
    func_id=130
  case default
    stop "WRONG SELECTION OF FUNCTIONAL IN LIBXC_PBE_SR_DRIVER!"
  end select

  !if(st/=0) stop ' libxc_driver allocation error7 '
  
  allocate(v1mul(ngrp2), v2mul(ngrp2), vsigma(ngrp3),den_eps(ngrp), stat=st)
  if(st/=0) stop ' libxc_driver allocation error8 '

  call xc_f90_func_init(xc_func, func_id, XC_POLARIZED)
  xc_info = xc_f90_func_get_info(xc_func)

  if(func==1) then
    omega_c = omega
    call xc_f90_func_set_ext_params_name(xc_func,'_omega',omega_c)
    !has_omega = .false.
    !n_ext_params = xc_f90_func_info_get_n_ext_params(xc_info)
    !allocate(pbe_sr_params(n_ext_params),ext_param_name(n_ext_params),stat=st); if(st/=0) stop 'pbe_sr_params'
    !!write(6,*) 'n_ext_params_pbe', n_ext_params
    !do ii=1,n_ext_params
    !  ext_param_name(ii) = xc_f90_func_info_get_ext_params_name(xc_info,ii-1)
    !  pbe_sr_params(ii) = xc_f90_func_info_get_ext_params_default_value(xc_info,ii-1)
    !  !write(6,*) 'ii, ext_param_name, default value', ii, ext_param_name, pbe_sr_params(ii)
    !  if(trim(adjustl(ext_param_name(ii)))=='_omega') then
    !    pbe_sr_params(ii) = omega
    !    !write(6,*) 'changing omega to: ', omega
    !    has_omega = .true.
    !  endif
    !enddo
    !if(.not.has_omega) stop "couldn't find _omega input in pbe_sr"
    !call xc_f90_func_set_ext_params_name(xc_func,pbe_sr_params)
    !omega_c = omega
    !call xc_f90_func_set_ext_params(xc_func,omega_c)
  endif
  
  select case (xc_f90_func_info_get_family(xc_info))
  case(XC_FAMILY_LDA)
     stop "lda being called in PBE SR LIBXC_DRIVER"
  case(XC_FAMILY_GGA,XC_FAMILY_HYB_GGA)
     call xc_f90_gga_exc_vxc(xc_func, ngrp8, dens(1), sigma(1), exc(1), v1mul(1), vsigma(1))
     
     where(sigma==0) vsigma=0.d0
     den_eps = dens
     where(abs(den_eps).lt.1E-10) den_eps=0.d0
     
     !call gga_pot2(ngrp, den_eps, vsigma,v2mul)
     call gga_pot2_pol(ngrp, den_eps, vsigma,v2mul)
     
     vxc = v1mul + v2mul
     
  end select
  
  call xc_f90_func_end(xc_func)
  deallocate(v1mul, v2mul, vsigma, den_eps)
end subroutine libxc_drive_polarized_pbe_sr

subroutine gga_pot2(n, dens, vsigma,v2mul)
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  implicit none
  integer   :: idir, n, st
  real*8    :: dens(n), vsigma(n), v2mul(n)
  real*8, allocatable :: vec(:,:)

  allocate(vec(n,3), stat=st); if(st/=0) stop 'error gga_pot2  '
  call grad_vec(nx, dx, ny, dy, nz, dz, dens, vec)

  do idir = 1,3
    vec(:,idir) = vsigma(:) * vec(:,idir)  
  end do

  call divrg(nx, dx, ny, dy, nz, dz, vec, v2mul)

  v2mul = -2.d0*v2mul !factor of two due to derivative of |nabla n|^2
  deallocate(vec)

end subroutine gga_pot2

subroutine gga_pot2_pol(n, dens, vsigma,v2mul)
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  implicit none
  integer   :: idir, n, st, is, js
  real*8    :: dens(2,n), vsigma(3,n), v2mul(2,n)
  real*8, allocatable :: vec(:,:), vec2(:,:), tmp(:)

  !u = up
  !d = down
  !vsigma(1,:) = vsigma(u)  = u*u
  !vsigma(2,:) = vsigma(ud) = u*d
  !vsigma(3,:) = vsigma(d)  = d*d
  !v2mul(u) = - nabla * (vsigma(u)*nabla(dens(u))+vsigma(ud)*nabla(dens(d)))
  !v2mul(d) = - nabla * (vsigma(d)*nabla(dens(d))+vsigma(ud)*nabla(dens(u)))
  !if u=d i.e nspin = 1, v2mul returns to nspin=1 form i.e factor of 2

  allocate(vec(n,3), vec2(n,3), tmp(n),stat=st); if(st/=0) stop 'error gga_pot2  '

  !up spin
    !first term
  vec = 0d0
  tmp=dens(1,:)
  call grad_vec(nx, dx, ny, dy, nz, dz, tmp, vec)
  do idir = 1,3
    vec(:,idir) = vsigma(1,:) * vec(:,idir)  
  end do

    !second term
  vec2=0d0
  tmp=dens(2,:)
  call grad_vec(nx, dx, ny, dy, nz, dz, tmp, vec2)
  do idir = 1,3
    vec2(:,idir) = 2d0*vec(:,idir) + vsigma(2,:) * vec2(:,idir)  
  end do
  call divrg(nx, dx, ny, dy, nz, dz, vec2, tmp)
  v2mul(1,:) = tmp
  !

  !down spin
    !first term
  vec = 0d0
  tmp=dens(2,:)
  call grad_vec(nx, dx, ny, dy, nz, dz, tmp, vec)
  do idir = 1,3
    vec(:,idir) = vsigma(3,:) * vec(:,idir)  
  end do

    !second term
  vec2=0d0
  tmp=dens(1,:)
  call grad_vec(nx, dx, ny, dy, nz, dz, tmp, vec2)
  do idir = 1,3
    vec2(:,idir) = 2d0*vec(:,idir) + vsigma(2,:) * vec2(:,idir)  
  end do
  call divrg(nx, dx, ny, dy, nz, dz, vec2, tmp)
  v2mul(2,:) = tmp
  !

  v2mul = -v2mul 
  deallocate(vec,vec2,tmp)

end subroutine gga_pot2_pol

