subroutine lda_libxc(dens, n, nspin, vxc, exc) ! modified dn
  implicit none
  integer             :: n, n2, n3, nspin, st, i
  integer, parameter  :: one=1, two=2
  real*8              :: dens(nspin,n), vxc(nspin,n), exc(n), dv

  !dummy local variables
  !real*8, allocatable :: sigma(:), ex(:), va(:)
  real*8, allocatable :: sigma(:,:), ex(:), ec(:), va(:,:)

  if (nspin==1) then
    allocate(sigma(1,n), ex(n), va(1,n), stat=st); if(st/=0) stop ' error lda_libxc '
    sigma = 0.d0

    call libxc_drive_unpolarized(n,dens,sigma,ex,va,one)
    exc(1:n)   = ex
    vxc(:,1:n) = va

    call libxc_drive_unpolarized(n,dens,sigma,ex,va,two)
    exc(1:n)   = exc(1:n) + ex
    vxc(:,1:n) = vxc(:,1:n) + va
  else if (nspin==2) then
    allocate(sigma(3,n), ex(n), va(nspin,n), stat=st); if(st/=0) stop ' error lda_libxc '
    sigma = 0.d0
    n2 = 2*n
    n3 = 3*n
    call libxc_drive_polarized(n,n2,n3,dens,sigma,ex,va,one)
    exc(1:n) = ex
    vxc(:,1:n) = va

    call libxc_drive_polarized(n,n2,n3,dens,sigma,ex,va,two)
    exc(1:n) = exc(1:n) + ex
    vxc(:,1:n) = vxc(:,1:n) + va
  endif
  
  deallocate(sigma, ex,va)
end subroutine

subroutine lda_libxc_x(dens, n, nspin, vx, ex)
  implicit none
  integer             :: n, n2, n3, nspin, st, i
  integer, parameter  :: one=1, two=2
  real*8              :: dens(nspin,n), vx(nspin,n), ex(n), dv

  !dummy local variables
  !real*8, allocatable :: sigma(:), ex(:), va(:)
  real*8, allocatable :: sigma(:,:)

  if (nspin==1) then
    allocate(sigma(1,n), stat=st); if(st/=0) stop ' error lda_libxc '
    sigma = 0.d0
    call libxc_drive_unpolarized(n,dens,sigma,ex,vx,one)
  else if (nspin==2) then
    allocate(sigma(3,n), stat=st); if(st/=0) stop ' error lda_libxc '
    sigma = 0.d0
    n2 = 2*n
    n3 = 3*n
    call libxc_drive_polarized(n,n2,n3,dens,sigma,ex,vx,one)
  endif
  deallocate(sigma)
end subroutine

subroutine lda_libxc_c(dens, n, nspin, vc, ec)
  implicit none
  integer             :: n, n2, n3, nspin, st, i
  integer, parameter  :: one=1, two=2
  real*8              :: dens(nspin,n), vc(nspin,n), ec(n), dv

  !dummy local variables
  !real*8, allocatable :: sigma(:), ec(:), va(:)
  real*8, allocatable :: sigma(:,:)

  if (nspin==1) then
    allocate(sigma(1,n), stat=st); if(st/=0) stop ' error lda_libxc '
    sigma = 0.d0
    call libxc_drive_unpolarized(n,dens,sigma,ec,vc,two)
  else if (nspin==2) then
    allocate(sigma(3,n), stat=st); if(st/=0) stop ' error lda_libxc '
    sigma = 0.d0
    n2 = 2*n
    n3 = 3*n
    call libxc_drive_polarized(n,n2,n3,dens,sigma,ec,vc,two)
  endif
  deallocate(sigma)
end subroutine

subroutine pbe_libxc(dens, n, nspin, vxc, exc)
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  use mpi_lib_ours, only : rank
  implicit none
  integer             :: n, nspin, st
  integer, parameter  :: one=1, two=2, three=3, four=4, five=5
  real*8              :: dens(nspin,n), vxc(nspin,n), exc(n)
  real*8,  parameter  :: toll_sigma = 1d-11

  !dummy local variables
  real*8, allocatable :: sigma(:,:), va(:,:), ex(:), dens_mix(:)
  if(nx*ny*nz/=n) stop "PROBLEM WITH THE GRID IN PBE_LIBXC!"
  

  if(nspin==1) then 
    allocate(sigma(1,n), va(1,n), ex(n), stat=st); if(st/=0) stop ' pbe_libxc alloc. error '
    call grad(nx, dx, ny, dy, nz, dz, dens, sigma)

    if(any(sigma/=sigma)) stop "NAN IN GRADS!"
    where(abs(sigma).lt.toll_sigma) sigma=0.d0 ! DN, abs needed
    sigma = sigma**2.d0 ! dont erase: maybe need to have 0.25
    !if(rank==0) write(6,*)' rank,sigma = ',rank,sum(sigma)

    call libxc_drive_unpolarized(n,dens,sigma,ex,va,three) 

    vxc = va
    exc = ex

    call libxc_drive_unpolarized(n,dens,sigma,ex,va,four)

    vxc = vxc + va
    exc = exc + ex
  else if(nspin==2) then
    allocate(sigma(3,n), va(2,n), ex(n), dens_mix(n), stat=st); if(st/=0) stop ' pbe_libxc alloc. error '
    dens_mix(:) = dens(1,:)*dens(1,:)
    call grad(nx, dx, ny, dy, nz, dz, dens_mix, sigma(1,:))
    dens_mix(:) = dens(1,:)*dens(2,:)
    call grad(nx, dx, ny, dy, nz, dz, dens_mix, sigma(2,:))
    dens_mix(:) = dens(2,:)*dens(2,:)
    call grad(nx, dx, ny, dy, nz, dz, dens_mix, sigma(3,:))
    
    call libxc_drive_polarized(n,2*n,3*n,dens,sigma,ex,va,three) 
    vxc = va
    exc = ex

    call libxc_drive_polarized(n,2*n,3*n,dens,sigma,ex,va,four) 
    vxc = vxc + va
    exc = exc + ex
    deallocate(dens_mix)
  endif
  deallocate(sigma, ex, va)
end subroutine

subroutine pbe_libxc_x(dens, sigma, n, nsig, nspin, vx, ex)
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  use mpi_lib_ours, only : rank
  implicit none
  integer             :: n, nspin, st, nsig
  integer, parameter  :: one=1, two=2, three=3, four=4, five=5
  real*8              :: dens(nspin,n), vx(nspin,n), ex(n), sigma(nsig,n)
  real*8,  parameter  :: toll_sigma = 1d-11

  if(nx*ny*nz/=n) stop "PROBLEM WITH THE GRID IN PBE_LIBXC_X!"
  
  if(nspin==1) then 
    call check(1,nsig,'1,nsig nspin=1 pbe_x')
    call libxc_drive_unpolarized(n,dens,sigma,ex,vx,three) 
  else if(nspin==2) then
    call check(3,nsig,'3,nsig nspin=2 pbe_x')
    call libxc_drive_polarized(n,2*n,3*n,dens,sigma,ex,vx,three) 
  endif
end subroutine

subroutine pbe_libxc_c(dens, sigma, n, nsig, nspin, vc, ec)
  use mainparam,      only : nx, ny, nz, dx, dy, dz
  use mpi_lib_ours, only : rank
  implicit none
  integer             :: n, nspin, st, nsig
  integer, parameter  :: one=1, two=2, three=3, four=4, five=5
  real*8              :: dens(nspin,n), vc(nspin,n), ec(n), sigma(nsig,n)
  real*8,  parameter  :: toll_sigma = 1d-11

  if(nx*ny*nz/=n) stop "PROBLEM WITH THE GRID IN PBE_LIBXC_C!"
  
  if(nspin==1) then 
    call check(1,nsig,'1,nsig nspin=1 pbe_c')
    call libxc_drive_unpolarized(n,dens,sigma,ec,vc,four) 
  else if(nspin==2) then
    call check(3,nsig,'1,nsig nspin=2 pbe_c')
    call libxc_drive_polarized(n,2*n,3*n,dens,sigma,ec,vc,four) 
  endif
end subroutine
