subroutine write_phieps_selected(i,is,p)
  use jr
  use simple_mpi, only : rank
  implicit none
  integer i,is
  real*8 p(n), eps
  logical :: first=.true.
  if(rank/=0) return

  if(first) then
     first=.false.
     open(35,file='wf_selected.txt',status='replace')
     write(35,*)nx,ny,nz,nocc_a(1:nsp),nvs,ncs,'nx,ny,nz,nocc,nvs,ncs'
     write(35,*)dx,dy,dz,' dx, dy, dz '
  endif
  if(i<nocc_a(is)-nvs+1.or.i>nocc_a(is)+ncs) return

  if(i.le.nocc_a(is)) then
     eps = ev(i-nocc_a(is)+nv,is)
  else
     eps = ec(i-nocc_a(is),is)
  endif

  write(35,*)i,is,real(eps), real(eps*27.211396),' i, eigenvalue(au), eigenvalue(eV) '
  write(35,*)p
  call flush(35)

  if(i==maxval(nocc_a)+ncs) close(35)
end subroutine write_phieps_selected
