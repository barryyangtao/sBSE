subroutine rho_ij_ab_bi_write
   implicit none
  call rhoij1_write;   call time_print(' post rhoij_write ')
  call rhoab1_write;   call time_print(' post rhoab_write ')
  call rhobi1_write;   call time_print(' post rhobi_write ')
end subroutine rho_ij_ab_bi_write

subroutine rhoij1_write
  use jr
  use simple_mpi, only : nodes, rank, sync_mpi
  implicit none
  character(len=1024) char_rank,name
  integer nds, ip
  nds = max(nodes,1)
  ip=40

  call ensure_directory_rho_storage_exists

  call open_replace_rhoij_file

  call write_rhoij
  close(ip)
  
contains
  subroutine ensure_directory_rho_storage_exists
    logical dir_exists, dir_verify
    integer ir !
    
    do ir=0,nds-1 ! this loop ensures that if each core is
       !            connected to a different disk, it will be opened
           
       call sync_mpi
       if(rank==ir) then
          inquire(file='./'//trim(adjustl(scratch_dir)), exist=dir_exists)
          if(.not.dir_exists) then
             call system("mkdir " // trim(adjustl(scratch_dir)) )
             inquire(file=trim(adjustl(scratch_dir)), exist=dir_verify)
             if(.not.dir_verify) stop ' cant open rho_storage '
          endif
       end if
    end do
    call sync_mpi


  end subroutine ensure_directory_rho_storage_exists

  subroutine open_replace_rhoij_file
    call cnvrt_number_1K_string(rank,char_rank)
    name = trim(adjustl(scratch_dir))//'/rhoij.'//trim(adjustl(char_rank))//'.bin'
    open(ip,file=trim(adjustl(name)),form='unformatted',status='replace')
  end subroutine open_replace_rhoij_file

  subroutine write_rhoij
    write(ip)nx,ny,nz,dx,dy,dz,nds,nv_band,nc_band,nalpha,ncomb,ncomb1,nij,nsp
    write(ip)rhoij1
    call flush(ip)
  end subroutine write_rhoij
end subroutine rhoij1_write

subroutine rhoab1_write
  use jr
  use simple_mpi, only : nodes, rank, sync_mpi
  implicit none
  character(len=1024) char_rank,name
  integer nds, ip
  nds = max(nodes,1)
  ip=40

  call ensure_directory_rho_storage_exists

  call open_replace_rhoab_file

  call write_rhoab
  close(ip)
  
contains
  subroutine ensure_directory_rho_storage_exists
    logical dir_exists, dir_verify
    integer ir !
    
    do ir=0,nds-1 ! this loop ensures that if each core is
       !            connected to a different disk, it will be open

       call sync_mpi
       if(rank==ir) then
          inquire(file='./'//trim(adjustl(scratch_dir)), exist=dir_exists)
          if(.not.dir_exists) then
             call system("mkdir " // trim(adjustl(scratch_dir)) )
             inquire(file=trim(adjustl(scratch_dir)), exist=dir_verify)
             if(.not.dir_verify) stop ' cant open rho_storage '
          endif
       end if
    enddo
    call sync_mpi

  end subroutine ensure_directory_rho_storage_exists

  subroutine open_replace_rhoab_file
    call cnvrt_number_1K_string(rank,char_rank)
    name = trim(adjustl(scratch_dir))//'/rhoab.'//trim(adjustl(char_rank))//'.bin'
    open(ip,file=trim(adjustl(name)),form='unformatted',status='replace')
  end subroutine open_replace_rhoab_file

  subroutine write_rhoab
    write(ip)nx,ny,nz,dx,dy,dz,nds,nv_band,nc_band,nalpha,ncomb,ncomb1,nab,nsp
    write(ip)rhoab1
    call flush(ip)
  end subroutine write_rhoab
end subroutine rhoab1_write


subroutine rhobi1_write
  use jr
  use simple_mpi, only : nodes, rank, sync_mpi
  implicit none
  character(len=1024) char_rank,name
  integer nds, ip
  nds = max(nodes,1)
  ip=40

  call ensure_directory_rho_storage_exists

  call open_replace_rhobi_file

  call write_rhobi
  close(ip)
  
contains
  subroutine ensure_directory_rho_storage_exists
    logical dir_exists, dir_verify
    integer ir !
    
    do ir=0,nds-1 ! this loop ensures that if each core is
       !            connected to a different disk, it will be open

       call sync_mpi
       if(rank==ir) then
          inquire(file='./'//trim(adjustl(scratch_dir)), exist=dir_exists)
          if(.not.dir_exists) then
             call system("mkdir " // trim(adjustl(scratch_dir)) )
             inquire(file=trim(adjustl(scratch_dir)), exist=dir_verify)
             if(.not.dir_verify) stop ' cant open rho_storage '
          endif
       end if
    enddo
    call sync_mpi

  end subroutine ensure_directory_rho_storage_exists

  subroutine open_replace_rhobi_file
    call cnvrt_number_1K_string(rank,char_rank)
    name = trim(adjustl(scratch_dir))//'/rhobi.'//trim(adjustl(char_rank))//'.bin'
    open(ip,file=trim(adjustl(name)),form='unformatted',status='replace')
  end subroutine open_replace_rhobi_file

  subroutine write_rhobi
    write(ip)nx,ny,nz,dx,dy,dz,nds,nv_band,nc_band,nalpha,ncomb,ncomb1
    write(ip)rhobi1
    call flush(ip)
  end subroutine write_rhobi
end subroutine rhobi1_write
