subroutine make_f0
  use jr
  implicit none
  if(.not.mixrep) call make_f0b
end subroutine make_f0

subroutine make_f0b
  use jr
  use simple_mpi, only : allsum_r8
  implicit none
  integer iv, id, st, iq, is

  allocate(f0b(nc,nv,nq,nsp), stat=st)
  call check0(st,' f0b ')

  allocate(fdb(nc,nv,nq,nsp,3), stat=st)
  call check0(st,' fdb ')

  do iq=1,nq
     do iv=1,nv
        do is=1,nsp
           f0b(:,iv,iq,is) = matmul(grd1(:,ipol)*pv1(:,is,iv),pc1(:,is,:))*dv
        enddo
     enddo
  enddo
  call allsum_r8(f0b,size(f0b))
  !write(6,*)' f0b ',real(f0b)
  
  do id=1,3
     do iq=1,nq
        do iv=1,nv
           do is=1,nsp
              fdb(:,iv,iq,is,id) = matmul(grd1(:,id)*pv1(:,is,iv),pc1(:,is,:))*dv
           enddo
        enddo
     enddo
  enddo
     
  if(nq==2) then
     f0b(:,:,nq,:)   = -f0b(:,:,nq,:)
     fdb(:,:,nq,:,:) = -fdb(:,:,nq,:,:)
  endif
     
  call allsum_r8(fdb,size(fdb))

end subroutine make_f0b


subroutine set_initial_state(u)
  use jr
  implicit none
  integer iv, iq
  real*8 u(nm,nv,nq,nsp)

  if(mixrep) then
     stop ' set u for mixrep '
     !do iq=1,nq
     !   do iv=1,nv
     !!      u(:,iv,iq) = grd1(:,ipol)*pv1(:,iv) TIMES -1 for iq=2
     !   end do
     !enddo
     !call clean(u)
  else
     u = f0b
  end if

end subroutine set_initial_state
  
