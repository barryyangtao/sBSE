subroutine Wbeta_minus_vw
  use jr
  select case(vwtype)
  case('Wvw')
     if(stoch_beta) call Wbeta_minus_vw_stoch
     if(det_beta)   call Wbeta_minus_vw_D
     if(SR_beta)    call Wbeta_minus_vw_SR
  end select
end subroutine Wbeta_minus_vw
  
subroutine Wbeta_minus_vw_D
  use jr, only : nbe=> nbe_D, Wbe=>Wbe_D, b1b=>b1b_D, b2b=>b2b_D, nvW=>nv_D
  implicit none
  call Wbeta_minus_vw_inside(nbe, nvW, Wbe, b1b, b2b)
end subroutine Wbeta_minus_vw_D

subroutine Wbeta_minus_vw_stoch
  use jr, only : nbe=> nbe_stoch, Wbe=>Wbe_stoch, b1b=>b1b_stoch, b2b=>b2b_stoch, nvW=>nv_stoch
  implicit none
  call Wbeta_minus_vw_inside(nbe, nvW, Wbe, b1b, b2b)
end subroutine Wbeta_minus_vw_stoch

subroutine Wbeta_minus_vw_SR
  use jr, only : nbe=> nbe_SR, Wbe=>Wbe_SR, b1b=>b1b_SR, b2b=>b2b_SR, nvW=>nv_SR
  implicit none
  call Wbeta_minus_vw_inside(nbe, nvW, Wbe, b1b, b2b)
end subroutine Wbeta_minus_vw_SR

subroutine Wbeta_minus_vw_inside(nbe, nvW, Wbe, b1b, b2b)
  use jr
  use simple_mpi, only : rank, nodes, gather_r4, scatter_r4, allsum_scalar_r8
  implicit none
  logical :: on_rank
  integer nbe, nvW
  integer ib, iu, ir, st, nds, is
  real*4 Wbe(n1, nsp, nbe), b1b(nvW, nbe), b2b(nvW, nbe)
  real*8 sum1, sum2 ! debug
  real*4, allocatable :: be_core(:,:), be(:,:), vwbe(:,:), vw1(:,:)
  real*8, allocatable :: be8(:), vwbe8(:)
  
  nds=max(nodes,1)
  allocate(be_core(n1,nsp), be(nn,nsp), vwbe(nn,nsp), vw1(n1,nsp), be8(n), vwbe8(n), &
       stat=st)
  call check0(st,' be_core ')

  sum1 = 0d0
  sum2 = 0d0

  do iu=0,nbe-1,nds
     on_rank=.false.
     do ib=iu+1,min(iu+nds,nbe)
        ir=ib-iu-1
        if(rank==ir) on_rank=.true.
        call make_be_core(nvW, b1b(:,ib), b2b(:,ib), be_core(:,:))
        do is=1,nsp
           call gather_r4(be_core(:,is), be(:,is), n1, ir)
        enddo
     enddo

     if(on_rank) then 
        do is=1,nsp
           be(n+1:nn,is) = 0
           be8 = be(1:n,is)
           call dens_to_vwpol(be8, vwbe8)
           vwbe(1:n,is) = vwbe8
           vwbe(n+1:nn,is) = 0
        enddo
     endif

     do ib=iu+1,min(iu+nds, nbe)
        ir=ib-iu-1
        call scatter_r4(vwbe(:,:), vw1(:,:), n1, ir)
        write(6,*)' ib, nbe ',ib,nbe ! erase
        sum1 = sum1 + sum(Wbe(:,:,ib)**2)*dv
        Wbe(:,:,ib) = Wbe(:,:,ib)-vw1(:,:)
        sum2 = sum2 + sum(Wbe(:,:,ib)**2)*dv
     enddo
  end do
  
  call allsum_scalar_r8(sum1)
  call allsum_scalar_r8(sum2)
  if(nbe>0) then
     sum1 = sum1/nbe
     sum2 = sum2/nbe
  endif
  if(rank==0) write(6,*)' <W|W>: pre, post -vw ',sum1,sum2

end subroutine Wbeta_minus_vw_inside
