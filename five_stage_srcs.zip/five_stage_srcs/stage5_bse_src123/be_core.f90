subroutine make_be_core(nvW, b1, b2, be)
  use jr
  implicit none
  integer nvW, st, is
  real*4 b1(nvW), b2(nvW), be(n1,nsp)
  real*4, allocatable :: beta1(:,:), beta2(:,:)

  call check(nvW,nv,' nvW should equal now nv, change later if needed')
  
  allocate(beta1(n1,nsp), beta2(n1,nsp), stat=st)
  do is=1,nsp
     beta1(:,is) = matmul(pv1(:,is,nv-nvW+1:nv),b1)
     beta2(:,is) = matmul(pv1(:,is,nv-nvW+1:nv),b2)
  end do
  be = beta1*beta2
end subroutine make_be_core
