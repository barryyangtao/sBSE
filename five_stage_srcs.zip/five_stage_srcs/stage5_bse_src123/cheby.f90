subroutine prep_cheby
  use jr
  use simple_mpi, only : rank
  implicit none
  integer i, iw, st
  integer ic, iv, is
  real*8 pi, evmin, ecmax
  pi = dacos(-1d0)

  allocate(dipw(nw,3), stat=st)
  call check0(st,' dipw ')

  if(simple_cheby) then
     allocate(wg(0:ncheby), stat=st)
     call check0(st,' wg ')
     
     wg = (/ (cos(pi*i/dble(2*ncheby))**4, &
          i=0,ncheby ) /)
     wg(1:) = 2*wg(1:)
     ! wg = wg/ncheby; fixed, note:
  end if

  evmin = 1000
  do is=1,nsp
     do iv=1,nv
        if(itrue_v(iv,is)==1) evmin = min(evmin,ev(iv,is))
     enddo
  enddo

  ecmax = -1000
  do is=1,nsp
     do ic=1,nc
        if(itrue_c(ic,is)==1) ecmax = max(ecmax,ec(ic,is))
     enddo
  enddo

  
  if(fctrchby>0) then
     Ltop = fctrchby* (ecmax-evmin)
  else
     Ltop = abs(fctrchby)
  end if

  if(rank==0) then
     write(6,*)' lowest occ, highest unocc ',real(evmin),real(ecmax)
     write(6,*)' most energetic raw exciton ',real(ecmax-evmin)
     write(6,*)' Ltop= ',Ltop
  endif

!  if(fctrchby>1d0) then
!     call reset_Ltop_Lbot
!     
!     if(Ltop<0d0) stop ' Ltop problems '
!     Ltop= Ltop*fctrchby
!  end if

  select case(offdiag)
  case('vwoffdiag'); Lbot = -Ltop
  case('TDA');     Lbot = 0
  case default;     stop 'offdiag error'
  end select
  
  Lavg = (Ltop+Lbot)/2d0
  dL   = (Ltop-Lbot)/2d0
  if(simple_cheby) then
     wg_w(:)= 1/(pi * sqrt(max(dL**2-(wa-Lavg)**2,1d-8)) )
  else
     ncheby_max = 10*dL/ewdth  
  endif
  
  if(rank==0) then
     write(6,*)' lowest occ, highest unocc ',real(evmin),real(ecmax)
     write(6,*)' most energetic raw exciton ',real(ecmax-evmin)
     write(6,*)' Lbot, Ltop ',real(Lbot), real(Ltop)
     write(6,*)' dL, Lavg   ',real(dL), Lavg

     if(simple_cheby) then
        write(6,*)' ncheby ',ncheby
     else
        write(6,*)' ewdth, ncheby_max ',real(ewdth),ncheby_max
     endif

     call flush(6)
  end if

  if(.not.simple_cheby) call calc_coeff_ncheby
  allocate(res(0:ncheby, 3), stat=st)
  call check0(st,' res ')

  allocate(fflt(nvs,ncs_i,nq,nw), stat=st) ! sampled nv, nc(the latter per nodes)
  call check0(st,' fflt ')
  fflt = 0d0

end subroutine prep_cheby

subroutine calc_coeff_ncheby
  use jr
  use simple_mpi, only : rank, bcast_scalar_i
  implicit none
  integer iw, i, st
  real*8 cmax

  allocate(coef(0:ncheby_max, nw),stat=st)
  call check0(st,' coef ')
  
  do iw=1,nw
     call cheb_coeff_r_gaussian_E(ncheby_max, Lavg, DL, wa(iw), ewdth, coef(:,iw))
  enddo

  if(rank==0) then
     do i=0,ncheby_max
        iw=1;  write(41,*)i,real(coef(i,iw)),' i coef(iw=1 )'; call flush(41)
        iw=nw; write(42,*)i,real(coef(i,iw)),' i coef(iw=nw)'; call flush(42)
     enddo
  endif
     
  ncheby = 0
  do iw=1,nw
     cmax = maxval(abs(coef(:,iw)))
     do i=ncheby_max,1,-1
        if(abs(coef(i,iw))>toll_cheby*cmax) ncheby=max(ncheby,i)
     end do
  end do

  if(ncheby>ncheby_max-10) then
     write(6,*)' problem, ncheby, ncheby_max ',ncheby, ncheby_max
     stop
  endif

  call bcast_scalar_i(ncheby)
  if(rank==0) then
     write(6,*)' ncheby, ncheby_max ',ncheby,ncheby_max
     call flush(6)
  end if
  
end subroutine calc_coeff_ncheby

subroutine reset_Ltop_Lbot
  use jr
  use simple_mpi, only : rank
  use simple_mpi, only : bcast_scalar_r8
  implicit none
  if(rank==0) call reset_Ltop_Lbot_rank0
  call bcast_scalar_r8(Lbot)
  call bcast_scalar_r8(Ltop)
end subroutine reset_Ltop_Lbot
  
subroutine reset_Ltop_Lbot_rank0
  use jr
  implicit none
  integer i, st
  integer, parameter :: nhigh=128
  integer, external :: is_it_power2
  real*8 a, Lh, Lb
  real*8, allocatable :: f(:), u(:)
  real*8,  external :: ran_ps

  allocate(f(nm*nv), stat=st)
  call check(st,0,' f ')

  allocate(u(nm*nv), stat=st)
  call check(st,0,' u ')

  do i=1,size(f)
     f(i) = 2d0*ran_ps()-1
  enddo

  do i=1,nhigh
     f=f/sqrt(sum(abs(f)**2)) ! no dv
     call Lsub(f,u)
     Lh = sum(f*u)!  *dv
     if(is_it_power2(i)==1) then
        write(6,*)i,Lh,' i, Lh '
        call flush(6)
     end if
     f = u
  enddo

  Ltop = Lh

  deallocate(f,u) 
end subroutine reset_Ltop_Lbot_rank0

