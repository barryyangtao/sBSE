subroutine make_vk
  use jr
  use simple_mpi, only : rank
  implicit none
  integer st, ngb
  logical, save :: first=.true.
  if(.not.first) return
  first=.false.

  select case(scale_vh)
  case(1)
     allocate(vk(n), vwktot(n), vwkpol(n),  stat=st)
     call check0(st,' vk, vwktot, vwkpol ')
     !scissors_shift_v0 = 0d0
     
     if(periodic) then;  call make_vk_vwktot_vwkpol_periodic
        !else;               call make_vk1_tuma
     else; stop ' use scale_vh=2 for non periodic '
     end if

  case(2)
     if(periodic) stop ' error, scale_vh==2 and periodic '

     ngb =n*8
     allocate(vkb(ngb), vwktot(ngb), vwkpol(ngb), stat=st)
     call check0(st,' vk, vwktot, vwkpol ')

     call make_vkb_tuma
  case default
     stop ' scale_vh '
  end select

contains

  subroutine make_vkb_tuma
    integer i, ngb, nxb, nyb, nzb

    nxb = scale_vh*nx
    nyb = scale_vh*ny
    nzb = scale_vh*nz
    ngb = nxb*nyb*nzb; 
    
    if(mod(nx ,2)/=0.or.mod(ny ,2)/=0.or.mod(nz ,2)/=0) stop ' make nx ,ny ,nz  all even '
    if(mod(nxb,2)/=0.or.mod(nyb,2)/=0.or.mod(nzb,2)/=0) stop ' make nxb,nyb,nzb all even '
    if(abs(ngb-dble(nxb)*dble(nyb)*dble(nzb))>1d-4) stop ' ngb not proper ; maybe need integer*8 '

    call prep_vktuma(nxb,nyb,nzb,dx,dy,dz,vkb,big)
    if(rank==0) then
       write(6,*)' vkb(1:3)        ',real(vkb(1:3))
       write(6,*)' vkb(1:3)/volume ',real(vkb(1:3)/(ngb*dv))
       write(6,*)' 4*pi/k^2(1:3)   ',real(0d0), real(4*3.14/k2_a(2:3))
    endif
       
    if(use_vwk_fit) then
       call vwk_fit_read
       vwkpol = vwk_fit
       vwkpol = ampw*vwkpol ! note the + sign
       deallocate(vwk_fit)
       vwktot= vkb + vwkpol
    else
       call prep_vktuma(nxb,nyb,nzb,dx,dy,dz,vwkpol,gamw)
       if(rank==0) write(6,*)' vwkpol(1:2), maxwkkpol ',real(vwkpol(1:2)),real(maxval(vwkpol))
       vwkpol =    ampw*vwkpol
       vwktot=  ampbare*vkb + vwkpol
    end if
    call print_vwktot

    ! new
    select case(vwtype)
    case('Wvw')
       !scissors_shift_v0 = vkb(1)/(ngb*dv) !* factor_shift
    case('vw','vwk')
       !scissors_shift_v0 = vwktot(1)/(ngb*dv)
    case('W','rpa','RPA','Rpa')
       !scissors_shift_v0 = 0d0
    case default
       stop ' vwtype problem '
    end select
    if(rank==0) write(6,*)' vwkpol(1:3) ',real(vwkpol(1:3))
    if(rank==0) write(6,*)' vwktot(1:3) ',real(vwktot(1:3))
    !if(rank==0) write(6,*)' scissors_shift_v0    (multiply by -1) ',scissors_shift_v0
    !if(rank==0) write(6,*)' scissors_shift_v0_eV (multiply by -1) ',scissors_shift_v0*27.211396
    !vwkpol(1) = 0d0 ! dont erase. Since chi(k=0)=0
    !vwktot(1) = 0d0 ! dont erase. Since chi(k=0)=0
    
  end subroutine make_vkb_tuma

end subroutine make_vk

subroutine make_vk_vwktot_vwkpol_periodic
  use jr
  use simple_mpi,only :rank
  implicit none
  integer i, st
  integer ikx, iky, ikz
  real*8  dkx, dky, dkz
  real*8   kx, ky,  kz
  real*8   k2
  real*8   pi

  call check(n, nx*ny*nz, ' n, nxyz ')
  
  pi = dacos(-1d0)
  dkx = 2d0*pi/(nx*dx)
  dky = 2d0*pi/(ny*dy)
  dkz = 2d0*pi/(nz*dz)
  
  i=0
  do ikz=1,nz
     do iky=1,ny
        do ikx=1,nx
           i=i+1
           kx = (ikx-1)*dkx
           ky = (iky-1)*dky
           kz = (ikz-1)*dkz
           if(kx>pi/dx)kx=kx-2d0*pi/dx
           if(ky>pi/dy)ky=ky-2d0*pi/dy
           if(kz>pi/dz)kz=kz-2d0*pi/dz
           k2 = kx**2 + ky**2 + kz**2

           if(k2>1d-8) then
              vk(i)=4*pi/k2
              vwkpol(i) = 4*pi/k2*exp(-k2/(4*gamw**2))

           else
              
              vk(i) = 0d0
              vwkpol(i) = 0d0
           end if
        enddo
     enddo
  enddo
  
  if(use_vwk_fit) then
    
     call vwk_fit_read
     vwkpol = vwk_fit
     vwkpol = ampw*vwkpol ! note the + sign
     deallocate(vwk_fit)
     vwktot = vk + vwkpol
  else
     vwkpol = ampw*vwkpol
     vwktot = ampbare*vk + vwkpol
  endif
  call print_vwktot
  if(rank==0) write(6,*)' vwktot when made ',maxval(abs(vwktot))
  if(rank==0) write(6,*) ' #, fraction vwktot ',count(vwktot<1d-10), count(vwktot<1d-10)/dble(n)
  if(rank==0) call flush(6)
end subroutine make_vk_vwktot_vwkpol_periodic

subroutine print_vwktot
  use jr
  use simple_mpi, only : rank, check_tag
  implicit none
  integer i
  if(rank==0) then
     open(39,file='vwktot.txt',status='replace')
     do i=1,size(vwktot)
        write(39,*)i,vwktot(i)
     enddo
     call flush(39)
     close(39)
  end if
  call check_tag
end subroutine print_vwktot
