subroutine get_vco( dens, nx, ny, nz, vk,vh, rank)
  implicit none
  integer nx, ny, nz,rank,i
  real*8 dens(nx,ny,nz)
  real*8   vk(nx,ny,nz)
  real*8   vh(nx,ny,nz)
  
  complex*16, allocatable :: ca(:,:,:)
  allocate(ca(nx,ny,nz),stat=i); if(i/=0) stop ' ca '
  ca = dens
  call fft3d_forward(nx, ny, nz, ca, ca)
  ca = ca * vk
  call fft3d_backward(nx, ny, nz, ca, ca)
  vh = ca / (dble(nx)*dble(ny)*dble(nz))
  deallocate(ca)
end subroutine get_vco


subroutine cget_vco( cdens, nx, ny, nz, vk,cvh, rank)
  implicit none
  integer nx, ny, nz,rank,i
  real*8       vk(nx,ny,nz)
  complex*16 cdens(nx,ny,nz)
  complex*16   cvh(nx,ny,nz)

  complex*16, allocatable :: ca(:,:,:)
  allocate(ca(nx,ny,nz),stat=i); if(i/=0) stop ' ca '
  ca = cdens
  call fft3d_forward(nx, ny, nz, ca, ca)
  ca = ca * vk
  call fft3d_backward(nx, ny, nz, ca, ca)
  cvh = ca / (dble(nx)*dble(ny)*dble(nz))
  deallocate(ca)
end subroutine cget_vco

