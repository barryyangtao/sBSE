subroutine make_vkstot
  use neargap
  use simple_mpi, only : scatter_r8, rank
  implicit none
  integer st,is
  logical, save :: first=.true.
  real*8, allocatable :: vkstot(:,:), y(:)

  if(.not.allocated(vkstot1)) then
     allocate(vkstot1(n1,nsp), vkstotfirst1(n1,nsp), stat=st)
     if(st/=0) stop ' vkstot1 '
  end if
  
  allocate(vkstot(n,nsp), y(nn), stat=st)
  if(st/=0) stop ' vkstot '

  if(rank==0) then
     do is=1,nsp
        vkstot(:,is) = vksvalence_noxc(:)+vxc(:,is)
     enddo
  endif

  do is=1,nsp
     y=0
     if(rank==0) y(1:n) = vkstot(:,is)
     call scatter_r8(y,vkstot1(:,is),n1,0)
  end do
  
  if(first) then
     first=.false.
     vkstotfirst1 = vkstot1
  end if
end subroutine make_vkstot
