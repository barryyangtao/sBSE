subroutine rhopt1_read
  use neargap
  use simple_mpi, only : nodes, rank, sync_mpi
  implicit none
  character(len=1024) char_rank,name
  integer ip, st
  ip=41

  call ensure_directory_rho_storage_exists

  call open_old_rhopt_file

  call rhopt1_read_header
  call rhopt1_read_in
  close(ip)
  
contains
  subroutine ensure_directory_rho_storage_exists
    logical dir_exists, dir_verify
    integer ir !
    
    do ir=0,nds-1 ! this loop ensures that if each core is
       !            connected to a different disk, it will be open

       call sync_mpi
       if(rank==ir) then
          inquire(file='./'//trim(adjustl(scratch_dir)), exist=dir_exists)
          if(.not.dir_exists) stop ' scratch directory doesnt exist '
       end if
    enddo
    call sync_mpi

  end subroutine ensure_directory_rho_storage_exists

  subroutine open_old_rhopt_file
    call cnvrt_number_1K_string(rank,char_rank)
    name = trim(adjustl(scratch_dir))//'/rhopt.'//trim(adjustl(char_rank))//'.bin'
    open(ip,file=trim(adjustl(name)),form='unformatted',status='old')
  end subroutine open_old_rhopt_file

  subroutine rhopt1_read_header
    integer mx,my,mz,mds,mtot,malpha,mcomb,mcomb1
    real*8  tx,ty,tz
    read(ip)mx,my,mz,tx,ty,tz,mds,mtot,malpha,mcomb,mcomb1
    call check(mx,nx,' mx-nx in rhopt ')
    call check(my,ny,' my-ny in rhopt ')
    call check(mz,nz,' mz-nz in rhopt ')
    call check_r(tx,dx,' tx-dx in rhopt ')
    call check_r(ty,dy,' ty-dy in rhopt ')
    call check_r(tz,dz,' tz-dz in rhopt ')
    call check(mds,nds,' mds, nds in rhopt ')
    call check(mtot,ntot,' mtot-ntot in rhopt ')
    call check(malpha,nalpha,' malpha-nalpha in rhopt ')
    call check(mcomb,ncomb,' mcomb-ncomb in rhopt ')
    call check(mcomb1,ncomb1,' mcomb1-ncomb1 in rhopt ')
  end subroutine rhopt1_read_header

  subroutine rhopt1_read_in
    if(allocated(rhopt1)) deallocate(rhopt1)
    allocate(rhopt1(ncomb1,ntot, ntot), stat=st)
    call check0(st,' rhopt1 read ')
    read(ip)rhopt1
    call flush(ip)
  end subroutine rhopt1_read_in
end subroutine rhopt1_read
