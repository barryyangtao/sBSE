subroutine read_phieps
  use neargap
  use simple_mpi, only : rank, bcast_r8, nodes, sr_mpi_r8_tag
  use simple_mpi, only : scatter_r8, allsum_scalar_r8, bcast_scalar_r8, bcast_scalar_i
  use simple_mpi, only : allsum_r8
  implicit none
  character*9 cha
  integer ns,nst,iomnwf,ihomo,i,j,st,ir
  integer icoreloc ! NEW 7/5/2023
  real*8  ov, diff
  integer mx,my,mz
  real*8  tx,ty,tz
  real*8, allocatable :: eraw(:), p(:)


  rnk0_a : if(rank==0) then
     open(441,file='wf.txt',form='formatted',status='old')
     rewind(441)
     read(441,*)cha,nx; if(cha/='nx')stop ' didnt read nx from wf.bin ';write(6,*)' nx=',nx
     read(441,*)cha,ny; if(cha/='ny')stop ' didnt read ny from wf.bin ';write(6,*)' ny=',ny
     read(441,*)cha,nz; if(cha/='nz')stop ' didnt read nz from wf.bin ';write(6,*)' nz=',nz
     read(441,*)cha,dx; if(cha/='dx')stop ' didnt read dx from wf.bin ';write(6,*)' dx=',dx
     read(441,*)cha,dy; if(cha/='dy')stop ' didnt read dy from wf.bin ';write(6,*)' dy=',dy
     read(441,*)cha,dz; if(cha/='dz')stop ' didnt read dz from wf.bin ';write(6,*)' dz=',dz
     read(441,*)cha,ns; if(cha/='nsp')stop ' didnt read nsp from wf.bin ';write(6,*)' ns = ',ns
     read(441,*)cha,nst; if(cha/='nstates')stop ' didnt read nstates from wf.bin '; &
          write(6,*)' nstates=',nst
     read(441,*)cha,iomnwf; if(cha/='orbmn_wf')stop ' didnt read orbmn_wf from wf.bin '; &
          write(6,*)' orbmn_wf=',iomnwf
     read(441,*)cha,ihomo; if(cha/='ihomo')write(6,*)' read ',cha,' instead of ihomo'; &
          write(6,*)' ihomo=',ihomo
     nocc = ihomo
     ncore = nocc-nv
     call check_le(0,ncore,'0-ncore ')
     
     read(441,*)cha
     if(cha/='evls  ') then
        write(6,*)' problem. reading ',cha
        write(6,*)' reather than "evl" '
        stop
     endif
     
     allocate(eraw(ncore+ntot), stat=st)
     call check0(st, ' eraw ')
     read(441,*)eraw(:)
     call print_hevl0(eraw(ncore+1:))
     write(6,*)' ncore, eraw(dft) ',ncore,real(eraw(ncore+1:))
     
     if(iomnwf/=1) then
        write(6,*)' problem iomnwf, should be 1 '
        stop
     endif
     
     read(441,*)cha
     if(cha=='dens0core') then
        read(441,*)cha
        read(441,*)cha
     end if

     if(cha=='vxc0') then
        read(441,*)cha
        read(441,*)cha
     end if
     
     if(cha/='orbitals  ') then
        write(6,*)' problem. reading ',cha
        write(6,*)' reather than "orbitals" '
        stop
     endif
  end if rnk0_a
  
  ! bcast etot

  call bcast_scalar_r8(dx)
  call bcast_scalar_r8(dy)
  call bcast_scalar_r8(dz)
  dv=dx*dy*dz
  
  call bcast_scalar_i(nocc)
  call bcast_scalar_i(ncore)
  call bcast_scalar_i(nx)
  call bcast_scalar_i(ny)
  call bcast_scalar_i(nz) 

  allocate(etot(ntot), stat=st)
  call check0(st, ' etot ')
  if(rank==0)   etot=eraw(ncore+1:)
  call bcast_r8(etot, size(etot), 0)

  n=nx*ny*nz
  n1 = n/nds
  if(n1*nds<n) n1=n1+1
  nn = n1*nds
  
  allocate(p(nn), stat=st); call check0(st,' p1 ')
  p=0d0

  allocate(ptot1(n1, ntot), stat=st)
  call check0(st,' ptot ')

  allocate(dens_sp(n,nsp), dens(n), dens0core(n), stat=st)
  call check0(st,' dens0 ')
  dens = 0
  dens0core = 0

  if(core_correct) then  !NEW 7/5/2023
     if(nstocore==-1) then
        call make_ncoreloc
        allocate(phi_core_loc(n, ncoreloc), stat=st)
        if(st/=0) stop ' phi_core_loc '
        icoreloc = 0
     else if(nstocore>0) then
        call stoch_core_prep
     end if
  end if
     
  
  !now read ptot

  do i=1,ncore+ntot
     rnk0_b : if(rank==0) then

        read(441,*)j
        call check(i,j,' i-j in read_wf ')
        read(441,*)p(1:n)
        if(i.le.nocc) dens(:) = dens(:) + 2d0*abs(p(1:n))**2
        if(i.le.ncore) dens0core = dens0core + 2d0*abs(p(1:n))**2
     endif rnk0_b

     if(i>ncore)call scatter_r8(p, ptot1(:,i-ncore), n1, 0)

     if(i.le.ncore.and.core_correct) call store_core
  enddo

  if(core_correct.and.nstocore==-1) call check(icoreloc, ncoreloc,' ncoreloc ')
  if(core_correct.and.nstocore>0)   call stoch_core_distribute
  
  call bcast_r8(dens, size(dens), 0)
  call bcast_r8(dens0core, size(dens0core), 0)
  dens_sp(:,1)   = dens/nsp
  dens_sp(:,nsp) = dens_sp(:,1)

  !now checking
  
  do i=1,ntot
     do j=1,ntot
        ov = sum(ptot1(:,i)*ptot1(:,j))*dv
        call allsum_scalar_r8(ov)
        if(i==j) ov = ov-1d0
        if(rank==0.and.abs(ov)>1d-7) then
           write(6,*)' problem. i,j, ov - delta ',i,j,ov
           stop      ' phi not orthogonal   '
        endif
     enddo
  enddo

contains
  subroutine store_nxyz_dxyz
    mx=nx; my=ny; mz=nz
    tx=dx; ty=dy; tz=dz
  end subroutine store_nxyz_dxyz

  subroutine check_nxyz_dxyz
    call check(mx,nx,' nx from W*.bin, nx from wf.bin ')
    call check(my,ny,' ny from W*.bin, ny from wf.bin ')
    call check(mz,nz,' nz from W*.bin, nz from wf.bin ')
    call check_r(dx,tx,' tx from W*.bin, tx from wf.bin ')
    call check_r(dy,ty,' ty from W*.bin, ty from wf.bin ')
    call check_r(dz,tz,' tz from W*.bin, tz from wf.bin ')
  end subroutine check_nxyz_dxyz

  subroutine store_core
    select case(nstocore)
    case(-1)
       ir = mod(i-1,nds)
       call sr_mpi_r8_tag(p, n, 0, ir) ! n, not nn
       if(rank==ir) then
          icoreloc = icoreloc + 1
          phi_core_loc(:,icoreloc) = p(1:n)
       endif
    case(0)
       stop ' dont use nstocore=0 and core_correct==T '
    case(1:)
       call filter_stoch_core_add_statei
    case default
       stop ' nstocore<-1 error '
    end select
  end subroutine store_core

  subroutine filter_stoch_core_add_statei
    integer isto
    real*8, allocatable :: ac(:), p1(:)
    allocate(ac(nstocore), p1(n1),stat=st); call check0(st,' ac ')

    call scatter_r8(p, p1, n1, 0)
    
    ac(:) = matmul(p1, stoch_core1)*dv

    call allsum_r8(ac, size(ac))

    do isto = 1, nstocore
       stoch_core_filt1(:,isto) = stoch_core_filt1(:,isto) + ac(isto)*p1(:)
    end do
  end subroutine filter_stoch_core_add_statei
end subroutine read_phieps
  
