subroutine make_vxc
  use neargap
  implicit none
  integer st
  if(.not.allocated(dens_sp))stop ' make_vxc_dens '
  if(.not.allocated(vxc))then
     allocate(vxc(n,nsp), stat=st)
     call check0(st,' vxc_alloc ')
  endif
  call vxc_spin_core_corrected(dens_sp, vxc, n, nsp)
end subroutine make_vxc
