subroutine stoch_core_distribute
  use neargap
  use simple_mpi, only: rank, gather_r8
  implicit none
  integer i, ir, st, iloc
  real*8, allocatable :: p(:)
  
  deallocate(stoch_core1)

  allocate(p(nn), stat=st)
  call check0(st,' pdistribute ')
  p= 0

  iloc= 0
  do i=1,nstocore
     ir=mod(i-1,nds)
     call gather_r8(stoch_core_filt1(:,i),p,n1,ir)
     if(rank==ir) then
        iloc = iloc + 1
        stoch_core_loc(:,iloc) = p(1:n)
     end if
  end do

  call check(iloc,nstocore_loc,' ilocsto')

  deallocate(stoch_core_filt1)
end subroutine stoch_core_distribute
