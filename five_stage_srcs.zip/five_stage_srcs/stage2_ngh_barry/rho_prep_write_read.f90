subroutine rho_pi_write_read
  use neargap
  implicit none
  select case(action_rhoij)
  case('prep','prepwriterun')
     call rhopt1_make
     call rhopt1_write
  case('preprun')
     call rhopt1_make
     return
  case('read')
     call rhopt1_read
  case default;
     stop ' action_rhoij '
  end select

end subroutine rho_pi_write_read


