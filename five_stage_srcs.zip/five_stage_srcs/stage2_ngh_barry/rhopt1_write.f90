subroutine rhopt1_write
  use neargap
  use simple_mpi, only : nodes, rank, sync_mpi
  implicit none
  character(len=1024) char_rank,name
  integer ip
  ip=40

  call ensure_directory_rho_storage_exists

  call open_replace_rhopt_file

  call write_rhopt
  close(ip)
  
contains
  subroutine ensure_directory_rho_storage_exists
    logical dir_exists, dir_verify
    integer ir !
    
    do ir=0,nds-1 ! this loop ensures that if each core is
       !            connected to a different disk, it will be open

       call sync_mpi
       if(rank==ir) then
          inquire(file='./'//trim(adjustl(scratch_dir)), exist=dir_exists)
          if(.not.dir_exists) then
             call system("mkdir " // trim(adjustl(scratch_dir)) )
             inquire(file=trim(adjustl(scratch_dir)), exist=dir_verify)
             if(.not.dir_verify) stop ' cant open rho_storage '
          endif
       end if
    enddo
    call sync_mpi

  end subroutine ensure_directory_rho_storage_exists

  subroutine open_replace_rhopt_file
    call cnvrt_number_1K_string(rank,char_rank)
    name = trim(adjustl(scratch_dir))//'/rhopt.'//trim(adjustl(char_rank))//'.bin'
    open(ip,file=trim(adjustl(name)),form='unformatted',status='replace')
  end subroutine open_replace_rhopt_file

  subroutine write_rhopt
    write(ip)nx,ny,nz,dx,dy,dz,nds,ntot,nalpha,ncomb,ncomb1
    write(ip)rhopt1
    call flush(ip)
  end subroutine write_rhopt
end subroutine rhopt1_write
