subroutine alloc_hm
  use neargap
  implicit none
  integer st
  if(.not.allocated(hm)) then
     allocate(hm(ntot,ntot,nsp), stat=st);  call check0(st,' hm ')
     allocate(hmfirsttime(ntot,ntot,nsp), stat=st);  call check0(st,' hmfirstitme ')
     allocate(hmnox(ntot,ntot,nsp), stat=st);  call check0(st,' hmnox ')
  end if
end subroutine alloc_hm

subroutine hmatrix_nox
  implicit none
  logical, save :: first=.true.
  if(first) then
     first=.false.
     call hmatrix_nox_firsttime
  else
     call hmatrix_nox_latertimes
  endif

end subroutine hmatrix_nox

subroutine hmatrix_nox_firsttime
  use neargap
  use simple_mpi, only : rank, gather_r8, scatter_r8
  implicit none
  integer is, i, j, ir, iloc, nloc, st  ! nloc=# of functions stored on p
  real*8, allocatable :: p(:), hp(:), ploc(:,:), hploc(:,:), hptot1(:,:)
  real*8, allocatable :: vptot1(:,:,:)

  allocate(p(nn), hp(nn), hptot1(n1,ntot), vptot1(n1,ntot,nsp), stat=st)
  call check0(st,' p(nn) ')

  call make_vptot1
  
  p=0
  hp=0
  
  ! gather some functions for each call
  nloc = 0
  do i=1,ntot
     ir=mod(i-1,nds)
     if(ir==rank) nloc=nloc+1
  enddo

  allocate( ploc(n, nloc), stat=st); call check0(st,'  ptot_loc ')
  allocate(hploc(n, nloc), stat=st); call check0(st,' hptot_loc ')
  
  iloc=0
  do i=1,ntot
     ir=mod(i-1,nds)
     call gather_r8(ptot1(:,i),p,n1,ir)
     if(ir==rank)then
        iloc=iloc+1
        ploc(:,iloc) = p(1:n)
     end if
  enddo

  iloc=0
  do i=1,ntot
     ir=mod(i-1,nds)
     if(ir==rank) then
        iloc=iloc+1
        call hsub_noxc(ploc(:,iloc),hploc(:,iloc))
     endif
  end do

  ! now scatter the wf
  iloc=0
  do i=1,ntot
     ir=mod(i-1,nds)
     if(rank==ir) then
        iloc=iloc+1
        hp(1:n) = hploc(:,iloc)
        hp(n+1:nn)=0
     end if
     call scatter_r8(hp, hptot1(:,i), n1, ir)
  enddo

  ! now finished scattering hp.
 
  ! do the matrix now.

  do is=1,nsp
     hmnox(:,:,is) = matmul(transpose(ptot1),hptot1+vptot1(:,:,is))*dv
  enddo

  hmfirsttime = hmnox
  
contains
  subroutine make_vptot1
    implicit none
    
    real*8, allocatable :: vxc1(:,:), vvxc(:,:)
    allocate(vxc1(n1,nsp), vvxc(nn,nsp), stat=st)
    call check0(st,' vvxc ')

    vvxc = 0
    vvxc(1:n,:) = vxc

     
    do is=1,nsp
       call scatter_r8(vvxc(:,is),vxc1(:,is),n1,0)
    enddo

    do is=1,nsp
       do i=1,ntot
          vptot1(:,i,is) = vxc1(:,is)*ptot1(:,i)
       enddo
    enddo
 
!   call debug
   
  end subroutine make_vptot1

  subroutine debug
    implicit none
    integer is
    is=1
    write(6,*) ' <s|vxc|t> ',matmul(transpose(ptot1),vptot1(:,:,is))*dv
  end subroutine debug
end subroutine hmatrix_nox_firsttime

subroutine hmatrix_nox_latertimes
  use neargap
  use simple_mpi, only : rank, allsum_r8
  implicit none
  integer st, i, is
  real*8, allocatable :: vd_ptot1(:,:,:)
  call make_vd_ptot1

  do is=1,nsp
     hmnox(:,:,is) = hmfirsttime(:,:,is)+matmul(transpose(ptot1),vd_ptot1(:,:,is))*dv
  enddo

contains
  subroutine make_vd_ptot1
    implicit none
    
    real*8, allocatable :: vd1(:,:)

    allocate(vd1(n1,nsp), stat=st)
    if(st/=0) stop ' vd '
    vd1 = vkstot1-vkstotfirst1

    allocate(vd_ptot1(n1,ntot,nsp), stat=st)
    if(st/=0) stop ' vd_ptot1 '
    
    do is=1,nsp
       do i=1,ntot
          vd_ptot1(:,i,is) = vd1(:,is)*ptot1(:,i)
       enddo
    enddo
  end subroutine make_vd_ptot1
end subroutine hmatrix_nox_latertimes
