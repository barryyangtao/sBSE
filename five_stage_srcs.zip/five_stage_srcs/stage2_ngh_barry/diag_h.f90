subroutine diag_h
  use neargap
  use mat_module, only : mat_diag
  use simple_mpi, only : rank, bcast_r8
  implicit none
  integer st,is
  if(.not.allocated(hevc)) then
     allocate(hevc(ntot, ntot, nsp), &
                    hevl(ntot, nsp), stat=st)
     call check0(st,' hevl ')
  endif

  if(rank==0)write(6,*)' iscf hhh pre  add ',hm(nv+1,nv+1,:)
  call add_scissors
  if(rank==0)write(6,*)' iscf hhh post add ',hm(nv+1,nv+1,:)

  do is=1,nsp
     call mat_diag(hm(:,:,is), hevc(:,:,is), hevl(:,is))
  enddo

  call bcast_r8(hevc, size(hevc),0)
  call bcast_r8(hevl, size(hevl),0)

end subroutine diag_h

subroutine add_scissors
  use neargap
  hm = hm -scissors_shift_v0*pm
end subroutine add_scissors
