subroutine prep_alpha  ! used for stochastic compression of high-k part of vw
  use neargap
  use simple_mpi, only : rank
  implicit none

  nalpha_factor = nalpha/dble(nk_low)
  if(nalpha<1) then
     alpha_compression = .false.
     return
  else
     alpha_compression = .true.
  end if

  l_alpha_pos = ceiling(alpha_coverage*nk_high_pos/dble(na_pos)) ! length each compression segment
  l_alpha_neg = 0
  if(na_neg>0) &
   l_alpha_neg = ceiling(alpha_coverage*nk_high_neg/dble(na_neg))

  if(rank==0) then
     write(6,*)' nk_low, nalpha, nalpha_fctor ',nk_low, nalpha, nalpha_factor
     write(6,*)' l_alpha_pos         ',l_alpha_pos
     write(6,*)' l_alpha_neg         ',l_alpha_neg
     if(l_alpha_pos<1) stop ' l_alpha is 0, stopping due to error '
  endif
  
end subroutine prep_alpha
