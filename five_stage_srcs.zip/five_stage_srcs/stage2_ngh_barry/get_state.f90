subroutine  get_state(i, is, p)
  use neargap
  use simple_mpi, only : gather_r8, bcast_r8, rank
  implicit none
  integer i,is, st
  real*8 p(n)
  real*8, allocatable :: pp(:)
  allocate(pp(nn),stat=st)
  call check0(st,' pp ')
  call gather_r8(psi1(:,i,is),pp,n1,0)
  if(rank==0) p = pp(1:n)
  call bcast_r8(p,n,0)
end subroutine get_state
