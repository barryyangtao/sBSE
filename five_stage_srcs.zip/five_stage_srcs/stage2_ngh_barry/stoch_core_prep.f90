subroutine stoch_core_prep
  use neargap
  use simple_mpi, only : rank, allsum_scalar_i, allsum_r8, scatter_r8
  implicit none
  logical, save :: first=.true.
  integer i, st
  real*8, allocatable :: p(:), stoch_f(:,:)
  if(.not.first) stop ' stoch_core_prep called more than once, error '
  first=.false.
  called_stoch_core_prep=.true.

  call make_nstocore_loc
  call alloc_stocore_loc
  call alloc_stoch_core1
  call alloc_p_nn
  call make_stoch_rank0
  
  do i=1,nstocore
     if(rank==0) p(1:n) = stoch_f(:, i)
     call scatter_r8(p, stoch_core1(:,i), n1, 0) 
  end do

contains
  subroutine make_nstocore_loc
    integer irem, isum
    nstocore_loc = nstocore/nds
    
    irem = mod(nstocore,nds)
    if(rank<irem) nstocore_loc = nstocore_loc+1
    
    isum=nstocore_loc
    call allsum_scalar_i(isum)
    call check(isum,nstocore,' isum nstocore ')
  end subroutine make_nstocore_loc

  subroutine alloc_stocore_loc
    allocate(stoch_core_loc(n, nstocore_loc), &
         stat=st)
    call check0(st,' stoch_core_loc ')
  end subroutine alloc_stocore_loc

  subroutine alloc_stoch_core1
    allocate(stoch_core1(n1, nstocore), &
         stat=st)
    stoch_core1 = 0
    call check0(st,' stoch_core1 ')
    
    allocate(stoch_core_filt1(n1, nstocore), &
         stat=st)
    stoch_core_filt1 = 0
    call check0(st,' stoch_core_filt1 ')
  end subroutine alloc_stoch_core1

  subroutine alloc_p_nn
    allocate(p(nn), stat=st)
    call check0(st,' p_stoch_core_pre ')
    p(:) = 0
  end subroutine alloc_p_nn

  subroutine make_stoch_rank0
    integer, allocatable :: ipm(:,:)
    if(rank==0) then
       allocate(ipm(nstocore, n), stoch_f(n, nstocore), stat=st)
       call check0(st,' ipm ')
       call rand88_i_pm1(ipm, size(ipm))
       stoch_f(:,:) = transpose(ipm)/sqrt(dv)
    end if
  end subroutine make_stoch_rank0
end subroutine stoch_core_prep
  
