subroutine diis_h
  use neargap
  implicit none
  if(diis_true) then
     call diis_general(hm,size(hm))
  else
     call diis_simple
  endif
end subroutine diis_h

module mix_modu
  implicit none
  save
  real*8, allocatable :: hmold(:,:,:)
end module mix_modu

subroutine diis_simple
  use neargap
  use mix_modu, only : hmold
  implicit none
  integer st
  if(.not.allocated(hmold)) then
     allocate(hmold(ntot,ntot,nsp), stat=st)
     call check0(st,' hmold ')
     hmold = hm
  endif

  hm = hm*mix+hmold*(1-mix)
  hmold = hm
end subroutine diis_simple
