subroutine init_crot
  use neargap
  implicit none
  integer i,st
  allocate(crot(ntot,ntot,nsp), stat=st)
  if(st/=0) stop ' ctot '
  crot = 0
  do i=1,ntot
     crot(i,i,:) = 1
  enddo
end subroutine init_crot

