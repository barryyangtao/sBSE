module mainparam
  use neargap, only : nx,ny,nz,dx,dy,dz,n
  implicit none
  save
end module mainparam
