! loc means local, i.e., from relevant core (could be present core).
subroutine rhopt1_make
!  use jr
  use neargap
  use simple_mpi, only : rank, nodes, gather_r8
  use simple_mpi, only : bcast_r8, scatter_c8, bcast_scalar_general_i
  implicit none
  integer s, ir
  integer b, br, b_loc, ntot_loc, ntot_loc_of_br
  integer i, st
  integer, allocatable :: map_b(:)
  real*8, allocatable  :: ptot_loc(:,:)
  real*8, allocatable  ::  p(:)
  real*8, allocatable  :: dns(:), dnsb(:)
  complex*16, allocatable :: uk(:)
  complex(kind=kind_gamma_c), allocatable  :: uklow(:), ukhigh_pos(:), ukhigh_neg(:)
  complex(kind=kind_gamma_c), allocatable  :: ukalpha_pos(:), ukalpha_neg(:), ukglue(:)
  complex(kind=kind_gamma_c), allocatable  :: cp(:)
  complex(kind=kind_gamma_c), allocatable  :: rhopt_loc(:,:) ! rhopt(1:ncomb, 1:nb, 
  
  ! First check that you need to be here

  call time_print(' entering rhopt ')

  ! Now start
  call make_ntot_loc
  call make_map_b

  ! Assign the phi states, to the nodes, phi1 to node 0, phi2 to node 1, etc.
  ! For this you need maps.

  if(allocated(rhopt1)) deallocate(rhopt1)
  allocate(rhopt1(ncomb1,ntot,ntot), stat=st)
  call check0(st,' rhopt1 ')

  allocate(rhopt_loc(ncomb, ntot_loc), stat=st)
  call check0(st,' rhopt_loc ')
  
  allocate(p(nn), stat=st)
  call check0(st,' p(nn) ')

  allocate(ptot_loc(n,ntot_loc), stat=st)
  call check0(st,' ptot_loc ')
  
  allocate(dns(n), dnsb(nk), uk(nk), stat=st) 
  call check0(st,' dns ')

  call check(na_pos+na_neg, nalpha,' na_pos + na_neg, nalpha ')
  call check(ncomb, nk_low+ nalpha,' ncomb, ncw+low+nalpha ')

  allocate(uklow(nk_low), ukglue(ncomb), cp(nncomb), stat=st)
  call check0(st,' ukglue ')

  allocate(ukhigh_pos(nk_high_pos), ukalpha_pos(na_pos),stat=st)
  call check0(st,' ukhighpost ')
  if(na_neg>0) then
     allocate(ukhigh_neg(nk_high_neg), ukalpha_neg(na_neg),stat=st)
     call check0(st,' ukhighneg ')
  endif
     
  cp = 0 ! important for scatter

  call gather_ptot_loc

  if(allocated(p))  deallocate(p)
  allocate(p(n), stat=st)
  call check0(st,' p ')
  
  ! main loop, bcast, fft, and dot product.  But first allocate

  i=0
  mainloop : do s=1,ntot
     ! first send the ac'th w.f. from its rank
     ir = mod(s-1,nds)
     if(rank==ir)then
        i=i+1
        p=ptot_loc(:,i)
     endif
     call bcast_r8(p, size(p), ir)
     ! now loop over all exisiting w.f.
     do b_loc=1,ntot_loc
        dns = p*ptot_loc(:,b_loc) ! phi(:,s)*phi(:,b)
        call broaden_dns_to_dnsb ! puts dns on bigger grid
        call fft_dnsb_to_uk   ! clear by name
        call scale_left_uk   ! uk--> const*sqrt(|vwktot|)*uk
        !call debug_uk
        call split_uk         ! splits to uklow, ukhigh
        call compress_kind_g_c_pos(ukhigh_pos, ukalpha_pos) ! makes uk_alpha
        if(na_neg>0) call compress_kind_g_c_neg(ukhigh_neg, ukalpha_neg)  
        call glue_uklow_ukalpha ! makes ukglue
        call assign_ukglue_to_rhopt_loc
        !call debug_rhopt
     enddo

     ! now bcast the calculated rhopt
     brloop : do br=0,nds-1
        ntot_loc_of_br= -99
        if(br==rank) ntot_loc_of_br= ntot_loc
        call bcast_scalar_general_i(ntot_loc_of_br, br)
        
        b_loc_loop : do b_loc =1,ntot_loc_of_br
           if(br==rank) then
              b= map_b(b_loc)
              cp(1:ncomb) = rhopt_loc(:,b_loc) 
           endif
           call bcast_scalar_general_i(b, br)

           call scatter_c8(cp, rhopt1(:,b,s), ncomb1, br)
        end do b_loc_loop
     end do brloop
  end do mainloop

  !call debug
  call time_print(' post rhopt ')
contains

  subroutine make_ntot_loc
    i=0
    do b=1,ntot
       br=mod(b-1,nds)
       if(rank==br)i=i+1
    enddo
    
    ntot_loc = i
  end subroutine make_ntot_loc

  subroutine make_map_b
    allocate(map_b(ntot_loc), stat=st)
    call check0(st,' map_b ')
    i=0
    do b=1,ntot
       br=mod(b-1,nds)
       if(rank==br) then
          i=i+1
          map_b(i) = b
       endif
    enddo
  end subroutine make_map_b

  subroutine gather_ptot_loc
    i=0
    do b=1,ntot 
       br = mod(b-1,nds)
       call gather_r8(ptot1(:,b), p, n1, br)
       if(rank==br) then
          i=i+1
          ptot_loc(:,i) = p(1:n)
       endif
    end do
    
    call time_print('  rhopt post-gather ')
  end subroutine gather_ptot_loc

  subroutine fft_dnsb_to_uk
    uk = dnsb
    call fft3d_forward(nx*scale_vh, ny*scale_vh, nz*scale_vh, uk, uk)
  end subroutine fft_dnsb_to_uk

  subroutine scale_left_uk
    call check(size(uk), size(vwktot),' size_u_vwktot ')
    uk = uk * sqrt(abs(vwktot(:)))*  sqrt(dv/dble(nk))
  end subroutine scale_left_uk

  subroutine split_uk ! splits to uklow, ukhigh
    uklow  = uk(map_vwklow(:))
    ukhigh_pos = uk(map_vwkhigh_pos(:))
    ukhigh_neg = uk(map_vwkhigh_neg(:))
  end subroutine split_uk

  subroutine glue_uklow_ukalpha
    ukglue(1:size(uklow))= uklow
    ukglue(size(uklow)+1:size(uklow)+na_pos) = ukalpha_pos
    if(na_neg>0)  ukglue(size(uklow)+na_pos+1:size(uklow)+na_pos+na_neg) = ukalpha_neg
  end subroutine glue_uklow_ukalpha

  subroutine assign_ukglue_to_rhopt_loc
    rhopt_loc(:,b_loc) = ukglue(:)
  end subroutine assign_ukglue_to_rhopt_loc
  
  subroutine broaden_dns_to_dnsb
    if(mod(nx ,2)/=0.or.mod(ny ,2)/=0.or.mod(nz ,2)/=0) stop ' make nx ,ny ,nz  all even '

    select case(scale_vh)
    case(2); call dns_to_dnsb(dns,dnsb)
    case(1); dnsb= dns
    case default; stop 'scale_vh problem '
    end select
  end subroutine broaden_dns_to_dnsb

  subroutine dns_to_dnsb(dns,dnsb)
    real*8  dns( nx, ny, nz)
    real*8  dnsb(nx*2,ny*2,nz*2)
    integer mx,my,mz,px,py,pz
    call check(scale_vh, 2, 'scale_vh vs. 2 ')

    dnsb = 0d0
    
    mx= 1 + nx - nx/2
    px=     nx + nx/2

    my= 1 + ny - ny/2
    py=     ny + ny/2

    mz= 1 + nz - nz/2
    pz=     nz + nz/2

    dnsb(mx:px,my:py,mz:pz) = dns
  end subroutine dns_to_dnsb

  subroutine debug
    use simple_mpi, only : allsum_scalar_r8
    real*8 sum_check
    sum_check = sum(abs(rhopt1**2))
    call allsum_scalar_r8(sum_check)
    if(rank==0) write(6,*)' rhopt1_norm2 ',sum_check
    write(6,*)'maxval(rhopt1), maxloc(rhopt1) ',maxval(abs(rhopt1)),maxloc(abs(rhopt1))

    !sum_rhopt1_ps = sum(abs(rhopt1**2),mask=vwktot>0)
  end subroutine debug

  subroutine debug_uk
    implicit none
    write(6,*)' s, b_loc ', s, b_loc, ' <u|vwp|u> ',sum(abs(uk)**2*vwktot,mask=vwktot.ge.0)
    write(6,*)' s, b_loc ', s, b_loc, ' <u|vwn|u> ',sum(abs(uk)**2*vwktot,mask=vwktot<0)
    write(6,*)' s, b_loc ', s, b_loc, ' <u|vw |u> ',sum(abs(uk)**2*vwktot)
  end subroutine debug_uk

  subroutine debug_rhopt
    implicit none
    real*8, allocatable :: vlow(:)
    allocate(vlow(1:nk_low), stat=st)
    call check0(st,' vlow ')
    write(6,*)' <rhopt1(:,1,1)**2 pos ',sum(abs(rhopt1(1:nk_low,1,1))**2*vlow,mask=vlow.ge.0)
    write(6,*)' <rhopt1(:,1,1)**2 neg ',sum(abs(rhopt1(1:nk_low,1,1))**2*vlow,mask=vlow<0)
    write(6,*)' <rhopt1(:,1,1)**2 tot ',sum(abs(rhopt1(1:nk_low,1,1))**2*vlow)
  end subroutine debug_rhopt
end subroutine rhopt1_make

