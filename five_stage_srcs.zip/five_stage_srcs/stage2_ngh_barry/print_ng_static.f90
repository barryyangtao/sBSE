subroutine print_ng_static
  use neargap
  use simple_mpi, only : rank
  implicit none
  integer is,i,st

  if(rank==0) then
     open(14,file='ng_static.bin',form='unformatted',status='replace')
     write(14)nv,nc,ntot,nsp,ekcut,n,nn
     write(14)kcut_vw,nalpha,alpha_coverage
     write(14)gamW,ampW,ampbare,periodic
     write(14)charge,tp
     write(14)crot
     write(14)hmnox
     write(14)focc
     write(14)pm
     write(14)functional
     close(14)
  end if
end subroutine print_ng_static
