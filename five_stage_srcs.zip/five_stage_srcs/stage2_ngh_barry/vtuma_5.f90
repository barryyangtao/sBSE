subroutine prep_vktuma( nx,ny,nz,dx,dy,dz,vk, g)
  use simple_mpi, only : rank
  implicit none
  integer nx,ny,nz
  integer ix,iy,iz
  integer i
  
  real*8 vk(nx,ny,nz)
  real*8 dx,dy,dz
  real*8 kx,ky,kz
  real*8 dkx,dky,dkz
  real*8 r0(3),rdif(3)
  real*8 a, aa_0,dV,rp,k2
  real*8 pi
  real*8 g, k2s, k2g, cut 
  real*8 cs, cg
  complex*16, allocatable, dimension(:,:,:)  :: cvk
  complex*16, parameter :: ci = (0.d0, 1.d0)
  pi = dacos(-1.d0)
  aa_0 = 7d0/min(nx*dx,ny*dy,nz*dz)
  allocate(cvk(nx,ny,nz),stat=i); if(i/=0)stop ' cvk '  
  dV = 1d0
  if(dx>1e-8)dV=dV*dx
  if(dy>1e-8)dV=dV*dy
  if(dz>1e-8)dV=dV*dz
  r0 = (/ -(nx)/2d0*dx, -(ny)/2d0*dy, -(nz)/2d0*dz /)
  
  if(g<aa_0) then
     a = g
  else
     a = aa_0
  endif
  write(6,*)' g, aa_0, a ',g,aa_0, a !erase
  ! goal: erf(g*r)/r.    for gamma==> infinity we get 1/r.  
  ! separate : 
  !  For g small (<aa_0)
  !     use    v(r)=erf(g*r)/r
  ! For large g  (g.ge.aa_0)
  !          erf(g*r)/r = erf(aa_0*r)/r + (erf(gr)-erf(aa_0*r))/r 
  !  FFT numerically the first part

  do iz=1,nz
     do iy=1,ny
        do ix=1,nx
           rdif = r0 + (/(ix-1)*dx,(iy-1)*dy,(iz-1)*dz/)
           rp  = sqrt(max(sum(rdif**2),1e-12))
           cvk(ix,iy,iz) = erf(a*rp)/rp * dv
        enddo
     enddo
  enddo

  call fft3d_general(cvk, Nx, Ny, Nz, 1)  

  
  dkx = 0d0 ; if(dx>1e-8) dkx = 2.d0*pi/(dble(Nx)*dx)
  dky = 0d0 ; if(dy>1e-8) dky = 2.d0*pi/(dble(Ny)*dy)
  dkz = 0d0 ; if(dz>1e-8) dkz = 2.d0*pi/(dble(Nz)*dz)

  do iz=1,nz
     do iy=1,ny
        do ix=1,nx
           
           kx = dble(ix-1)* dkx
           ky = dble(iy-1)* dky
           kz = dble(iz-1)* dkz
           
           if(kx>pi/dx) kx = kx-2d0*pi/dx  
           if(ky>pi/dy) ky = ky-2d0*pi/dy
           if(kz>pi/dz) kz = kz-2d0*pi/dz

           k2 = max(1d-8,kx**2+ky**2+kz**2)  ! DN -- note-- max is new
           
           cvk(ix,iy,iz) = &
           cvk(ix,iy,iz) * exp(ci*( r0(1)*kx+r0(2)*ky+r0(3)*kz ))   

           k2s = k2/(4d0*a**2d0)
           k2g = k2/ (4d0*g**2d0)
           cut = 1d-8
           if(k2s>cut) then
              cs = 4d0*pi/k2*(1d0-exp(-k2s))
           else
              cs = 4d0*pi/k2*(k2s-k2s**2/2d0 +k2s**3/6d0) 
           end if

           if(k2g>cut) then
              cg = 4d0*pi/k2*(1d0-exp(-k2g))
           else
              cg = 4d0*pi/k2*(k2g - k2g**2/2d0+k2g**3/6) 
           end if

           !if(g.ge.aa_0) then ! possibly un-erase
              cvk(ix,iy,iz) =  cvk(ix,iy,iz) +  (cs-cg)
           !endif
        enddo
     enddo
  enddo
     
  call check_c_real(cvk, size(cvk), ' cv_num ')
  vk =  cvk
  deallocate(cvk, stat=i); if(i/=0) stop ' cvkdeal '

  if(rank==0)then
     write(6,*)
     write(6,*)' Martyna Tuckeran '
     write(6,*)' dv,aa ( tuma ),g, r0 = ',real(dv),real(aa_0),real(g),real(r0)
     write(6,*)' minval, maxval vk ', &
          real(minval(vk)), real(maxval(vk))
     write(6,*)' vk(1:5,1,1) ',&
          real(vk(1:min(nx,5),1,1))
     write(6,*)' vk(nx,ny,nz-4:nz)',&
          real(vk(nx,ny,max(nz-4,1):nz))
     call flush(6)
  end if
end subroutine prep_vktuma
