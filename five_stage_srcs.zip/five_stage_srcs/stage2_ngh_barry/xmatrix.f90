subroutine u_from_rhopi
  use neargap
  implicit none
  integer is,p,i,st

  call get_nonempty
  
  !  if(.not.allocated(u)) then
  if(allocated(u))deallocate(u)
  allocate(u(ncomb1,nemp,ntot,nsp), stat=st)  !nemp: to account for partial charge
  call check0(st,' u ')
!  end if
  
  do is=1,nsp
     do p=1,ntot
        u(:,:,p,is)=matmul(rhopt1(:,:,p),crot(:,1:nemp,is))
     enddo
  enddo

  do is=1,nsp
     do i=1,nemp
        u(:,i,:,is) = u(:,i,:,is)*sqrt(focc(i,is))
     enddo
  enddo

contains
  subroutine get_nonempty ! highest non-empty level
    real*8 :: toll=1d-7
    nemploop: do nemp=ntot,1,-1
       if(maxval(focc(nemp,:))>toll) exit nemploop
    enddo nemploop
  end subroutine get_nonempty
end subroutine u_from_rhopi

subroutine alloc_xm
  use neargap
  implicit none
  integer st
  if(.not.allocated(xm)) then
     allocate(xm(ntot,ntot,nsp), stat=st)
     call check0(st,' xm ')
  endif
end subroutine alloc_xm

subroutine xmatrix(u)
  use neargap, only : kind_gamma_c, ncomb1,ntot,  nsp, xm, ampw, sign_comb1, nemp
  implicit none
  integer is,st
  complex(kind=kind_gamma_c) :: &
       u(ncomb1*nemp,ntot,nsp)  ! <k|phi_b psi_i>, for a strip of k
  complex(kind=kind_gamma_c), allocatable :: uH_sign(:,:)

  allocate(uH_sign(ntot,ncomb1*nemp), stat=st)
  call check0(st,' uH ')

  do is=1,nsp
     uH_sign = transpose(conjg(u(:,:,is)))
     call mult_uH_sign(uH_sign)
     xm(:,:,is) = - matmul(uH_sign(:,:), u(:,:,is))
  enddo

  !xm = xm*ampw  ! note don't multiply because we already have this factor...

contains
  subroutine mult_uH_sign(uH_sign)
    integer icomb1
    complex(kind=kind_gamma_c) uH_sign(ntot,ncomb1,nemp)
    do icomb1 = 1, ncomb1
       uH_sign(:,icomb1,:) = uH_sign(:,icomb1,:)* sign_comb1(icomb1)
    enddo
  end subroutine mult_uH_sign
end subroutine xmatrix
