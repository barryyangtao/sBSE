subroutine set_nalpha_pos_neg
  use neargap
  use simple_mpi, only : rank, bcast_scalar_i
  implicit none
  real*8, parameter :: frac_min=0.1 ! minimum amount for negative alpha.

  if(frac_vwk_neg>0) then
     na_neg = ceiling(max(frac_vwk_neg,frac_min)* nalpha)
     call check_lele(1,na_neg,nalpha-1,' 1 na_neg, na_alpha-1 ')
  else
     na_neg = 0
  endif

  na_pos = nalpha - na_neg

  call bcast_scalar_i(na_pos)
  call bcast_scalar_i(na_neg)

  if(rank==0) write(6,*)' nalpha_pos, nalpha_neg ',na_pos, na_neg
end subroutine set_nalpha_pos_neg
