subroutine rotate_xcore_mo_to_ao(is)
  use neargap
  implicit none
  integer is
  integer i,j
  
  if(.not.allocated(hevc)) then
     if(iscf/=1) stop ' rotate problem '
     return ! no need to rotate in first iteration
  end if

  call check_unity_hevc_times_htranspose
  if(maxval(abs(crot(:,:,is)-hevc(:,:,is)))>1d-8) stop ' crot /= hevc '
  
  ! the following may be erased
  !do i=lbound(xcore,1),ubound(xcore,1)
  !   do j=1,lbound(xcore,2),ubound(xcore,2)
  !      if(i/=j) xcore(i,j,is) = 0d0 ! possibly erase
  !   enddo
  !enddo
     
  xcore(:,:,is) = matmul(hevc(:,:,is),xcore(:,:,is))
  xcore(:,:,is) = matmul(xcore(:,:,is),transpose(hevc(:,:,is)))

  
contains
  subroutine check_unity_hevc_times_htranspose
    use simple_mpi, only : check_tag, rank
    integer st, i
    real*8, allocatable :: am(:,:)
    real*8, parameter :: toll=1d-8
    if(rank==0) then
       allocate(am(ntot,ntot),stat=st)
       call check0(st,' am ')
       am=matmul(hevc(:,:,is),transpose(hevc(:,:,is)))
       do i=1,ntot
          am(i,i)=am(i,i)-1d0
       enddo
       
       if(maxval(abs(am))>toll) then
          write(6,*)' is, hevc*hevcT isnt unity ',is, real(maxval(abs(am))),' at ',maxloc(abs(am))
          stop
       end if
    endif

    call check_tag
  end subroutine check_unity_hevc_times_htranspose
end subroutine rotate_xcore_mo_to_ao
