subroutine split_vw
  use neargap
  use simple_mpi, only : rank
  implicit none
  integer st

  call map_vwk_low_high
  
  allocate(vwktot_low(nk_low), stat=st)
  call check0(st,' vwktot_low ')

  allocate(vwktot_high_pos(nk_high_pos), stat=st)
  call check0(st,' vwktot_high_pos ')

  allocate(vwktot_high_neg(nk_high_neg), stat=st)
  call check0(st,' vwktot_high_neg ')

  if(periodic) then
     call split_vw_inside(vwktot, vwktot_low, vwktot_high_pos, vwktot_high_neg)
  else
     call split_vw_inside(vwktot, vwktot_low, vwktot_high_pos, vwktot_high_neg)
  end if

  if(rank==0) write(6,*)' vwktot_low,high_pos, high_neg ',&
       sum(abs(vwktot_low)), sum(abs(vwktot_high_pos)), sum(abs(vwktot_high_neg))
  
end subroutine split_vw

subroutine map_vwk_low_high
  use neargap
  use simple_mpi, only : rank
  implicit none
  integer i, j, jp,jn, ik, irep, st
  real*8 sum_vwk_high_pos
  real*8 sum_vwk_high_neg
!un-erase, put here rather than 0*0  real*8, allocatable :: k2_a(:)   ! k squared array, for usual or doubled grid
  !call make_k2_a
  
  i=0
  j=0
  jp=0
  jn=0
  do ik=1,size(k2_a)
     if(sqrt(k2_a(ik))<kcut_vw) then
        i=i+1
     else
        j=j+1
        if(vwktot(ik).ge.0) then
           jp=jp+1
        else
           jn=jn+1
        endif
     end if
  enddo
  nk_low = i
  nk_high_pos = jp
  nk_high_neg = jn
  nkhigh = j

  call check(nk_high_pos+nk_high_neg,nkhigh,' nkhighposneg nkhigh ')
  
  allocate(map_vwklow(nk_low), stat=st)
  call check0(st,' map_nk_low ')

  allocate(map_vwkhigh_pos(nk_high_pos), stat=st)
  call check0(st,' map_nk_high_pos ')

  allocate(map_vwkhigh_neg(nk_high_neg), stat=st)
  call check0(st,' map_nk_high_neg ')

  i=0
  j=0
  jp=0
  jn=0
  do ik=1,size(k2_a)
     if(sqrt(k2_a(ik))<kcut_vw) then

        i=i+1
        map_vwklow(i) = ik

     else

        j=j+1
        
        if(vwktot(ik).ge.0) then
           jp=jp+1
           map_vwkhigh_pos(jp) = ik 
        else
           jn=jn+1
           map_vwkhigh_neg(jn) = ik 
        endif
        
     end if

  enddo

  call check(i,nk_low,' i, nk_low')
  call check(j,nkhigh,' j, nkhigh')
  call check(nk_low+nkhigh,size(k2_a),' nvw low plus high vs. size(k2_a) ')

  sum_vwk_high_pos =  sum(vwktot(map_vwkhigh_pos))
  sum_vwk_high_neg =  sum(vwktot(map_vwkhigh_neg))
  frac_vwk_neg     = abs(sum_vwk_high_neg)/(sum_vwk_high_pos+abs(sum_vwk_high_neg))
  
  if(rank==0) write(6,*)' vwk_high: pos vs. neg ',real(sum_vwk_high_pos), real(sum_vwk_high_neg)
  if(rank==0) write(6,*)' frac_vwk_neg ',real(frac_vwk_neg)

  !call debug

contains

  subroutine debug
    implicit none
    integer ik
    if(scale_vh==2) then
       write(6,*)' maxval,maxloc vwktot_low ',&
            maxval(abs(vwktot(map_vwklow(:)))), &
            maxloc(abs(vwktot(map_vwklow(:))))
       ik = product( maxloc(abs(vwktot(map_vwklow(:)))))
       write(6,*)' maxvwlow: ik, k2_a ',ik,k2_a(ik)
    
       write(6,*)' maxval,maxloc vwktot_high ',&
            maxval(abs(vwktot(map_vwkhigh_pos(:)))), &
            maxloc(abs(vwktot(map_vwkhigh_pos(:))))
       ik = product( maxloc(abs(vwktot(map_vwkhigh_pos(:)))))
       write(6,*)' maxvwhigh_pos: ik, k2_a ',ik,k2_a(ik)
    endif
  end subroutine debug
end subroutine map_vwk_low_high
  
subroutine split_vw_inside( vwk, vwk_low, vwk_high_pos, vwk_high_neg)
  use neargap
  use simple_mpi, only : rank
  implicit none
  integer i,ik
  real*8 vwk(*), vwk_low(nk_low), vwk_high_pos(nk_high_pos), vwk_high_neg(nk_high_neg)

  if(rank==0) write(6,*)' vwk (pre-low) ',sum(vwk(1:n*scale_vh**3)) 
  vwk_low(:) = vwk(map_vwklow(:))
  vwk_high_pos(:) = vwk(map_vwkhigh_pos(:))
  vwk_high_neg(:) = vwk(map_vwkhigh_neg(:))

  !if(neta.ne.0) then ! if using eta, zero vwk in its low parts, as eta is using vwk, not vwk_high
  !   stop ' need to modify vwklow if neta=0 '
  !   vwk(map_vwklow(:)) = 0
  !endif

  if(rank==0) then
     write(6,*)' vwk_low ',sum(vwk_low)
     write(6,*)' vwk_high_pos  ',sum(vwk_high_pos)
     write(6,*)' vwk_high_neg  ',sum(vwk_high_neg)
     write(6,*)' nk_low ',nk_low
     write(6,*)' nk_high ',nkhigh
     write(6,*)' nk_high_pos ',nk_high_pos
     write(6,*)' nk_high_neg ',nk_high_neg
  endif

end subroutine split_vw_inside
