subroutine make_ncoreloc
  use neargap
  use simple_mpi, only : rank, allsum_scalar_i
  implicit none
  integer i, iloc, isum

  iloc=0
  do i=1,ncore
     if(mod(i-1,nds)==rank) iloc=iloc+1
  end do
  ncoreloc = iloc
  
  isum= ncoreloc
  call allsum_scalar_i(isum)
  call check(isum,ncore,' sum_ncoreloc ')
end subroutine make_ncoreloc
