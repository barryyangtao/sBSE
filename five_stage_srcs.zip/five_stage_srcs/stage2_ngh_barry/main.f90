program main
  implicit none
  call prepare_mpi
  call main_neargap
  call finalize_mpi
end program main

subroutine main_neargap
  use neargap
  use simple_mpi, only : nodes
  implicit none
  nds=max(nodes,1)
  call prep
  do iscf=1,nscf
     call make_dens_sp
     call make_vks_valence_noxc
     call make_vxc
     call make_vkstot
     call possibly_core_correct
     call hmatrix
     call diis_h
     call diag_h
     call print_hevl
     call nocc_a_make
     call print_ng_static
     call print_psi ! CORRECTED
     call set_focc
     call set_crot
     call make_P
  end do

contains
  subroutine prep
    call read_param
    call prep_rand88
    call seed_check
    call read_phieps
    call prep_grd
    call prep_nk
    call make_k2_a
    call make_vk
    call split_vw
    call set_nalpha_pos_neg
    call set_ncomb
    call set_sign_comb
    call prep_alpha
    call rho_pi_write_read
    call hsub_prep
    call init_focc
    call init_crot
    call init_P
    if(action_rhoij=='prep')return
  end subroutine prep

end subroutine main_neargap
  
  
