subroutine core_correction(p, xp)
  ! given p, calculate <p|X_core^gamma|q>, p,q in nxcore near gap
  use neargap
  use simple_mpi, only : allsum_r8
  implicit none
  integer i, st ! i here from 1 to ncoreloc
  real*8 p(1:n), xp(1:n)
  real*8, allocatable  :: dns(:), dnsb(:)
  complex*16, allocatable :: uk(:)

  xp = 0
  !return ! erase

  
  allocate(dns(n), dnsb(nk), uk(nk), stat=st)
  call check0(st,' pair ')

  select case(nstocore)
  case(0)
     xp= 0
     !return
  case(-1)
     xp = 0
     do i=1, ncoreloc
        dns = p*phi_core_loc(:,i)
        call broaden_dns_to_dnsb
        call fft_dnsb_to_uk
        uk = uk*vwktot/dble(nk)
        call fft3d_backward(nx*scale_vh, ny*scale_vh, nz*scale_vh, uk, uk)
        call check_real(uk, size(uk))
        dnsb = uk
        call narrow_dnsb_to_dns
        xp = xp - phi_core_loc(:,i)*dns
     enddo
  case(1:)
     stop ' rearrange core_correction for nstocore '
     !de = 0
     !if(.not.called_stoch_core_prep) stop ' not called stoc core prep '
     !do i=1,nstocore_loc
     !   dns = p*stoch_core_loc(:,i)
     !   call broaden_dns_to_dnsb
     !   call fft_dnsb_to_uk
     !   de = de - sum(abs(uk)**2*vwktot(:))*dv/dble(nk)
     !enddo
  end select
  call allsum_r8(xp,size(xp))
contains
  subroutine broaden_dns_to_dnsb
    if(mod(nx ,2)/=0.or.mod(ny ,2)/=0.or.mod(nz ,2)/=0) stop ' make nx ,ny ,nz  all even '
    select case(scale_vh)
    case(2); call dns_to_dnsb(dns,dnsb)
    case(1); dnsb= dns
    case default; stop 'scale_vh problem '
    end select
  end subroutine broaden_dns_to_dnsb

  subroutine dns_to_dnsb(dns,dnsb)
    real*8  dns( nx, ny, nz)
    real*8  dnsb(nx*2,ny*2,nz*2)
    integer mx,my,mz,px,py,pz
    call check(scale_vh, 2, 'scale_vh vs. 2 ')

    dnsb = 0d0
    
    mx= 1 + nx - nx/2
    px=     nx + nx/2

    my= 1 + ny - ny/2
    py=     ny + ny/2

    mz= 1 + nz - nz/2
    pz=     nz + nz/2

    dnsb(mx:px,my:py,mz:pz) = dns
  end subroutine dns_to_dnsb

  subroutine narrow_dnsb_to_dns
    if(mod(nx ,2)/=0.or.mod(ny ,2)/=0.or.mod(nz ,2)/=0) stop ' make nx ,ny ,nz  all even '

    select case(scale_vh)
    case(2); call dnsb_to_dns(dnsb,dns)
    case(1); dns = dnsb
    case default; stop 'scale_vh problem2 '
    end select
  end subroutine narrow_dnsb_to_dns

  subroutine dnsb_to_dns(dnsb,dns)
    real*8  dnsb(nx*2,ny*2,nz*2)
    real*8  dns( nx, ny, nz)
    integer mx,my,mz,px,py,pz
    call check(scale_vh, 2, 'scale_vh vs. 2 ')

    mx= 1 + nx - nx/2
    px=     nx + nx/2

    my= 1 + ny - ny/2
    py=     ny + ny/2

    mz= 1 + nz - nz/2
    pz=     nz + nz/2

    dns = dnsb(mx:px,my:py,mz:pz)

  end subroutine dnsb_to_dns
  
  subroutine fft_dnsb_to_uk
    uk = dnsb
    call fft3d_forward(nx*scale_vh, ny*scale_vh, nz*scale_vh, uk, uk)
  end subroutine fft_dnsb_to_uk
end subroutine core_correction

     
     

  
