subroutine dot_xp_to_dxcore(xp, dx_row, is) ! really dX_column
  use neargap
  use simple_mpi, only : scatter_r8, allsum_r8
  implicit none
  integer st, is
  real*8 xp(n), dx_row(ixlow:ixhigh)
  real*8, allocatable :: xp1(:), xpp(:)

  allocate(xp1(n1), xpp(nn), stat=st)
  call check0(st,' xp1 ')

  xpp =0
  xpp(1:n) = xp
  call scatter_r8(xpp, xp1, n1, 0)

  dx_row = dv*matmul(xp1,psi1(:,ixlow:ixhigh,is))

  call allsum_r8(dx_row, size(dx_row))

end subroutine dot_xp_to_dxcore
