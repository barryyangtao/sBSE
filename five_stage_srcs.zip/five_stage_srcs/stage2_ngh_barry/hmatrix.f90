subroutine hmatrix
  use simple_mpi, only : allsum_r8, rank
  use neargap
  implicit none

  call alloc_hm
  call hmatrix_nox
  
  call u_from_rhopi
  call alloc_xm
  call xmatrix(u)  ! stripe
  !write(6,*)' shape(hmnox) ',shape(hmnox)
  !write(6,*)' shape(xcore) ',shape(xcore)
  call allsum_r8(hmnox,size(hmnox))
  call allsum_r8(xm,size(xm))

  if(core_correct)hmnox = hmnox + xcore
  hm = hmnox +xm
  
  !write(6,*)' hmnox ',sum(hmnox**3)
  !write(6,*)' xm    ',sum(xm**3)
  !write(6,*)' hm    ',sum(hm**3)
  
  call print_selected
  call symmetrize_hm
  call debug
contains
  subroutine print_selected
    integer i, imin, imax
    imin=max(nv-2,1)
    imax=min(nv+3,ntot)
    
    if(rank==0) then
       write(6,*)' hm_nox_diag_nearg from to  ',imin,imax, (real(hm(i,i,:)-xm(i,i,:)),i=imin,imax)
       write(6,*)' xm_diag_nearg          ',imin,imax, (real(xm(i,i,:)),i=imin,imax)
    endif
  end subroutine print_selected

  subroutine debug
    implicit none
    integer i, ij(2), st,is
    real*8, allocatable :: hh(:,:)
    if(rank==0) then
       allocate(hh(ntot,ntot), stat=st)
       call check0(st,' hh ')
       hh = hm(:,:,1)
       do i=1,ntot
          hh(i,i)=0
       enddo
       ij=maxloc(abs(hh))
       write(6,*)' i,j, hm(i,J) off diag max ',ij,hm(ij(1),ij(2),1)

       do is=1,nsp
          hh = matmul(hm(:,:,is),pm(:,:,is))-matmul(pm(:,:,is),hm(:,:,is))
          write(6,*)' is, max([h,p])',maxval(abs(hh))
       enddo
       
    end if
  end subroutine debug
    
end subroutine hmatrix

subroutine symmetrize_hm
  use simple_mpi, only : rank, bcast_r8
  use neargap
  implicit none
  integer is
  real*8 diff_rel

  do is=1,nsp
     diff_rel = maxval(abs(hm(:,:,is)-transpose(hm(:,:,is))))/maxval(abs(hm))
     if(diff_rel>1d-8) then
        if(rank==0) then
           write(6,*) real(diff_rel), iscf,is, ' hm assymetry iscf, is '
        endif
     endif
     hm(:,:,is)=(hm(:,:,is)+transpose(hm(:,:,is)))/2
  end do

  call bcast_r8(hm, size(hm), 0)
end subroutine symmetrize_hm


