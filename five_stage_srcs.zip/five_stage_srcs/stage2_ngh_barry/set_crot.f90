subroutine set_crot
  use neargap
  use simple_mpi, only: bcast_r8, rank
  implicit none
  integer i
  if(.not.allocated(crot))stop ' crotnot '

  do i=1,ntot
     crot(i,:,:)=hevc(i,:,:)!*sqrt(focc(:,:))
  end do

  call bcast_r8(crot,size(crot),0)

end subroutine set_crot
