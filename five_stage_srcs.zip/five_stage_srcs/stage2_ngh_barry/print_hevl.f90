subroutine print_hevl
  use neargap
  use neargap, only : Har=>Hartree_to_eV
  use simple_mpi, only : rank, check_tag
  implicit none
  integer i, imin, imax, st, is
  integer ip
  logical dir_exists
  character(len=1024) char_rank,name
  real*8, allocatable :: elumo(:), ehomo(:)
  allocate(ehomo(nsp), stat=st); call check0(st,' ehomo ')
  allocate(elumo(nsp), stat=st); call check0(st,' elumo ')
  ip=50
  if(rank==0) then
     inquire(file='./'//trim(adjustl('hevl')), exist=dir_exists)
     if(.not.dir_exists) then
        call system("mkdir " // trim(adjustl('hevl')) )
        inquire(file=trim(adjustl('hevl')), exist=dir_exists)
        if(.not.dir_exists) stop ' cant open hevl '
     endif
     
     call cnvrt_number_1K_string(1000+iscf,char_rank)
     name = trim(adjustl('hevl'))//'/evl.'//trim(adjustl(char_rank))
     open(ip,file=trim(adjustl(name)),status='replace')
     
     do i=1,ntot
        write(ip,*) i, real(hevl(i,:)), real(focc(i,:))
     end do
     close(ip)
  end if
  
  imin=max(nv-3,1)
  imax=min(nv+4,ntot)
  if(rank==0) then
     write(6,*)
     do i=imin,imax
        write(6,*)i,real(hevl(i,:)),iscf,' i evl(i)_Hartree iscf '
     enddo
     do i=imin,imax
        write(6,*)i,real(hevl(i,:)*Har),iscf,' i evl(i)_eV iscf '
     enddo
     !write(6,*) real((hevl(nv+1,:)-hevl(nv,:))),iscf,    ' gap(Hartree) iscf '
     do is=1,nsp
        do i=1,ntot-1
           if(focc(i,is)>0.5d0.and.focc(i+1,is).le.0.5d0) exit
        enddo
        if(i.ge.ntot-1)stop ' focc problem '
        ehomo(is) = hevl(i,is)
        elumo(is) = hevl(i+1,is)
     enddo
     write(6,*) real((elumo-ehomo)*Har),iscf,' gap_eV(1:nsp) iscf '
  endif
  
  call check_tag
end subroutine print_hevl

subroutine print_hevl0(hevl0)
  use neargap
  use neargap, only : Har=>Hartree_to_eV
  use simple_mpi, only : rank
  implicit none
  integer i, imin, imax, ip
  real*8 hevl0(ntot)
  logical dir_exists
  character(len=1024) char_rank,name
  iscf=0
  ip=50
  if(rank==0) then
     inquire(file='./'//trim(adjustl('hevl')), exist=dir_exists)
     if(.not.dir_exists) then
        call system("mkdir " // trim(adjustl('hevl')) )
        inquire(file=trim(adjustl('hevl')), exist=dir_exists)
        if(.not.dir_exists) stop ' cant open hevl '
     endif
     
     call cnvrt_number_1K_string(1000+iscf,char_rank)
     name = trim(adjustl('hevl'))//'/evl.'//trim(adjustl(char_rank))
     open(ip,file=trim(adjustl(name)),status='replace')
     
     imin=max(nv-4,1)
     imax=min(nv+5,ntot)
     if(rank==0) then
        write(6,*)
        do i=imin,imax
           write(6,*)i,real(hevl0(i)),iscf,' i evl(i)_Hartree iscf '
        enddo
        do i=imin,imax
           write(6,*)i,real(hevl0(i)*Har),iscf,' i evl(i)_eV iscf '
        enddo
        write(6,*) real((hevl0(nv+1)-hevl0(nv))),iscf,    ' gap(Hartree) iscf '
        write(6,*) real((hevl0(nv+1)-hevl0(nv))*Har),iscf,' gap(eV)     iscf '
        write(6,*)
     endif

  end if

end subroutine print_hevl0
