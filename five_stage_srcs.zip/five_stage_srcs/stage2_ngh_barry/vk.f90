subroutine make_vk
  use neargap
  use neargap, only : vwk=>vwktot
  use simple_mpi, only : rank
  implicit none
  integer st, ngb
  logical, save :: first=.true.
  if(.not.first) return
  first=.false.

  select case(scale_vh)
  case(1)
     allocate(vk(n),  stat=st)
     call check0(st,' vk ')
     scissors_shift_v0 = 0d0
     
     if(periodic) then;
        allocate(vwk(n),  stat=st)
        call check0(st,' vk ')
        scissors_shift_v0 = 0d0
        call make_vk_vwk_periodic
        !else;               call make_vk1_tuma
     else; stop ' use scale_vh=2 for non periodic '
     end if

  case(2)
     if(periodic) stop ' error, scale_vh==2 and periodic '

     ngb =n*8
     allocate(vkb(ngb), vwk(ngb),  stat=st)
     call check0(st,' vk, vwk,  ')

     call make_vkb_tuma
  case default
     stop ' scale_vh '
  end select

  !where(vwk<0) vwk=0  ! erase
  !vwk = abs(vwk) ! erase
contains

  subroutine make_vkb_tuma
    integer i, ngb, nxb, nyb, nzb

    nxb = scale_vh*nx
    nyb = scale_vh*ny
    nzb = scale_vh*nz
    ngb = nxb*nyb*nzb; 
    
    if(mod(nx ,2)/=0.or.mod(ny ,2)/=0.or.mod(nz ,2)/=0) stop ' make nx ,ny ,nz  all even '
    if(mod(nxb,2)/=0.or.mod(nyb,2)/=0.or.mod(nzb,2)/=0) stop ' make nxb,nyb,nzb all even '
    if(abs(ngb-dble(nxb)*dble(nyb)*dble(nzb))>1d-4) stop ' ngb not proper ; maybe need integer*8 '

    call prep_vktuma(nxb,nyb,nzb,dx,dy,dz,vkb,big)
    if(rank==0) then
       write(6,*)' vkb(1:3)        ',real(vkb(1:3))
       write(6,*)' vkb(1:3)/volume ',real(vkb(1:3)/(ngb*dv))
       write(6,*)' 4*pi/k^2(1:3)   ',real(0d0), real(4*3.14/k2_a(2:3))
       write(6,*)count(vkb<0),' count(vkb<0), big '
    endif
       
    call prep_vktuma(nxb,nyb,nzb,dx,dy,dz,vwk,gamw)
    if(rank==0) write(6,*)count(vwk<0),real(gamw),' count(vwk<0), gamw '
    vwk=  ampbare*vkb + ampw*vwk

    call print_vwk
    
    scissors_shift_v0 = vwk(1)/(ngb*dv)
    vwk(1) = 0
    if(rank==0) then
       write(6,*)' scissors_shift_v0 ',scissors_shift_v0
    endif
    
  end subroutine make_vkb_tuma

end subroutine make_vk

subroutine make_vk_vwk_periodic
  use neargap
  use neargap, only : vwk=>vwktot
  use simple_mpi,only :rank
  implicit none
  integer i, st
  integer ikx, iky, ikz
  real*8  dkx, dky, dkz
  real*8   kx, ky,  kz
  real*8   k2
  real*8   pi

  call check(n, nx*ny*nz, ' n, nxyz ')

  pi = dacos(-1d0)
  dkx = 2d0*pi/(nx*dx)
  dky = 2d0*pi/(ny*dy)
  dkz = 2d0*pi/(nz*dz)
  
  i=0
  do ikz=1,nz
     do iky=1,ny
        do ikx=1,nx
           i=i+1
           kx = (ikx-1)*dkx
           ky = (iky-1)*dky
           kz = (ikz-1)*dkz
           if(kx>pi/dx)kx=kx-2d0*pi/dx
           if(ky>pi/dy)ky=ky-2d0*pi/dy
           if(kz>pi/dz)kz=kz-2d0*pi/dz
           k2 = kx**2 + ky**2 + kz**2

           if(k2>1d-8) then
              vk(i)=4*pi/k2
              vwk(i) = 4*pi/k2*exp(-k2/(4*gamw**2))

           else
              
              vk(i) = 0d0
              vwk(i) = 0d0
           end if
        enddo
     enddo
  enddo
  
  vwk = ampbare*vk +  ampw*vwk

  call print_vwk
  if(rank==0) write(6,*)' vwk when made ',maxval(abs(vwk))
  if(rank==0) write(6,*) ' #, fraction vwk ',count(vwk<1d-10), count(vwk<1d-10)/dble(n)
  if(rank==0) call flush(6)
end subroutine make_vk_vwk_periodic

subroutine print_vwk
  use neargap
  use neargap, only : vwk=>vwktot
  use simple_mpi, only : rank, check_tag
  implicit none
  integer i
  if(rank==0) then
     open(39,file='vwk.txt',status='replace')
     do i=1,size(vwk)
        write(39,*)i,vwk(i)
     enddo
     call flush(39)
     close(39)
  end if
  call check_tag
end subroutine print_vwk  
