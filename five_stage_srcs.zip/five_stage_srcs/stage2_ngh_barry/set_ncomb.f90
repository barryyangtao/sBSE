subroutine set_ncomb
  use neargap
  use simple_mpi, only : rank, nodes, bcast_scalar_general_i
  implicit none
  integer m, ir

  ! set ncomb
  ncomb = nk_low + nalpha
  
  ncomb1 = ncomb/nds  ! strip size
  if(ncomb1*nds<ncomb) ncomb1=ncomb1+1
  nncomb = ncomb1*nds ! strip*nds, may exceed ncomb

  ! now print
  if(rank==0) then
     write(6,*)
     write(6,*)' nk_low, nalpha, na_pos, na_neg, ncomb, nncomb, ncomb1 ', &
                 nk_low, nalpha, na_pos, na_neg, ncomb, nncomb, ncomb1 
     write(6,*)
     call flush(6)
  endif
  
  ! now checking that the values are equal on each core
  do ir=0,nds-1
     m=-99
     if(rank==ir) m = ncomb
     call bcast_scalar_general_i(m,ir)
     if(m.ne.ncomb) stop ' ncomb diff. across cores -- error '
  end do
  
end subroutine set_ncomb
