subroutine make_P
  use neargap
  implicit none
  integer is, st, i
  real*8, allocatable :: sqP(:,:)
  allocate(sqP(ntot,ntot), stat=st)
  if(st/=0) stop ' sqP '
  
  do is=1,nsp
     sqP = crot(:,:,is)

     do i=1,ntot
        sqP(:,i) = sqP(:,i)*sqrt(focc(i,is))
     enddo
     
     pm(:,:,is) = matmul(sqP,transpose(sqP))
  enddo
  
end subroutine make_P

subroutine init_P
  use neargap
  implicit none
  integer st
  allocate(pm(ntot,ntot,nsp), stat=st)
  if(st/=0) stop ' ctot '
  call make_P
end subroutine init_P
