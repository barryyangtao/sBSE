subroutine nocc_a_make
  use neargap
  use simple_mpi, only : rank
  implicit none
  integer i, is, st

  if(.not.allocated(nocc_a)) then
     allocate(nocc_a(nsp), stat=st)
     call check0(st,' nocc_a ')
  endif
  
  do is=1,nsp
     do i=1,ntot-1
        if(focc(i,is)>0.5d0.and.focc(i+1,is).le.0.5d0) exit
     enddo
     if(i.ge.ntot-1)stop ' focc problem '
     nocc_a(is) = ncore + i
  enddo
  if(rank==0) then
     write(6,*)' nocc_a(1:nsp) ',nocc_a(:)
  endif
end subroutine nocc_a_make
