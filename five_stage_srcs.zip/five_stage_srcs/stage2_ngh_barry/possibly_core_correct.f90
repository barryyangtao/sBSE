subroutine possibly_core_correct
  use neargap
  implicit none
  integer is, i, st 
  real*8, allocatable :: p(:), xp(:)

  ! Return in most cases
  if(.not.core_correct) return
  call check_le(2,nxcore,' two_nxcore ')

  ! first time
  if(.not.allocated(dxcore)) then
     allocate(dxcore(ixlow:ixhigh, ixlow:ixhigh,nsp), stat=st)
     call check0(st,' dxcore ')
     dxcore = 0
  endif

  if(.not.allocated(xcore)) then
     allocate(xcore(ntot,ntot,nsp), stat=st)
     call check0(st,' xcore ')
     xcore = 0
  endif

  
  if(iscf.ne.nscf.and.mod(iscf,icore_correct)/=0) return

  dxcore = 0  
  allocate(p(n), xp(n), stat=st)
  call check0(st,' p in possibly_core ')

  do is=1,nsp


     do i=ixlow,ixhigh
        call get_state(i, is, p)
        call core_correction(p, xp)
        
        call dot_xp_to_dxcore(xp, dxcore(:,i,is), is)
     enddo

     call populate_xcore(is)
     call rotate_xcore_mo_to_ao(is)
  enddo
  call print_core_x_correction
  
end subroutine possibly_core_correct

subroutine map_state_core(i,im)
  use neargap
  implicit none
  integer i,im
  im = nv - nxcore_v + i
end subroutine map_state_core
