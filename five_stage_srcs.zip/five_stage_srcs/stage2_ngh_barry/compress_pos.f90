! compress_kind_g_c:  compresses gh(nh) to galpha(alpha) = <alpha|gh>*cnst; both have kind_gamma_c
! called separately, for high_pos and high_neg
subroutine compress_kind_g_c_pos(gh, galpha)  
!  use neargap
  use neargap, only : kind_gamma_c, istart=>istart_pos
  use neargap, only : La=>l_alpha_pos, na=>na_pos, nh=>nk_high_pos, alph=>alpha_pos
  use simple_mpi, only : rank, nodes
  implicit none
  integer :: ba, st  ! ba=batch
  integer :: iabot, iatop, is, ia  ! is=istart. ia=ialpha
  integer, save :: counter=0
  integer, external :: integer_rand, is_it_power2
  integer, allocatable :: batch(:,:)
  real*8  :: valueRSS_GB
  real*8  :: t0, t1
  real*8  :: tearly, trand, tdot
  complex(kind=kind_gamma_c) :: gh(nh), galpha(na) 
  complex(kind=kind_gamma_c), allocatable :: gtmp(:)

  tearly = 0d0
  trand  = 0d0
  tdot   = 0d0
  
  if(rank==0.and.is_it_power2(counter)==1) then
     
     call  system_mem_usage_GB(valueRSS_GB)
     write(6,*)' counter; system mem usage (GB): 1core, all cores',&
          counter, real(valueRSS_GB),real(valueRSS_GB*max(nodes,1))
  endif
  
  call cpu_time(t0)
  allocate(gtmp(-La+2:nh+La-1),stat=st)
  call check0(st,'gtmp ')
  ! e.g., La=5, nh=20 [-3:24]     ! [-3:0] pad, [1:20] data,  [21:24] pad
  gtmp(1:nh) = gh
  !gtmp(nh:nh+La-1)=0  ! pad gh with zeroes
  gtmp(nh+1:nh+La-1)=0  ! corrected, 7/20/2023 
  gtmp(-La+2:0) = 0 ! padding with 0's
  
  ba = min(na, int(1e6/La))  ! getting a million rand.# at a time
  ba = max(1,ba)

  call cpu_time(t1); tearly = tearly + t1-t0; t0=t1

  ! na=2, la=3:  1,1  2,1  1,2, 2,2 1,3  2,3
  ! na=4, la=3   1,1  2,1, 3,1 4,1 ....
  if(.not.allocated(alph)) then
     call reset_random_seed  ! sets random seed to be the same each time, and same across cores
     allocate(alph(La,na), istart(na), stat=st)
     if(st/=0) then
        write(6,*)' problem in rank=',rank,' memory request: Na*La ',real(Na)*real(La),' per core'
        stop
     endif
     if(rank==0) then;
        write(6,*)' size(alpha) ',size(alph)
        call flush(6)
     end if

     do iabot=1,na,ba
        iatop = min(iabot-1+ba, na)
        allocate(batch(iabot:iatop,La),stat=st)  !batch like this to reduce grid-alpha depend.
        call rand88_i_pm1(batch, size(batch))
        alph(:,iabot:iatop) = transpose(batch)
        deallocate(batch)
     end do

     do ia=1,na
        istart(ia) = integer_rand(La+nh-1)-La+1 ! starting point.
     enddo
  endif
  
  call cpu_time(t1); trand = trand+ t1-t0; t0=t1
  do ia=1,na
     is = istart(ia)
     !Example.  La=5,nh=20.  "is" \in [-3:20]. If is=-3, segment is [-3:1]. For is=20, [20:24]
     galpha(ia) = sum(alph(:,ia)*gtmp(is:is+La-1))  
  end do
  call cpu_time(t1); tdot = tdot+ t1-t0; t0=t1

  galpha = galpha * sqrt(dble(nh+la-1)/dble(na*la))
  ! Using again La=5,nh=20.  is has 24 values, in each i sample eahc point 5 times.

  counter=counter+1
  if(counter.le.4.and.rank==0) then
     write(6,*)' tearly, trand, tdot ',real(tearly),real(trand),real(tdot)
  endif
end subroutine compress_kind_g_c_pos

