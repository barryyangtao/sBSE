! NEW 9/11/2023, making wfhybrid.bin look like wf.bin
subroutine print_psi
  use neargap
  use simple_mpi, only : gather_r8, rank
  implicit none
  integer is, i, st, nst_print
  real*8, allocatable :: p(:)
  integer, allocatable :: icharge_array(:)
  allocate(icharge_array(nsp),stat=st)
  call check0(st,' icharge_array')
  if(nsp==1) then
     icharge_array = nint(charge)
  else
     icharge_array = nint( (/chargeU, chargeD /) )
  end if

  
  if(.not.printpsi) return
  
  if(iscf.ne.nscf) return ! print only at the last iteration
  
  allocate(p(nn), stat=st); call check0(st,' p ')
  if(rank==0) then
     open(12,file='wfhybrid.bin',form='unformatted',status='replace')
     !write(12)nsp,nx,ny,nz,n,dx,dy,dz,dv,nocc,
     write(6,*)' nx = ',nx
     write(12)'nx       ',nx,nv,nc,gamW,ampW,ampbare
     write(12)'ny       ',ny
     write(12)'nz       ',nz
     write(12)'dx       ',dx
     write(12)'dy       ',dy
     write(12)'dz       ',dz
     write(12)'nsp      ',nsp
     write(12)'nstates  ',nv+nc
    !write(12)'orbmn_wf ',1
     write(12)'orbmn_wf ',ncore+1
    !write(12)'ihomo    ',nv, icharge_array(:)
     write(12)'ihomo    ',nocc_a(:),icharge_array(:)
     write(12)'evls     ',shape(transpose(hevl))
     write(12) transpose(hevl(:,:))

     write(12)'dens0core'
     write(12)dens0core
     write(6,*)' integral dens0core dv ',sum(dens0core)*dv
     
     write(12)'vxc0     '
     write(12)vxc
     write(12)'amps     '
     write(12)ampbare,ampw,gamw

     write(12)'orbitals '
  end if
  
  p=0
  do i=1,ntot
     do is=1,nsp
        call gather_r8(psi1(:,i,is),p,n1,0)
        if(rank==0) then
           write(12)i,is,focc(i,is),n
           !write(12)psi1(:,i,is)   
           write(12)p(1:n)
        endif
     end do
  end do
  if(rank==0) close(12)

 
  ! new section for homo-4 to lumo+4 (10 states) printing
  if(rank==0 .and. nv >= 5) then
     open(13,file='homo5_lumo6.txt',form='formatted',status='replace')

     write(13,*) 'nx       ',nx
     write(13,*) 'ny       ',ny
     write(13,*) 'nz       ',nz
     write(13,*) 'dx       ',dx
     write(13,*) 'dy       ',dy
     write(13,*) 'dz       ',dz
     write(13,*) 'nsp      ',nsp
     write(13,*) 'nstates  ',10
     write(13,*) 'orbmn_wf ',1
     write(13,*) 'ihomo    ',0
     write(13,*) 'evls'

     ! print eigenvalues
     do is=1,nsp
        write(13,*) hevl(nv-4,is), hevl(nv-3,is), hevl(nv-2,is), hevl(nv-1,is), hevl(nv,is), &
                    hevl(nv+1,is), hevl(nv+2,is), hevl(nv+3,is), hevl(nv+4,is), hevl(nv+5,is)
     end do
     write(13,*) 'orbitals '
  end if

  p = 0
  do i = 1, ntot
     do is = 1, nsp
        if (i >= nv-4 .and. i <= nv+5) then
           call gather_r8(psi1(:,i,is),p,n1,0)
           if(rank==0) then
              write(13,*) i-nv,is
              write(13,*) p(1:n)
           end if
        end if
     end do
  end do

  if(rank==0) close(13)

  ! special case: small nv, print all occupied and 5 unoccupied
  if (rank == 0 .and. nv < 5) then
     open(14,file='small_nv.txt',form='formatted',status='replace')
     write(14,*) 'nx       ',nx
     write(14,*) 'ny       ',ny
     write(14,*) 'nz       ',nz
     write(14,*) 'dx       ',dx
     write(14,*) 'dy       ',dy
     write(14,*) 'dz       ',dz
     write(14,*) 'nsp      ',nsp
     write(14,*) 'nstates  ',nv+5
     write(14,*) 'orbmn_wf ',1
     write(14,*) 'ihomo    ',0
     write(14,*) 'evls'
     do is=1,nsp
        write(14,*) (hevl(i,is), i=1,nv+5)
     end do
     write(14,*) 'orbitals '
  end if

  p=0
  if (nv <= 5) then
     do i = 1, nv+5
        do is=1,nsp
           call gather_r8(psi1(:,i,is),p,n1,0)
           if(rank==0) then
              write(14,*) i-nv,is
              write(14,*) p(1:n)
           endif
        end do
     end do
     if(rank==0) close(14)
  endif
  
end subroutine print_psi
