subroutine make_dens_sp
  use neargap
  use simple_mpi, only : gather_r8, bcast_r8, rank
  implicit none
  integer st, is, i
  real*8, allocatable :: dens_sp1(:), dn(:)

  if(.not.allocated(psi1))then
     allocate(psi1(n1,ntot,nsp),stat=st)
     if(st/=0) stop ' psi1 '
  endif
     
  allocate(dens_sp1(n1), dn(nn), stat=st)
  if(st/=0) stop ' ctot '

  do is=1,nsp
     psi1(:,:,is)=matmul(ptot1,crot(:,:,is))
  enddo

  dn=0
  do is=1,nsp
     dens_sp1(:)=0d0
     do i=1,ntot
        dens_sp1 = dens_sp1 + 2/dble(nsp)*focc(i,is)*abs(psi1(:,i,is))**2
     enddo
     call gather_r8(dens_sp1(:), dn, n1, 0)
     if(rank==0) dens_sp(:,is) = dn(1:n) + dens0core/nsp
  enddo

  if(rank==0) dens = sum(dens_sp,dim=2)

  call bcast_r8(dens_sp,size(dens_sp),0)
  call bcast_r8(dens,size(dens),0)

  if(rank==0) write(6,*)' number_of_electrons ',real(sum(dens*dv)),' i.e., -charge_electrons '

end subroutine make_dens_sp


  
