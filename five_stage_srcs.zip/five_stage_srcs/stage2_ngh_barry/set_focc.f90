subroutine init_focc
  use neargap
  use simple_mpi, only : rank, bcast_r8
  implicit none
  integer ifull,st,i,is
  real*8 diff
  allocate(focc(ntot,nsp),rnel_val(nsp), stat=st)
  if(st/=0) stop ' focc '

  allocate(mu(nsp), mubot(nsp), mutop(nsp), stat=st)
  if(st/=0) stop ' mubot '
  
  focc = 0

  if(nsp==1) then
     rnel_val = rnel-2*ncore
  else
     rnel_val(1) = rnel/2-ncore + (-(chargeU-chargeD)/2)
     rnel_val(2) = rnel/2-ncore + (-(chargeD-chargeU)/2)
  endif

  if(rank==0) write(6,*)' rnel_val (# valence electrons in each spin) ',real(rnel_val)

  do is=1,nsp
     ifull = floor(rnel_val(is)*nsp/2d0) 
     call check_le(ifull+1,ntot,'ifullp1, ntot ')
     focc(1:ifull,is) = 1
  enddo
     
  select case(nsp)
  case(1)
     diff = rnel_val(1)-sum(2*focc)
     if(diff<0) stop ' error: problem with focc and diff<0 '
     if(diff>2) stop ' error: problem with focc and diff>2 '
     focc(ifull+1,:) = diff/2d0
  case(2)
     do is=1,nsp
        ifull = floor(rnel_val(is)*nsp/2d0) 
        diff = rnel_val(is)-sum(focc(:,is))
        !if(rank==0) write(6,*)' is,ifull, focc, diff ',ifull,real(focc(:,is)),real(diff)
        if(diff<0) stop ' error: problem with focc and diff<0 '
        if(diff>1) stop ' error: problem with focc and diff>1 '
        !if(diff.le.1) then
        !   if(is==1)focc(ifull+1,is) =  diff
        !   if(is==2)focc(ifull+1,is) = 0
        !else
        !   if(is==1) focc(ifull+1,is) = 1d0
        !   if(is==2) focc(ifull+1,is) = diff-1d0
        !end if
        focc(ifull+1,is) = diff
     end do
  end select

  do is=1,nsp
     call check_r(rnel_val(is), 2d0/nsp*sum(focc(:,is)), ' rnel_val_is, (2 or 1)*sum_focc(:,is) ')
  end do
  
  if(rank==0) then
     write(6,*)' near-fermi-level initial occupation focc '
     do i=max(nv-2,1),min(nv+2,ntot)
        write(6,*)i, real(focc(i,:))
     enddo
  end if

  call bcast_r8(focc, size(focc), 0)
end subroutine init_focc
  
subroutine set_focc
  use neargap
  use simple_mpi, only : bcast_r8, rank
  implicit none
  integer i,irep,is,st
  real*8, allocatable :: sum_ne(:)
  real*8, external :: expm

  allocate(sum_ne(nsp), stat=st)
  if(st/=0) stop ' sum_ne '
  
  do is=1,nsp
     mubot(is) = minval(hevl(:,is))
     mutop(is) = maxval(hevl(:,is))
  enddo
     
  do irep=1,90
     mu=(mubot+mutop)/2
     do is=1,nsp
        do i=1,ntot
           focc(i,is) = 1d0/(1d0+expm((hevl(i,is)-mu(is))*beta))
        enddo
     
        sum_ne(is) = sum(focc(:,is))* 2d0/nsp
        
        if(sum_ne(is)>rnel_val(is)) then
           mutop(is) = mu(is)
        else
           mubot(is) = mu(is)
        end if
     enddo
  end do
  if(rank==0) write(6,*)' number of valence_electorns ',real(sum_ne)

  if(rank==0) then
     write(6,*)' near-fermi-level occupation focc, iscf= ',iscf
     do i=max(nv-3,1),min(nv+3,ntot)
        write(6,*)i, real(focc(i,:))
     enddo
  end if

  call bcast_r8(focc, size(focc), 0)
end subroutine set_focc

real*8 function expm(x)
  implicit none
  real*8 x, xa
  xa =min(x,50d0)
  xa = max(xa,-50d0)
  expm = exp(xa)
end function expm
