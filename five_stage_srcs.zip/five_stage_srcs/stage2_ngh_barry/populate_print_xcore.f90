subroutine populate_xcore(is) ! scissors for states not very-near-gap
  use neargap
  use simple_mpi, only : rank
  implicit none
  integer is, i
  xcore(:,:,is) = 0
  !return !erase
  
  call check_lelele(1,ixlow,ixhigh,ntot,' one, ixlow,ixhigh, ntot ')

  xcore(ixlow:ixhigh,ixlow:ixhigh,is) = dxcore(:,:,is) ! fixed 2/19/24

  if(rank==0) write(6,*)' is, xcoroelow, ',is,dxcore(ixlow,ixlow,is)
  if(rank==0) write(6,*)' is, xcorehigh  ',is,dxcore(ixhigh,ixhigh,is)
  
  do i= 1, ixlow-1
     xcore(i,i,is) = dxcore(ixlow,ixlow,is)
  enddo

  do i= ixhigh+1, ntot
     xcore(i,i,is) = dxcore(ixhigh,ixhigh,is)
  enddo

  if(rank==0.and.ntot<10) then
     do i=1,ntot
        write(6,*)' is, i, xcore ',is, i,real(xcore(:,i,is))
     enddo
  endif

end subroutine populate_xcore
