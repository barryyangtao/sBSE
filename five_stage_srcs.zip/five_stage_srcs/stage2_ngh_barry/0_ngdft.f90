module neargap
  implicit none
  save
  logical, parameter :: diis_true=.true.
  character*30, parameter :: scratch_dir='rho_storage' ! doesnt have to exist, will be made.
  integer, parameter :: kind_gamma=4
  integer, parameter :: kind_gamma_c = kind_gamma
  real*8, parameter :: Hartree_to_eV = 27.211396
  real*8, parameter :: big = 1d10

  ! complex(kind=4) is the same as complex*8
  ! complex(kind=8) is the same as complex*16

  character*30 action_rhoij
  character*30 functional
  logical :: periodic
  logical :: alpha_compression
  logical :: printpsi
  logical :: called_stoch_core_prep=.false.
  logical :: core_correct ! NEW 7/5/2023
  
  integer icore_correct ! <1 not correcting;else how often correcting (& at end)  
  integer nds ! max(nodes,1)
  integer nsp ! nspin=1,2
  integer scale_vh  ! 1 for periodic, 2 for Martyna-Tuckerman
  integer nk_low ! number of low-kterms in nvw
  integer nkhigh, nk_high_pos, nk_high_neg ! number of high-kterms in nvw
  integer nalpha, na_pos, na_neg !# of stochastic compression vec
  integer l_alpha_pos, l_alpha_neg
  integer ncomb, ncomb1,nncomb ! ncomb=nk_low+nalpha; ncomb1=ncomb/nds (+1); nncomb = ncomb1*nds
  integer nv, nc, ntot, nemp ! nemp: nv or nv+1
  
  integer nx, ny, nz
  integer n1, nn, n
  integer nk1, nnk, nk, n8
  integer nocc
  integer ncoreloc,ncore
  integer nxcore ! # of stochastic valence orbitals on which we'll act with the exchange.
  integer nxcore_v, nxcore_c ! which associate with valence, which conduction
  integer ixlow, ixhigh ! first and last state for which core correction is calculated explicitly.
  integer nstocore !-1 for analytic core exch,0 for none,>0 :# of stochastic core orb.
  integer nstocore_loc
  integer iscf, nscf
  integer, allocatable :: istart_pos(:)
  integer, allocatable :: istart_neg(:)
  integer, allocatable :: alpha_pos(:,:) ! compression, +-1. pos refers to vwk values applied on.
  integer, allocatable :: alpha_neg(:,:) ! analogously
  integer, allocatable :: map_vwklow(:)
  integer, allocatable :: map_vwkhigh_pos(:)
  integer, allocatable :: map_vwkhigh_neg(:)
  integer, allocatable :: sign_comb(:), sign_comb1(:) ! +1 or -1
  integer, allocatable :: nocc_a(:) ! number of occupied states INCLUDING core, for each spin
  
  real*8  dx, dy, dz, dv,  beta, Tp
  reaL*8, allocatable::  mu(:), mubot(:), mutop(:), rnel_val(:)
  real*8  rnel, rnel_orig, rnel_neutral
  real*8 charge, chargeU, chargeD, n_valence_tot
  ! charge= chargeU+chargeD.if nsp=1, using only charge.  
  real*8  ekcut
  real*8 ampW, gamW, ampbare
  real*8 kcut_vw  ! separates the two ways of sampling vw
  real*8 nalpha_factor ! nalpha = nalpha_factor * nk_low
  real*8 alpha_coverage
  real*8 scissors_shift_v0
  real*8 mix  ! scf
  real*8 frac_vwk_neg ! how much of the vwk (for k>kcut) is negative.  (how much, not how many).
  real*8, allocatable :: phi_core_loc(:,:) ! phi_core(1:n,fewstates). NEW, 7/5/2023
  real*8, allocatable :: ptot1(:,:), etot(:)  ! pv+pc, ev+ec
  real*8, allocatable :: psi1(:,:,:)           ! rotated w.f.
  real*8, allocatable :: vwktot(:)             ! exchange kernel (interaction)
  real*8, allocatable :: vwktot_low(:)         ! low-k sampling
  real*8, allocatable :: vwktot_high_pos(:)         ! high-k sampling for vwk>0
  real*8, allocatable :: vwktot_high_neg(:)         ! high-k sampling for vwk<0
  real*8, allocatable :: k2_a(:)   ! k squared array, for usual or doubled grid
  real*8, allocatable :: grd1(:,:)
  real*8, allocatable :: vk(:), vkb(:)
  real*8, allocatable :: vh(:) ! for debugging
  real*8, allocatable :: dens_sp(:,:) ! spin selective
  real*8, allocatable :: dens0core(:), dens(:) ! not spin-selective
  real*8, allocatable :: vxc(:,:)
  real*8, allocatable :: pm(:,:,:), crot(:,:,:)
  real*8, allocatable :: hm(:,:,:), hmfirsttime(:,:,:),hmnox(:,:,:)
  real*8, allocatable :: xm(:,:,:)
  real*8, allocatable :: hevc(:,:,:), hevl(:,:)
  real*8, allocatable :: focc(:,:)
  real*8, allocatable :: vksvalence_noxc(:)
  real*8, allocatable :: vkstot1(:,:) ! "1" means strip 
  real*8, allocatable :: vkstotfirst1(:,:)
  real*8, allocatable :: dxcore(:,:,:) ! = -<q_is|X_core^gamma|p_is>, p,q: very neargap MO
  real*8, allocatable :: xcore(:,:,:)  ! = -<q_is|X_core^gamma|p_is>, p,q: AO
  real*8, allocatable :: stoch_core_loc(:,:)
  real*8, allocatable :: stoch_core1(:,:)
  real*8, allocatable :: stoch_core_filt1(:,:)
  
  complex(kind=kind_gamma_c), allocatable :: &
       rhopt1(:,:,:)  ! <J|phi_b phi_t>, for a strip of J=k+alpha

  complex(kind=kind_gamma_c), allocatable :: &
       u(:,:,:,:)  ! <J|phi_b psi(:,i,ispin)>, for a strip of J=k+alpha
    
end module neargap
