subroutine  vloc_prep_atom(ch, l, rr, vr, nr, nnr)
  implicit none
  integer nnr,nr,lp,ir,jr,l,ch
  real*8  vr(nnr),r,p,v,rr(nnr)

  call vloc_prep_atom_upf

contains
  subroutine vloc_prep_atom_upf
    use atoms, only : matop, mapat
    use nl, only : nrpp, vpploc
    implicit none
    integer ma
    logical fit

    fit=.false.
    do ma=1,matop
       if(mapat(ma)==ch) then
          fit=.true.
          call check(nrpp(ma),nr,        ' nrpp_ma, nr     ')
          call check(size(vpploc,1), nnr,' sz_vploc_1, nnr ')
          call check_le(nr,   nnr,       ' nr, nnr         ')
          vr(1:nr) = vpploc(1:nr,ma)
       endif
    enddo
    if(.not.fit) stop ' error: didnt read vpploc '
  end subroutine vloc_prep_atom_upf

  subroutine vloc_prep_atom_fort5000
    implicit none
    rewind(ch+5000)
    read(ch+5000,*) 
    do lp=0,l
       read(ch+5000,*)nr; call check_le(nr,nnr,' nr nnr   ')
       do ir=1,nr
          read(ch+5000,*)jr,r,p,v; call check(jr,ir,' jr vs.ir');
          if(lp==l) then
             rr(ir)=r; vr(ir) = v 
             !write(798,*)rr(ir),vr(ir) ! removed
          end if
       enddo
    enddo
  end subroutine vloc_prep_atom_fort5000

end subroutine vloc_prep_atom
