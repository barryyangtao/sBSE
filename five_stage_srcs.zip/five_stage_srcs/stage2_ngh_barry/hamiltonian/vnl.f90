subroutine h_nl(p, q, n) ! add vnl*p to q
  use main_param,  only : dv
  use atoms, only : na, mapai
  use nl,    only : lmax=>lmx
  use nl,    only : nlm, lloc_at
  use nl,    only : ngs, mapkbg=>map_kb_grid
  use nl,    only : dij_diag
  use nl,    only : nsuper_nl
  use nl,    only : i_indx_nl
  use nl,    only : l_indx_nl
  use nl,    only : m_indx_nl
  use nl,    only : pkb_many
  implicit none
  integer    :: n, ia, ma, itf
  real*8     :: p(n), q(n)
  
  do ia=1,na
     call hnl_a ! (p,q,n,ms,ia)
  enddo
     
contains

  subroutine hnl_a
    implicit none
    integer :: ma, j, i, l, m, igg, in
    real*8  :: ae
    !
    ! Assumes that VNL is unpolarized.  Could be extended.
    !
    ma = mapai(ia)    
    call v1a_extended(ia)
    super: do j=1,nsuper_nl
       i=i_indx_nl(j)
       l=l_indx_nl(j)
       m=m_indx_nl(j)
       l_ne_lloc_le_lmax :  if(l/=lloc_at(ma).and.l.le.lmax) then

          ae = 0d0
          do igg=1,ngs(ia)
             ae = ae +  pkb_many(igg,j) * p(mapkbg(igg,ia))
          enddo
          
          ae = ae * dv * dij_diag(i,ma) ! note scaling

          do igg=1,ngs(ia)
             q(mapkbg(igg,ia)) = q(mapkbg(igg,ia)) + ae*pkb_many(igg,j)
          end do
       end if l_ne_lloc_le_lmax
    enddo super
  end subroutine hnl_a
  
end subroutine h_nl

