module h0_modu
  use neargap, only : dens, dens0core, vksvalence_noxc
  implicit none
!  real*8, allocatable :: h0(:,:), hv(:,:),hw(:)
!  complex*16, allocatable :: p0dt(:,:)
  save
  logical :: called_hsub_prep = .false.
  real*8, allocatable :: ek(:)
end module h0_modu
