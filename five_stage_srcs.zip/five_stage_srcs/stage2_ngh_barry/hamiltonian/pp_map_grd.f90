subroutine make_map_pp_grd
  use main_param,  only : dx, dy, dz
  use main_param,  only : nx, ny, nz, periodic
  use atoms, only : mapai, matop
  use atoms, only : ch, cnt, na
  use nl, only : ngs, ngsmall
  use nl, only : map_kb_grid, rgn
  use nl, only : racut_a
  use simple_mpi, only : rank
  implicit none
  integer       :: st,rep,nga,ia,ma,ig,mpd
  integer       :: mmx,mmy,mmz
  integer       :: ix0, iy0, iz0
  integer       :: ix,  iy,  iz
  integer       :: ixp, iyp, izp
  integer       :: ipx, ipy, ipz
  integer       :: i, l, m
  integer, save :: i1=1
  logical       :: found
  real*8        :: d2,r0(3),rg(3),rn(3)
  
  if(i1/=1) return
  i1=-1  

  r0 = (/ -(nx)/2d0*dx, -(ny)/2d0*dy, -(nz)/2d0*dz /)

  mpd=0 ! now 0
  !if(periodic)mpd=2  ! see mpd below to unerstand.
  
  if(periodic.and.2d0*maxval(racut_a)>min(nx*dx, ny*dy, nz*dz)) then
     stop ' ERROR: stopping. periodic, & cell too small, images of nuclei in NL overlap '
  endif
  call check_cell(mpd)

  do ma=1,matop
     mmx = racut_a(ma)/dx + 2;    
     mmy = racut_a(ma)/dy + 2;    
     mmz = racut_a(ma)/dz + 2;    
     if(rank==0)write(6,*)' ma, integer radius of checking ',ma, mmx, mmy, mmz
  end do

  reploop : do rep = 1,2
     ialoop : do ia=1,na
        nga = 0
        ma = mapai(ia)
        mmx = racut_a(ma)/dx + 2;    
        mmy = racut_a(ma)/dy + 2;    
        mmz = racut_a(ma)/dz + 2;    
        
        pzloop : do ipz=-mpd,mpd
           pyloop : do ipy=-mpd,mpd
              pxloop : do ipx=-mpd,mpd
                 
                 rn = cnt(:,ia) + (/ ipx*nx*dx, ipy*ny*dy, ipz*nz*dz /)
                 
                 if(nx>1) then; ix0 = (rn(1) - r0(1))/dx; else ; ix0=1; 
                 endif
                 if(ny>1) then; iy0 = (rn(2) - r0(2))/dy; else ; iy0=1; 
                 endif
                 if(nz>1) then; iz0 = (rn(3) - r0(3))/dz; else ; iz0=1; 
                 endif
                 
!                 izloop : do iz=max(1,iz0-mmz),min(nz,iz0+mmz)
!                    iyloop : do iy=max(1,iy0-mmy),min(ny,iy0+mmy)
!                      ixloop: do ix=max(1,ix0-mmx),min(nx,ix0+mmx)
                 izloop : do izp=iz0-mmz,iz0+mmz
                    iyloop : do iyp=iy0-mmy,iy0+mmy
                       ixloop: do ixp=ix0-mmx,ix0+mmx

                          found = .false.
                          rg = r0 + (/ (ixp-1)*dx, (iyp-1)*dy, (izp-1)*dz /) 
                          d2 = sum((rg-rn)**2)

                          if(periodic) then
                             ix = mod(ixp-1+(mpd+1)*nx,nx)+1; call check_lele(1,ix,nx,'1-ix-nx')  
                             iy = mod(iyp-1+(mpd+1)*ny,ny)+1; call check_lele(1,iy,ny,'1-iy-ny')
                             iz = mod(izp-1+(mpd+1)*nz,nz)+1; call check_lele(1,iz,nz,'1-iz-nz') 
                          else 
                             ix=ixp
                             iy=iyp
                             iz=izp
                             if(ix<1.or.ix>nx) cycle ixloop
                             if(iy<1.or.iy>ny) cycle iyloop
                             if(iz<1.or.iz>nz) cycle izloop
                          end if

                          ig = ix+(iy-1)*nx+(iz-1)*nx*ny

                          nearby: if(d2<racut_a(ma)**2) then
                             if(found)stop ' ERROR: 2 atomic images overlapping in NL '
                             found=.true.
                             nga = nga+1
                             if(rep==2) then
                                map_kb_grid(  nga,ia) = ig
                                rgn(:,nga,ia) = rg(:)-rn(:) 
                             end if
                          end if nearby
                       end do ixloop
                    end do iyloop
                 end do izloop
              end do pxloop
           end do pyloop
        end do pzloop
        ngs(ia) = nga
     end do ialoop
     
     irep1 : if(rep==1) then
        ngsmall = maxval(ngs(1:na)) 
        if(rank==0) then
           write(6,*)' minval ngs, maxval(=ngsmall) ',minval(ngs(1:na)),ngsmall; call flush(6)
        endif
        allocate(map_kb_grid(ngsmall, na), stat=st); call check(st,0,' map_kb_grid ' )
        allocate(      rgn(3,ngsmall, na), stat=st); call check(st,0,' rgn         ' )
        map_kb_grid = -999999
     end if irep1
  end do reploop
  
  if(rank==0) then
     write(6,*)
     write(6,*)' ngs ',ngs
     write(6,*)
     call flush(6)
  endif
contains
  subroutine check_cell(mpd)
    use mpi_lib_ours, only : sync_mpi, rank
    implicit none
    integer mpd, i
    real*8  rL(3),amn(3),amx(3),fctr
    rL = (/ nx*dx, ny*dy, nz*dz /)
    amn = (/ minval(cnt(1,:)),minval(cnt(2,:)),minval(cnt(3,:)) /)
    amx = (/ maxval(cnt(1,:)),maxval(cnt(2,:)),maxval(cnt(3,:)) /)
    
    rnk0: if(rank==0) then
       write(6,*)' Checking atoms vs. cell '
       write(6,*)' atoms_minmax, cell length '
       do i=1,3
          write(6,*)' direction: ',i,' atoms_minmax ',real(amn(i)),real(amx(i)),&
               ' cell-length ',real(rl(i))
       enddo
       prdc: if(periodic) then
          !call check(mpd,2,' mpd, 2 ')
          write(6,*)' periodic,     atoms cell should be within -fctr*cell,fctr*cell, fctr=1.5 ' 
          fctr = 1.5d0
       else
          call check(mpd,0,' mpd, 0 ')
          write(6,*)' non-periodic, atoms cell should be within -fctr*cell,fctr*cell, fctr=0.5 ' 
          fctr = 0.5d0
       end if prdc
       do i=1,3
          call check_r_le(-fctr*rL(i),amn(i), ' -fctr*rL, minval_cnt ')
          call check_r_le(amx(i), fctr*rL(i), '  maxval_cnt, fctr*rL ')
       enddo
    end if rnk0
    call sync_mpi
  end subroutine check_cell
end subroutine make_map_pp_grd
