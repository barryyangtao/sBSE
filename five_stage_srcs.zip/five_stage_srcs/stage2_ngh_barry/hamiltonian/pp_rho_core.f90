subroutine make_rho_core
  use kb_mod
  use simple_mpi, only : bcast_r8
  use vloc_modu,  only : rho_core
  implicit none
  integer, save :: i1=1
  integer       :: ia, ma,  mpd, ig, i
  integer       :: ix0, iy0, iz0
  integer       :: ix,  iy,  iz
  integer       :: ixp, iyp, izp
  integer       :: ipx, ipy, ipz
  integer       :: mmx, mmy, mmz
  real*8        :: d1, d2, r0(3), rg(3), rn(3), rtop 
  real*8, parameter :: toll_rho = 1d-12

  if(i1/=1) return
  if(i1==1) i1=-1
  r0 = (/ -dble(nx)/2d0*dx, -dble(ny)/2d0*dy, -dble(nz)/2d0*dz /)
  mpd=0
  !if(periodic)mpd=2  ! see mpd below to unerstand.
  if(.not.allocated(rho_core)) then
     allocate(rho_core(n), stat=st)
     call check0(st,' rho_core ')
  else
     call check(size(rho_core),n,' rho_core ')
  end if
  rho_core = 0d0
  
  ialoop : do ia=1,na
     ma = mapai(ia)
     rtop = -99d0
     core_check : if(core_correction(ma)) then
        
        do i=1,nr(ma)
            if(rho_core_a(i,ma)>toll_rho) then
              rtop = max(rtop,rr(i,ma))
           end if
        enddo
        call check_r_le(0d0,rtop,' 0-rtop ')
        
        mmx = rtop/dx + 2;    
        mmy = rtop/dy + 2;    
        mmz = rtop/dz + 2;    
        if(periodic.and. 2d0*rtop>min(nx*dx, ny*dy, nz*dz)) then
           stop ' ERROR: stopping. periodic, & cell too small, images of nuclei in NL overlap '
        endif
        
        pzloop : do ipz=-mpd,mpd
        pyloop : do ipy=-mpd,mpd
        pxloop : do ipx=-mpd,mpd
           
           rn = cnt(:,ia) + (/ ipx*nx*dx, ipy*ny*dy, ipz*nz*dz /)
           
           if(nx>1) then; ix0 = (rn(1) - r0(1))/dx; else ; ix0=1; 
           endif
           if(ny>1) then; iy0 = (rn(2) - r0(2))/dy; else ; iy0=1; 
           endif
           if(nz>1) then; iz0 = (rn(3) - r0(3))/dz; else ; iz0=1; 
           endif
           
           izloop : do izp=iz0-mmz,iz0+mmz
           iyloop : do iyp=iy0-mmy,iy0+mmy
           ixloop: do ixp=ix0-mmx,ix0+mmx
              
              rg = r0 + (/ (ixp-1)*dx, (iyp-1)*dy, (izp-1)*dz /) 
              d2 = sum((rg-rn)**2)
              
              if(periodic) then
                 ix = mod(ixp-1+(mpd+1)*nx,nx)+1; call check_lele(1,ix,nx,'1-ix-nx')  
                 iy = mod(iyp-1+(mpd+1)*ny,ny)+1; call check_lele(1,iy,ny,'1-iy-ny')
                 iz = mod(izp-1+(mpd+1)*nz,nz)+1; call check_lele(1,iz,nz,'1-iz-nz') 
              else 
                 ix=ixp
                 iy=iyp
                 iz=izp
                 if(ix<1.or.ix>nx) cycle ixloop
                 if(iy<1.or.iy>ny) cycle iyloop
                 if(iz<1.or.iz>nz) cycle izloop
              end if
              
              ig = ix+(iy-1)*nx+(iz-1)*nx*ny
              nearby: if(d2.le.rtop**2) then
                 d1 = sqrt(d2)
                 call interp_rho_add(d1, rho_core(ig), rr(1,ma), rho_core_a(1,ma), nr(ma))
              end if nearby
              
           end do ixloop
           end do iyloop
           end do izloop
     
        end do pxloop
        end do pyloop
        end do pzloop
     endif core_check
  end do ialoop
  
  if(rnk==0) then
     write(6,*)' max rhocore, integral rhocore ',maxval(rho_core), sum(rho_core)*dv
     call flush(6)
  endif
  call bcast_r8(rho_core, size(rho_core),0)
end subroutine 
