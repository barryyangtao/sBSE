subroutine label_to_atom_and_charge(ccha, cha, zcha)
  implicit none
  character*2 ccha
  real*8 zcha
  integer cha
  
  if(ccha=='Si') then
     cha = 14
     zcha = 4d0
  elseif(ccha=='P') then
     cha = 15
     zcha = 5d0
  else if(ccha=='H ') then
     cha = 1
     zcha = 1d0
  else if(ccha=='C ') then
     cha = 6
     zcha = 4d0
  else if(ccha=='B ') then
     cha = 5
     zcha = 3d0
  elseif(ccha=='Li') then
     cha = 3
     zcha = 1d0
  else if(ccha=='N ') then
     cha = 7
     zcha = 5d0
  else if(ccha=='O ') then
     cha = 8
     zcha = 6d0
  else if(ccha=='F ') then
     cha = 9
     zcha = 7d0
  else if(ccha=='S ') then
     cha = 16
     zcha = 6d0
  else if(ccha=='Cl') then
     cha = 17
     zcha = 7d0
  else if(ccha=='Zn') then
     cha = 30
     zcha = 12d0
  else if(ccha=='Ni') then
     cha = 28
     zcha = 10d0
  else if(ccha=='Mo') then
     cha = 42
     zcha = 6d0
  else if(ccha=='I') then
     cha = 53
     zcha = 7d0
  else if(ccha=='W ') then
     cha = 74
     zcha = 6d0
  else if(ccha=='Au') then
     cha = 79
     zcha = 11d0
  else if(ccha=='Mg') then
     cha = 12
     zcha = 2d0
  else if(ccha=='Ca'.or.ccha=='CA') then
     cha = 20
     zcha = 2d0
  else if(ccha=='Al'.or.ccha=='AL') then
     cha = 13
     zcha = 3d0
  else if(ccha=='Br') then
     cha = 35
     zcha = 7d0
  else
     write(6,*)' stopping, since we need to include also the case of atom ',ccha
     stop
  end if
end subroutine label_to_atom_and_charge
