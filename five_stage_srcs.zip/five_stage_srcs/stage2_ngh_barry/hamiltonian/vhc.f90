subroutine dens_to_vh(dens, vh)
  use main_param, only : vk, vkb, scale_vh, n
  implicit none
  real*8 dens(*), vh(*)
  select case(scale_vh)
  case(1);  call dens_to_vd_generalvk(dens, vh, vk)
  case(2);  call dens_to_vd_generalvk(dens, vh, vkb); 
  case default; stop ' scale_vh '
  end select
end subroutine dens_to_vh

subroutine dens_to_vd_generalvk(densin,vd,vk_method)
  use main_param, only : scale_vh, n, nx, ny, nz
  use simple_mpi, only : rank
  implicit none
  integer  nxb,nyb,nzb,i
  real*8   densin(n)
  real*8   vd(n)
  real*8   vk_method(*)  ! which vk is used  
  real*8 , allocatable :: dens(:),densb(:), vdb(:)  

  select case(scale_vh)
  case(1);     call vd1_sub(densin,vd)
  case(2);     call vd_sub_dbl
  case default; stop ' problem, sclae_vd'
  end select

contains
  subroutine vd_sub_dbl
    implicit none
    nxb = scale_vh*nx
    nyb = scale_vh*ny
    nzb = scale_vh*nz
    
    if(mod(nx ,2)/=0.or.mod(ny ,2)/=0.or.mod(nz ,2)/=0) stop ' make nx ,ny ,nz  all even '
    if(mod(nxb,2)/=0.or.mod(nyb,2)/=0.or.mod(nzb,2)/=0) stop ' make nxb,nyb,nzb all even '
    
    allocate( dens(nx*ny*nz),    stat=i); if(i/=0) stop ' dens  '
    allocate(densb(nxb*nyb*nzb), stat=i); if(i/=0) stop ' densb '
    allocate(  vdb(nxb*nyb*nzb), stat=i); if(i/=0) stop '   vdb '
    
    dens = densin
    call dens_to_densb(dens,densb)
    call get_vco(densb,nxb,nyb,nzb,vk_method,vdb,rank)
    
    call vdb_to_vd(vdb,vd)
    
    deallocate(  vdb)
    deallocate(densb)
    deallocate(dens)
  end subroutine vd_sub_dbl

  subroutine dens_to_densb(dens,densb)
    implicit none
    real*8  dens( nx, ny, nz)
    real*8  densb(nxb,nyb,nzb)

    integer mx,my,mz,px,py,pz
    densb = 0d0
    
    mx= 1 + nxb/2 - nx/2
    px=     nxb/2 + nx/2

    my= 1 + nyb/2 - ny/2
    py=     nyb/2 + ny/2

    mz= 1 + nzb/2 - nz/2
    pz=     nzb/2 + nz/2

    densb(mx:px,my:py,mz:pz) = dens
  end subroutine dens_to_densb

  subroutine vdb_to_vd(vdb,vd)
    implicit none
    real*8  vd( nx, ny, nz)
    real*8  vdb(nxb,nyb,nzb)
    integer mx,my,mz,px,py,pz

    mx= 1 + nxb/2 - nx/2
    px=     nxb/2 + nx/2

    my= 1 + nyb/2 - ny/2
    py=     nyb/2 + ny/2

    mz= 1 + nzb/2 - nz/2
    pz=     nzb/2 + nz/2

    vd = vdb(mx:px,my:py,mz:pz) 

  end subroutine vdb_to_vd
  
  subroutine vd1_sub(dens,vd)
    use simple_mpi, only : rank
    implicit none
    real*8   dens(n)
    real*8   vd(n)
    call get_vco(dens,nx,ny,nz,vk_method,vd,rank)
  end subroutine vd1_sub
end subroutine dens_to_vd_generalvk

