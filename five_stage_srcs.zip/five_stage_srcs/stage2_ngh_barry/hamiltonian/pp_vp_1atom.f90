subroutine v1a_extended(ia)
  use nl,  only : nproj, racut_a
  use nl,  only : lpp, lpptop
  use nl,  only : nsuper_nl
  use nl,  only : i_indx_nl
  use nl,  only : l_indx_nl
  use nl,  only : m_indx_nl
  use nl,  only : pkb_many, lmax=>lmx
  use kb_mod, only : ngs, rgn
  use atoms,  only : mapai

  implicit none
  integer ia, ma, lh, st, np
  integer igg, ix,iy,iz
  integer i, l, m, j
  real*8  ra, x, y, z, pi
  real*8  as, ap, ap0, dc(5), fc(7)
  real*8  ad0, ad, af0, af
  real*8, allocatable :: fm(:,:), pb(:)

  pi = dacos(-1d0)
  ma = mapai(ia)
  np = nproj(ma)

  lh = maxval(lpp(1:np,ma))
  call check_lele(0,lh,3,        ' 2-lh-3        ')
  call check_lele(0,lpptop(ma),3,' 2-lpptop_ma-3 ')
  call check_lele(2,lmax,3,      ' 2-lmax-3      ')

  call make_super_nl
    
  allocate(fm(2*lh+1,0:lh), stat=st)
  call check0(st,' fm alloc ')

  allocate(pb(np), stat=st)
  call check0(st,' pb alloc ')
  
  if(allocated(pkb_many)) deallocate(pkb_many)
  allocate(pkb_many(ngs(ia),nsuper_nl), stat=st)
  call check0(st,' pkb_many ')

  call const_angular
  iggloop : do igg=1,ngs(ia)
     x = rgn(1,igg,ia)
     y = rgn(2,igg,ia)
     z = rgn(3,igg,ia)
     ra = max(sqrt(x*x+y*y+z*z),1.d-8)

     ra_le_racut : if(ra<racut_a(ma)) then

        call make_fm_angular
        call interpp(ra, pb(1:np), ma, np)
        
        super: do j=1,nsuper_nl
           i=i_indx_nl(j)
           l=l_indx_nl(j)
           m=m_indx_nl(j)           
           pkb_many(igg,j) = pb(i)*fm(m,l)
        enddo super
     else
        pkb_many(igg,:)=0d0
     end if ra_le_racut
  enddo iggloop
  deallocate(fm)
  deallocate(pb)
contains
  subroutine make_super_nl
    implicit none
    integer in, l, m, j

    j=0
    do in=1,np
       l=lpp(in,ma)
       do m=1,2*l+1
          j=j+1
       enddo
    end do

    nsuper_nl = j
    if(allocated(i_indx_nl))deallocate(i_indx_nl)
    if(allocated(l_indx_nl))deallocate(l_indx_nl)
    if(allocated(m_indx_nl))deallocate(m_indx_nl)

    allocate(i_indx_nl(nsuper_nl),stat=st); call check0(st,' iindxnl ')
    allocate(l_indx_nl(nsuper_nl),stat=st); call check0(st,' lindxnl ')
    allocate(m_indx_nl(nsuper_nl),stat=st); call check0(st,' mindxnl ')
    
    j=0
    do in=1,np
       l=lpp(in,ma)
       do m=1,2*l+1
          j=j+1
          i_indx_nl(j) = in
          l_indx_nl(j) = l
          m_indx_nl(j) = m
       enddo
    end do
  end subroutine make_super_nl

  subroutine const_angular
    implicit none
    
    dc(:) = (/ 1d0, 1d0, 1d0/2d0/sqrt(3d0), 1d0, 1d0/2d0 /)
    fc(:) = &
         (/ sqrt(35d0/2d0),2*sqrt(105d0),sqrt(21d0/2d0),sqrt(7d0),&
            sqrt(21d0/2d0),sqrt(105d0),sqrt(35d0/2d0)/)
    as  = 1d0 / sqrt(4d0*pi) 
    ap0 = as  * sqrt(3d0)
    ad0 = sqrt(15d0)/2d0/sqrt(pi)
    af0 =        1d0/4d0/sqrt(pi)
  end subroutine const_angular

  subroutine make_fm_angular
    implicit none
    fm(1,0) = as
    
    if(lh.ge.1) then
       ap = ap0/ra 
       fm( 1,1) = ap* x 
       fm( 2,1) = ap* y 
       fm( 3,1) = ap* z            
    end if
    
    if(lh.ge.2) then
       ad = ad0/ra**2 
       fm( 1,2) = ad*dc(1)*x*y
       fm( 2,2) = ad*dc(2)*y*z 
       fm( 3,2) = ad*dc(3)*(2*z**2-x**2-y**2)
       fm( 4,2) = ad*dc(4)*x*z
       fm( 5,2) = ad*dc(5)*(x**2-y**2)
    endif
    
    if(lh.ge.3) then
       af       = af0/ra**3 
       fm( 1,3) = af*fc(1)*y*(3*x**2-y**2)
       fm( 2,3) = af*fc(2)*x*y*z           
       fm( 3,3) = af*fc(3)*y*(4*z**2-x**2-y**2)
       fm( 4,3) = af*fc(4)*z*(2*z**2-3*x**2-3*y**2) 
       fm( 5,3) = af*fc(5)*x*(4*z**2-x**2-y**2)  
       fm( 6,3) = af*fc(6)*z*(x**2-y**2)      
       fm( 7,3) = af*fc(7)*x*(x**2-3*y**2)      
    end if
    
    if(lh.ge.4) stop ' error: lpp_high > 3, need to put g states '
  end subroutine make_fm_angular

end subroutine v1a_extended

  
  

