subroutine get_ma(znum,ma)
  use atoms, only : mapat, matop
  implicit none
  integer znum,ma,maf
  ma = 0
  maloop : do maf=1,matop
     if(mapat(maf)==znum) ma=maf
  end do maloop
end subroutine get_ma

