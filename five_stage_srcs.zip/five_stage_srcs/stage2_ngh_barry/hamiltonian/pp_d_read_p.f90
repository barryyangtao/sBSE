subroutine pp_convert_upf(fname,znum,valnum)
  use nl, only : nrpp, nrppmx
  use nl, only : lmx, lpploc, lpptop, lpp
  use nl, only : nproj
  use nl, only : rrpp, vpploc
  use nl, only : phipp, dij_diag
  use nl, only : rho_core_a, core_correction
  use nl, only : racut_a
  implicit none
  integer           :: i, np
  integer           :: ii, i1, i2, i3, in
  character(8)      :: str8
  character(50)     :: fname
  character(2)      :: name
  character(80)     :: str1,str2
  character(500)    :: full, f2
  integer           :: ir,znum,lmax,lloc
  integer           :: sz,jr,mr,st,licn,il
  integer           :: ipt,valnum
  integer           :: ma
  integer           :: iread
  logical           :: found_cc, core_c
  real*8, parameter :: toll_phipp=1d-7
  real*8            ::  pi, r_valnum, norm2
  real*8, allocatable :: grd(:), dr(:)
  real*8, allocatable :: rho_cr(:), vloc_rd(:)
  real*8, allocatable :: phi(:,:)
  real*8, allocatable :: dij_mtrx(:,:)
  pi = dacos(-1d0)

  open(001,file='PP/'//trim(fname))
  read(001,*) str1,str2

  if(str2(scan(str2,'"')+1:scan(str2,'"',.true.)-1)/="2.0.1") &
                               stop "UPF Version 2.0.1 required!"
  
  headerhead : do
     read(001,*)str1
     if(index(str1,"<PP_HEADER")/=0) then
        exit headerhead
     endif
  end do headerhead

  lloc=-11
  header: do
     read(001,"(A)")full
     read(full,*)str1
     str2=str1(1:scan(str1,'=')-1)
     call lower_the_case(str2)
     select case(trim(str2))
     case("element")   ! Three possibilies, generically : " H", or "Si","H "
        i=scan(full,'"')
        call check_le(i+2,len_trim(full),' i+2, len_trim(full) ')
        if(full(i+1:i+1)==' ') then ! " H"
           name=full(i+2:i+2)//' '
        else                        ! "Si" or "H "
           name=full(i+1:i+2)
        endif
        write(6,*) ' full ',full
        write(6,*) ' i ',i
        write(6,*) ' name ',name
        call elname(name,znum) 
        write(17,*) "element:",name,znum
     case("z_valence")
        write(f2,'(A)')full(scan(full,'"')+1:scan(full,'"',.true.)-1)
        read( f2,*) r_valnum
        valnum = nint(r_valnum) ! integer 
        if(abs(valnum-r_valnum)>1d-4)then; 
           write(6,*)' error: valnum, r_valnum ',valnum,r_valnum
           stop
        endif
        write(17,*) "valence:",valnum
     case("l_max")
        if(len(str1(scan(str1,'"')+1:scan(str1,'"',.true.)-1))/=1) then
           stop "lmax <1!"
        end if
        call str2int(str1(scan(str1,'"')+1:scan(str1,'"',.true.)-1),1,lmax)
        write(17,*) "L max=",lmax
     case("is_ultrasoft")
        if(str1(scan(str1,'"')+1:scan(str1,'"',.true.)-1)=="T") then
           write(17,*) "Ultrasoft not supported!"
           stop
        end if
     case("is_paw")
        if(str1(scan(str1,'"')+1:scan(str1,'"',.true.)-1)=="T") then
           write(17,*) "PAW not supported!"
           stop
        end if
     case("functional")
        str2=str1(scan(str1,'"')+1:scan(str1,'"',.true.)-1) 
        if(str2/='PW'.and.str2/='SLA-PW'.and.str2/='PBE') then
           write(6,*) "Error: (not stopping!) Functional not supported!"
           write(6,*) "Functional is:",str2
           !stop
        end if
     case("l_local")
        write(f2,'(A)')full(scan(full,'"')+1:scan(full,'"',.true.)-1)
        read( f2,*) lloc
        write(17,*) "L loc=",lloc
     case("core_correction")
        if(str1(scan(str1,'"')+1:scan(str1,'"',.true.)-1)=="T") then
           core_c=.true.
        else if(str1(scan(str1,'"')+1:scan(str1,'"',.true.)-1)=="F") then
           core_c=.false.
        else
           stop ' core_correction ill defined, stopping '
        end if
     case("number_of_proj")
        sz = len(str1(scan(str1,'"')+1:scan(str1,'"',.true.)-1))
        call str2int(str1(scan(str1,'"')+1:scan(str1,'"',.true.)-1),sz,np)
     end select
     if(index(full,"/>")/=0)  exit header
  end do header
  call check_le(-1,lloc,' (-1)-lloc ')
  call flush(17)
  !
  ! verifying that atom is among list of nuclei
  ! 
  call check_le(1,znum,' 1, znum ')
  call get_ma(znum,ma)
  if(ma==0) then
     close(001)
     return
  endif
  call check_lele(1,np,size(phipp,2),' 1-np-szphipp2 ')
  nproj( ma) = np
  lpptop(ma)=min(lmax,lmx)
  lpploc(ma)=lloc

  search_pp_r : do     
     read(001,"(A)") full
     if(index(full,"PP_R")/=0) exit search_pp_r
  enddo search_pp_r

  write(f2,'(A)')full(index(full,'size=')+6:)
  write(full,'(A)')f2(1:index(f2,'"')-1)
  read(full,*)mr

  write(17,*) "Number of points:",mr; call flush(17)
  call check_le(mr,nrppmx,' mr nrppmx ')

  allocate(      grd(mr),    stat=st); call check0(st,' grd      ')
  allocate(       dr(mr),    stat=st); call check0(st,' grd      ')
  allocate(   rho_cr(mr),    stat=st); call check0(st,' r_core   ')
  allocate(  vloc_rd(mr),    stat=st); call check0(st,' vloc_rd  ')
  allocate(      phi(mr,np), stat=st); call check0(st,' phi      ')
  allocate( dij_mtrx(np,np), stat=st); call check0(st,' dij_mtrx ')

  read(001,*) grd
  ! make dr
  dr(1)      = grd(2)-grd(1)
  dr(mr)     = grd(mr)-grd(mr-1)
  dr(2:mr-1) = (grd(3:mr)-grd(1:mr-2))/2d0

  core_correction(ma) = core_c
  if(core_c) then
     found_cc = .false.
     search_ppnlcc : do 
        read(001,*)str1
        if(str1=="<PP_NLCC") then
           found_cc = .true.
           exit search_ppnlcc
        endif
     end do search_ppnlcc
     if(.not.found_cc) stop ' core_correction but did not find PP_NLCC '
     read(001,*) rho_cr(:)
     write(17,*)' rho_core_integral ',sum(4d0*pi*grd**2*rho_cr)
     if(any(rho_cr<0d0)) stop ' rho_cr_negative somewhere, problem '
  endif

  searchpplocal : do 
     read(001,*) str1
     if(str1=="<PP_LOCAL") exit searchpplocal
  end do searchpplocal

  read(001,*) vloc_rd(:)

  ! 
  !  Next: nonlocal part,
  ! 
  do 
     read(001,*) str1
     if(str1=="<PP_NONLOCAL>") exit
  end do

  !
  !  now need to read PP_BETA.1 ,  PP_BETA.2 , ... THEN: PP_DIJ ....
  ! 

  channeloop : do ii=1,np
     ! read PP_BETA.  Header, angular momentum, and index
     in = -1 ! index
     il = -1 ! l
     PP_Beta_header_search : do
        read(001,'(A)') full
        if(index(full,"<PP_BETA").ne.0) exit PP_Beta_header_search
     end do PP_Beta_header_search
     
     write(17,*) "Reading ichannel",ii
     
     PP_BETA_next : do 
        i1 = index(full,"angular_momentum=")
        if(i1/=0) then
           write(f2,'(A)')full(i1+18:)       
           write(f2,'(A)')f2(:index(f2,'"')-1)
           read( f2,*)il
        endif
        
        ! now checking index.  more complicated, since "index" could be a number > 1.
        i1 = index(full," index")
        if(i1/=0) then
           write(f2,'(A)')full(i1+8:)         
           write(f2,'(A)')f2(:index(f2,'"')-1)
           read(f2,*)in
        end if
        
        if(index(full,">").ne.0) exit PP_BETA_next
        read(001,'(A)') full ! reading the next one
     end do PP_BETA_next

     ! now check that l and the index are correct. 
     call check_lele(0,il,9,' 0-il-9 ') 
     call check(ii,in,' ii, in ')  
     lpp(in,ma)=il
     
     ! read w.f.
     read(001,*) phi(:,in)
     !
     ! print w.f. properties
     write(17,*)' atom index=',ma,' index=',in
     norm2 = sum(phi(:,in)**2*dr) 
     write(17,*)' <phi(:,in)|phi(:,in> ',norm2
     if(abs(norm2-1d0)>1d-4) then
        write(6,*)' potential problem:  in, l, <phi(:,in)|phi(:,in> ',in,il,norm2
     endif
     ! *grd**2 built within phi.
     
     read(001,'(A)') full
     if(index(full,'</PP_BETA')==0) then; write(6,*)' error , full=',full; stop
     end if
  end do channeloop
  !
  !  now read PP_DIJ
  ! 

  read(001,'(A)') full
  if(index(full,'<PP_DIJ')==0) stop ' error, no PP_DIJ '

  end_dij : if(index(full,'>')==0) then
     loopend : do
        read(001,'(A)') full
        if(index(full,'>')/=0) exit loopend
     end do loopend
  end if end_dij

  read(001,*)dij_mtrx

  !
  ! check diagonality, extract diagonal value.  
  !
  call check_le(np, size(dij_diag,1),' np, diag_diag ')
  do i1=1,np
     do i2=1,np
        if(i1==i2) then; dij_diag(i1,ma) = dij_mtrx(i1,i1) / 2d0  ! Rydberg to Hartree
        else;            if(abs(dij_mtrx(i1,i2))>1d-6) stop ' dij_mtrx not diagonal '
        end if
     end do
  end do

  nrpp(         ma) = mr
  rrpp(  1:mr,  ma) = grd(1:mr)
  vpploc(1:mr,  ma) = vloc_rd(1:mr)/2.d0               ! Rydberg to Hartree     

  rho_core_a(:, ma) = 0d0
  if(core_correction(ma))  rho_core_a(1:mr,ma) = rho_cr(1:mr)

  phipp( 1:mr,:,ma) = 0d0
  do in=1,np
     do ir=1,mr
        if(grd(ir)>1d-5) phipp(ir,in,ma) = phi(ir,in)/grd(ir)
     enddo
  end do

  ! maximum r point
  !
  jrmake : do jr=mr,1,-1
     if (maxval(abs(phipp(jr,:,ma)))>toll_phipp) exit jrmake
  enddo jrmake
  write(6,*)' ma, jr,      rrpp(jr,ma),  np, phipp(jr,1:np,ma)',&
              ma, jr, real(rrpp(jr,ma)), np, phipp(jr,1:np,ma)
  jr = min(mr,jr+1) ! no need for +4
  racut_a(ma) = rrpp(jr,ma)
  write(6,*)' atomtype index(=ma): ',ma,' racut_a(ma) ',racut_a(ma)

  call flush(17)
  close(001)
  deallocate(grd)
  deallocate(dr)
  deallocate(rho_cr)
  deallocate(vloc_rd)
  deallocate(phi)
  deallocate(dij_mtrx)
end subroutine pp_convert_upf

subroutine str2int(str,n,num)
  implicit none
  integer          :: num,n
  character(n)     :: str
  read(str,*) num
end subroutine str2int


