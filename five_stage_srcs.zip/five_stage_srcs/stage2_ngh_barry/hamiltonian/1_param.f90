module main_param
  use neargap, only : dx, dy, dz, dv
  use neargap, only : nx, ny, nz, n
  use neargap, only : periodic
  use neargap, only : ekcut
  use neargap, only : scale_vh
  use neargap, only : gam_bnl=>gamW, ampbare, ampw
  use neargap, only : chrg=>charge
  use neargap, only : vk, vkb
  use neargap, only : functional
  implicit none
  save
end module main_param

  
