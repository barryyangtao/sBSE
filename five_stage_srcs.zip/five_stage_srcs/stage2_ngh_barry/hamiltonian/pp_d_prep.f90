subroutine pp_d_prep
  use mpi_lib_ours, only : rank
  implicit none
  call pp_d_allocate
  if(rank==0) call pp_d_read_in
  if(rank==0) then; write(6,*)' finished reading PP  '; write(6,*); call flush(6); endif
  call pp_d_check
  if(rank==0) then; write(6,*)' finished checking PP '; call flush(6); endif
  call pp_d_bcast
end subroutine pp_d_prep
