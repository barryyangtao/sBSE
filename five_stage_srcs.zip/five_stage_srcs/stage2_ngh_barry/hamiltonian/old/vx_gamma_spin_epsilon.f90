subroutine  get_vx_gamma_spin_epsilon(dens_sp, n, nspin, vx, gm, ampw)
  implicit none
  integer n, nspin, st
  real*8 dens_sp(n, nspin), vx(n, nspin), gm, ampw
  real*8, allocatable, dimension(:,:) :: vg0 ! vx_short(gamma=0)

  allocate(vg0(n,nspin), stat=st)
  call check0(st,' vg0 ')

  call get_vx_gamma_spin(dens_sp, n, nspin, vx,  gm)
  call get_vx_spin(dens_sp, n, nspin, vg0)

  vx = vg0*(1-ampw)+ampw*vx
end subroutine get_vx_gamma_spin_epsilon

subroutine  get_vx_gamma_spin_epsilon_lda(dens_sp, n, nspin, vx, gm, ampw)
  implicit none
  integer n, nspin, st
  real*8 dens_sp(nspin,n), vx(nspin,n), gm, ampw
  real*8, allocatable, dimension(:,:) :: vg0 ! vx_short(gamma=0)
  real*8, allocatable, dimension(:)   :: ex 

  allocate(vg0(nspin,n), ex(n), stat=st)
  call check0(st,' vg0 ')

  call lda_sr_libxc_x(dens_sp, n, nspin, vx, ex,gm) 
  call lda_libxc_x(dens_sp, n, nspin, vg0, ex) 

  vx = vg0*(1-ampw)+ampw*vx
  deallocate(vg0,ex)
end subroutine get_vx_gamma_spin_epsilon_lda

subroutine  get_vx_gamma_spin_epsilon_pbe(dens_sp, sigma, n, nsig, nspin, vx, gm, ampw)
  implicit none
  integer n, nspin, st, nsig
  real*8 dens_sp(nspin,n), vx(nspin,n), sigma(nsig,n), gm, ampw
  real*8, allocatable, dimension(:,:) :: vg0 ! vx_short(gamma=0)
  real*8, allocatable, dimension(:)   :: ex 

  allocate(vg0(nspin,n), ex(n), stat=st)
  call check0(st,' vg0 ')

  call pbe_sr_libxc_x(dens_sp, sigma, n, nsig, nspin, vx, ex,gm) 
  call pbe_libxc_x(dens_sp, sigma, n, nsig, nspin, vg0, ex) 

  vx = vg0*(1-ampw)+ampw*vx
  deallocate(vg0,ex)
end subroutine get_vx_gamma_spin_epsilon_pbe
!subroutine  get_vx_gamma_spin_epsilon(dens_sp, n, nspin, vx, gm, ampbare, ampw)
!  implicit none
!  integer n, nspin, st
!  real*8 dens_sp(n, nspin), vx(n, nspin), gm, ampw, ampbare
!  real*8, allocatable, dimension(:,:) :: vg0, vx_lr, vx_sr ! vx_short(gamma=0)
!
!  allocate(vg0(n,nspin), stat=st)
!  allocate(vx_sr(n,nspin), stat=st)
!  allocate(vx_lr(n,nspin), stat=st)
!  call check0(st,' vg0 ')
!  
!  call get_vx_gamma_spin(dens_sp, n, nspin, vx_sr,  gm)
!  call get_vx_spin(dens_sp, n, nspin, vg0)
!  vx_lr = vg0 - vx_sr
!
!  vx = (1d0 - ampbare - ampw)*vx_lr + (1d0 - ampbare)*vx_sr
!  deallocate(vx_sr, vx_lr, vg0)
!  
!!!!  vx = vg0*(1-ampw)+ampw*vx
!end subroutine get_vx_gamma_spin_epsilon


!subroutine  get_vx_gamma_spin_epsilon_lda(dens_sp, n, nspin, vx, gm, ampbare, ampw)
!  implicit none
!  integer n, nspin, st
!  real*8 dens_sp(n, nspin), vx(n, nspin), gm, ampw, ampbare
!  real*8, allocatable, dimension(:,:) :: vg0, vx_lr, vx_sr ! vx_short(gamma=0)
!  real*8, allocatable, dimension(:)   :: ex ! vx_short(gamma=0)
!
!  allocate(vg0(n,nspin), stat=st)
!  allocate(vx_sr(n,nspin), stat=st)
!  allocate(vx_lr(n,nspin), stat=st)
!  allocate(ex(n), stat=st)
!  call check0(st,' vg0 ')
!  
!  !call get_vx_gamma_spin(dens_sp, n, nspin, vx_sr,  gm)
!  !call get_vx_spin(dens_sp, n, nspin, vg0)
!  call lda_sr_libxc_x(dens_sp, n, nspin, vx_sr, ex,gm) 
!  call lda_libxc_x(dens_sp, n, nspin, vg0, ex) 
!  vx_lr = vg0 - vx_sr
!
!  vx = (1d0 - ampbare - ampw)*vx_lr + (1d0 - ampbare)*vx_sr
!  deallocate(vx_sr, vx_lr, vg0)
!  
!!!!  vx = vg0*(1-ampw)+ampw*vx
!end subroutine get_vx_gamma_spin_epsilon_lda
