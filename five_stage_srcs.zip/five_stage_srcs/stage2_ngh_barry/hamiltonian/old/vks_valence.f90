subroutine make_vks_valence_noxc
  use main_param, only : n, longcore
  use h0_modu, only : vksvalence_noxc, dens, dens0core
  implicit none
  integer st
  if(.not.allocated(vksvalence_noxc)) then
     allocate(vksvalence_noxc(n), stat=st)
     call check0(st,' vksvalence ')
  else
     call check(size(vksvalence_noxc),n,' szvksvalence ')
  endif
  call vks_sub_valence_noxc(dens,dens0core,vksvalence_noxc,n)  

end subroutine make_vks_valence_noxc

subroutine vks_sub_valence(dens,denscore,vks,n)
  use vloc_modu, only : vloc_tot
  use main_param, only : longcore
  implicit none
  integer, parameter :: nspin_loc=1
  logical, save      :: first=.true.
  integer n,i,st
  real*8 dens(n), denscore(n), vks(n)
  real*8, allocatable :: vxc(:), vxlongcore(:)

  vks=0 
  call dens_to_vh(dens,vks)
  vks = vks + vloc_tot
 
  allocate(vxc(n), stat=st); if(st/=0) stop ' vxc '
  call vxc_spin_core_corrected(dens,vxc,n,nspin_loc)
  vks = vks + vxc

  if(longcore) then
     allocate(vxlongcore(n), stat=st); if(st/=0) stop ' vxlongcore '
     call vx_long_range_gamma(denscore, vxlongcore, n, nspin_loc)
     vks = vks+vxlongcore
  end if
  call time_print(' post vks_sub ')
end subroutine vks_sub_valence

subroutine vks_sub_valence_noxc(dens,denscore,vks_noxc,n)
  use vloc_modu, only : vloc_tot
  use main_param, only : longcore
  implicit none
  integer, parameter :: nspin_loc=1
  logical, save      :: first=.true.
  integer n,i,st
  real*8 dens(n), denscore(n), vks_noxc(n)
  real*8, allocatable :: vxc(:), vxlongcore(:)

  vks_noxc=0 
  call dens_to_vh(dens,vks_noxc)
  vks_noxc = vks_noxc + vloc_tot
 
!  allocate(vxc(n), stat=st); if(st/=0) stop ' vxc '
!  call vxc_spin_core_corrected(dens,vxc,n,nspin_loc)
!  vks = vks + vxc

  if(longcore) then
     allocate(vxlongcore(n), stat=st); if(st/=0) stop ' vxlongcore '
     call vx_long_range_gamma(denscore, vxlongcore, n, nspin_loc)
     vks_noxc = vks_noxc+vxlongcore
  endif
  
  call time_print(' post vks_noxc_sub ')
end subroutine vks_sub_valence_noxc

subroutine vx_long_range_gamma(denscore, vxlongcore, n, nspin)
  use main_param, only : gm=>gam_bnl, ampw
  implicit none
  integer n, nspin, st
  real*8 denscore(n,nspin), vxlongcore(n, nspin)
  real*8, allocatable :: vxlda(:,:)
  allocate(vxlda(n,nspin), stat=st); if(st/=0) stop ' vxlda '

  if(gm<1d-8) then
     vxlongcore = 0
  else
     !call get_vx_spin( denscore, n,   nspin, vxlda)
     call get_vx_gamma_spin(denscore, n, nspin, vxlda, 1d-6) ! short range
     call get_vx_gamma_spin(denscore, n, nspin, vxlongcore, gm) ! short range
     vxlongcore = (vxlda-vxlongcore)*ampw
  end if
  call debug
contains
  subroutine debug
    integer i, is, ivec(2)
    write(6,*)' minval, maxval  denscore ',minval(denscore),maxval(denscore)
    write(6,*)' minval, maxval vxlongcore ',minval(vxlongcore),maxval(vxlongcore)
    ivec= minloc(vxlongcore)
    i=ivec(1)
    is=ivec(2)
    write(6,*)' i_min, denscore(i), vxlda(i), vxlongcore(i) ',&
         i,real(denscore(i,is)),real(vxlda(i,is)),real(vxlongcore(i,is))
  end subroutine debug
end subroutine vx_long_range_gamma
