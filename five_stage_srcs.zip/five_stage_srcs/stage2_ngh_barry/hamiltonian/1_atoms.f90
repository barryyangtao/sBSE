module atoms
  use neargap, only :  rnel, rnel_orig, rnel_neutral
  implicit none
  save
  integer, parameter                    :: n118=118
  integer                               :: na, matop
  integer                               :: kbflg(n118), iap_list(n118)
  integer                               :: valence_list(n118)
  integer, allocatable, dimension(:)    :: mapai, mapat, ch
  real*8, allocatable, dimension(:)     :: zch, zch_ch
  real*8, allocatable, dimension(:,:)   :: cnt,cnt_old
  logical                               :: found_charge(n118)=.false.
  character*2                           :: atom_upper_name(n118)
  character*2                           :: atom_name(n118)
end module atoms
