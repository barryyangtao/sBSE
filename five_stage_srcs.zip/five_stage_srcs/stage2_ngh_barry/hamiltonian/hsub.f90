subroutine hsub_noxc(p, hp)
  use main_param
  use h0_modu, only : ek, vksvalence_noxc, called_hsub_prep
  use simple_mpi, only : sync_mpi
  implicit none
  real*8 p(n), hp(n), ak, anl, av
  logical, save :: first=.true.
  if(.not.called_hsub_prep) stop ' didnt call hsub_prep before '

  call kin ! hp = kin(p)
  call h_nl(p, hp, n) ! adds hp
  hp = hp + vksvalence_noxc*p
contains
  subroutine kin
    implicit none
    integer st
    complex*16, allocatable :: ca(:)
    allocate(ca(n), stat=st)
    call check0(st,' ca ' )
    ca = p
    call fft3d_forward(nx, ny, nz, ca, ca)
    ca = ca* (ek/n)
    call fft3d_backward(nx, ny, nz, ca, ca)
    hp = ca
    deallocate(ca)
  end subroutine kin
end subroutine hsub_noxc
