module kb_mod
  use main_param,  only  : n, nx,ny,nz,dx,dy,dz,dv,periodic
  use atoms, only  : mapat, mapai,cnt, matop, na, kbflg, n118
  use simple_mpi,  only  : rnk => rank
  implicit none
  save
  integer, parameter  :: lmax=3  ! 2 or 3
  integer             :: nrmax = 2501 ! 798
  integer, parameter  :: nlm= (lmax+1)**2 
  integer             :: l_from_ilm(nlm) 
  integer             :: ngsmall
  integer             :: st
  integer,allocatable :: nr(:), ngs(:)  
  integer,allocatable :: map_kb_grid(:,:)
  integer, allocatable :: lmax_at(:), lloc_at(:), ltop_nl(:)
  logical,allocatable :: core_correction(:)
  real*8, parameter   :: racut = 2.7d0 ! better to use racut_a(ma)
  real*8, parameter   :: toll_kb = 1d-6  ! if <p|delta_v|p> < toll, stop
  real*8, allocatable :: rgn(:,:,:)
  real*8, allocatable :: vl(  :,:,:),sl(:,:)
  real*8, allocatable :: pl(:,:,:)
  real*8, allocatable :: vpl(:,:,:)
  real*8, allocatable :: rr(:,:)
  real*8, allocatable :: dr(:,:)
  real*8, allocatable :: vloc(:,:)
  real*8, allocatable :: v_kb_nrmlz(:,:)
  real*8, allocatable :: vv_kb(     :,:)
  real*8, allocatable :: v_kb_phi(:,:,:)  ! not used now.
  real*8, allocatable :: vkbp1(:,:)       ! replaces v_kb_phi, recalculated each time.
  real*8, allocatable :: rho_core_a(:,:)
  integer             :: nrlin(n118)
  real*8, allocatable :: rrlin(:,:)   ! for Ni, Au and other kb_many
  real*8, allocatable :: vphi(:,:,:,:)  ! for Ni, Au and other kb_many
  real*8, allocatable :: vkbp1_many(:,:,:)  ! replaces v_kb_phi, extended, recalculated each time.
  real*8, allocatable :: vnl_evl(   :,:,:)  
  complex*16, allocatable  :: cterm_nrmlz(:,:) ! assigned elsewhere
  
contains
  subroutine kb_alloc
    implicit none
    allocate(sl(nrmax,matop), &      ! dont remove-- corrected from sl(nrmax,na) -- check
             nr(  matop), &
             ngs(na), &
             vl(  nrmax,0:lmax,  matop), &
             pl(nrmax,0:lmax,    matop), &
             vpl(nrmax,0:lmax,   matop), &
             rr(nrmax,           matop), &
             dr(nrmax,           matop), &
             vloc(nrmax,         matop), &
             v_kb_nrmlz( 0:lmax, matop), &
             vv_kb(      0:lmax, matop), &
             cterm_nrmlz(0:lmax, matop), &
             lmax_at(            matop), &
             lloc_at(            matop), &
             ltop_nl(            matop), &
             core_correction(    matop), &
             rho_core_a(nrmax,   matop), &
             stat=st )
    if(st/=0) stop ' kb_allocate problems '
  end subroutine kb_alloc

  subroutine kb_read
    implicit none
    integer   ma,ip,l,mr,ir,jr, ch
    real*8  term, pi, ds
    pi = dacos(-1.d0)
 
    atomtypeloop : do ma=1,matop
       ch = mapat(ma)
       call read_kb_terms(ch, ma, lmax_at(ma), lloc_at(ma))

       if(lloc_at(ma)==lmax_at(ma)) then
          ltop_nl(ma) = lmax_at(ma)-1
       else
          ltop_nl(ma) = lmax_at(ma)
       endif

       select case(kbflg(ch))
       case(1)
          call prep_kb_usual_nl(ch, ma)
          call plot_vkb(        ch, ma)
       case(2)
          stop ' not ready for kbflg==2 '
       end select

    enddo atomtypeloop
  end subroutine kb_read

  subroutine read_kb_terms(ch, ma, lmax_a, lloc_a)
    implicit none
    integer ch, ma, ip, l, mr, ir, jr, lmax_a, lloc_a, lmax_a_orig
    real*8  ds, termp2, termv, r, pi, termcore
    logical core_c

    pi = dacos(-1d0)
    ip = ch +5000
    read(ip,*) lmax_a, lloc_a, core_c
!    call check_lelele(2,lloc_a,lmax_a,3,' 2 lloc_a,lmax_a,3 ')
!    call check_lelele(2,lloc_a,lmax   ,3,' 2 lloc_a,lmax,  3 ')

    call check_lelele(-1,lloc_a,lmax_a,3,' 0 lloc_a,lmax_a,3 ')
    call check_lelele(-1,lloc_a,lmax   ,3,' 0 lloc_a,lmax,  3 ')

    write(6,*)' lmax_a, lloc_a, core_correction ',lmax_a, lloc_a, core_c
    lmax_a_orig=lmax_a
    if(lmax_a>lmax) then
       write(6,*)' reducing lmax_a to lmax, i.e.,',lmax_a,' to ',lmax
       lmax_a = lmax
    endif
    core_correction(ma) = core_c

    pl(:,:,ma) = 0d0
    vl(:,:,ma) = 0d0
    
    lloop : do l=0,lmax_a_orig
       read(ip,*)mr
       
       if(l==0) then
          call check_le(mr,nrmax,' mnmxr   ')
          nr(ma) = mr
       else
          call check(mr,nr(ma),' mnr     ')
       end if
       
       do ir=1,nr(ma)
          read(ip, *)jr, r, termp2, termv
          call check(jr,ir,' irjr2 ')

          if(l>0) call check_r(r, rr(ir,ma),' term rr  ')
          rr(ir,ma)=r
          sl(ir,ma) = log(rr(ir,ma))

          if(l==lloc_a) vloc(ir,ma) = termv

          if(kbflg(ch)==1) then
             if(l.le.lmax_a_orig) then
                pl(ir,l,ma) = termp2/r
                vl(ir,l,ma) = termv
             endif
          else 
             stop ' stopping kbflg(ch) /= 1 '
          endif
       enddo
    enddo lloop
    ds = sl(2,ma)-sl(1,ma); 
    call check_r_le(maxval(abs(sl(2:mr,ma)-sl(1:mr-1,ma)-ds)),1.d-8,' maxvval sl ')
    dr(1:mr,ma) = ds* rr(1:mr,ma)  ! logarithmic grid

    if(core_correction(ma)) then
       read(ip,*)mr
       call check(mr,nr(ma),' mnr     ')
       
       do ir=1,nr(ma)
          read(ip, *)jr, r, termcore
          call check(ir,jr,' ir jr   ')
          call check_r(r, rr(ir,ma),' term rr  ')
          rho_core_a(ir,ma)= termcore/(4d0*pi)
       enddo
       write(6,*)' ma,integral(4*pi*r**2*dr*rhocore)',ma,&
            sum(rr(1:nr(ma),ma)**3*ds*4d0*pi*rho_core_a(1:nr(ma),ma))
    endif

  end subroutine read_kb_terms

  subroutine prep_kb_usual_nl(ch,ma)
    implicit none
    real*8, parameter :: toll_vl = 1d-5
    integer ch, ma
    integer l, mr, ir
    real*8  term, ds

    mr = nr(ma)

    lloop2 : do l=0,ltop_nl(ma)
       l_ne_lloc : if(l/=lloc_at(ma)) then
          vl( 1:mr,l,ma)   =  vl(1:mr,l,ma)-vloc(1:mr,ma)       
          vpl(1:mr,l,ma)   =  vl(1:mr,l,ma)*pl(1:mr,l,ma)

          v_kb_nrmlz(l,ma) =   &
        sum( pl(1:mr,l,ma)*rr(1:mr,ma)**2*dr(1:mr,ma)* vpl(1:mr,l,ma)) ! no 4 pi -- y0 integ.

          vv_kb(l,ma)      =   &
        sum( pl(1:mr,l,ma)*rr(1:mr,ma)**2*dr(1:mr,ma)*vpl(1:mr,l,ma)*vl(1:mr,l,ma))  &
          /v_kb_nrmlz(l,ma)

          rnk0 : if(rnk==0) then
             write(6,*)' l, atom,   v_kb_nrmlz,      1/v_kb_nrmlz ',&
                  l,mapat(ma),v_kb_nrmlz(l,ma),1d0/v_kb_nrmlz(l,ma)
             
             write(6,*)' l, atom, <pl|pl> ',&
               l,mapat(ma),sum(pl(1:mr,l,ma)**2*rr(1:mr,ma)**2*dr(1:mr,ma))
          
             if(abs(v_kb_nrmlz(l,ma))<toll_kb) then
                write(6,*)' ERROR: problem with pseudopotential. '
                write(6,*)' <p_l|v_l-v_loc|p_l> is too small, for '
                write(6,*)' atom_type=ma=',ma,' l= ',l,' while tollerance=',toll_kb,' ; stopping '
                stop
             endif

             do ir=1,mr
                if(rr(ir,ma)>racut.and.abs(vl(ir,l,ma))>toll_vl) then
                   write(6,*)' problem, rr= ',rr(ir,ma),', so above racut=',racut 
                   write(6,*)'  but ma,l,vl=     ',ma,l,vl(ir,l,ma),' i.e., v-vloc /= 0 '
                   write(6,*)' so Error, and stopping '
                   stop
                endif
             enddo

          endif rnk0
          
       else
          vl( 1:mr,l,ma)   =  0d0
          vpl(1:mr,l,ma)   =  0d0
          v_kb_nrmlz(l,ma)=0d0
          vv_kb(l,ma)=0d0
       end if l_ne_lloc
    enddo lloop2
    call flush(6)

  end subroutine prep_kb_usual_nl

  subroutine plot_vkb(ch,ma)
    implicit none
    integer ir
    integer  ch,ma
    if(rnk/=0) return
    if(matop>1) then
       if(ma==1) then
          write(6,*)' mr ',nr(1)
          write(6,*)' atomindex(if using kb), charge, v_kb_nrmlz(0:ltop_nl), vv_kb(0:ltop_nl)  '
       endif

       if(kbflg(ch)==1) then
          write(6,*)ma, ch, real(v_kb_nrmlz(0:ltop_nl(ma),ma)), real(vv_kb(0:ltop_nl(ma),ma))
       endif
    end if
  end subroutine plot_vkb
  
end module kb_mod


