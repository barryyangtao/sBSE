subroutine pp_d_bcast
  use mpi_lib_ours, only : bcast_i
  use mpi_lib_ours, only : bcast_r8
  use mpi_lib_ours, only : bcast_L
  use mpi_lib_ours, only : bcast_scalar_i
  use nl, only: nrppmx
  use nl, only: nrpp
  use nl, only: racut_a
  use nl, only: rrpp
  use nl, only: lpploc
  use nl, only: lpptop
  use nl, only: vpploc
  use nl, only: rho_core_a
  use nl, only: core_correction
  use nl, only: nproj
  use nl, only: lpp
  use nl, only: phipp
  use nl, only: dij_diag
  implicit none
  call bcast_scalar_i(nrppmx)
  call bcast_i(  nrpp,    size(nrpp),   0)
  call bcast_i(  nproj,   size(nproj),  0)
  call bcast_i(  lpp,     size(lpp)  ,  0)
  call bcast_i(  lpploc,  size(lpploc), 0)
  call bcast_i(  lpptop,  size(lpptop), 0)
  call bcast_r8( rrpp,    size(rrpp),   0)
  call bcast_r8( vpploc,  size(vpploc), 0)
  call bcast_r8( racut_a, size(racut_a),0)
  call bcast_r8( phipp,   size(phipp),  0)
  call bcast_r8( dij_diag,size(dij_diag),0)
  call bcast_r8( rho_core_a, size(rho_core_a),0)
  call bcast_L(  core_correction, size(core_correction),0)

end subroutine pp_d_bcast
