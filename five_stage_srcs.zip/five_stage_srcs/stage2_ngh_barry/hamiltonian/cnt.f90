subroutine prep_cnt
  use atoms, only : na, cnt, cnt_old, ch, zch, rnel, rnel_orig, zch_ch, rnel_neutral, n118
  use main_param,  only : dx, dy, dz, nx, ny, nz
  use simple_mpi, only : rank
  implicit none
  call set_flg_pp
  call read_cnt
  call check_flg_pp
  call map_cnt  
  call map_kb_extended
contains
  subroutine read_cnt
    use main_param, only : chrg
    implicit none
    real*8 x,y,z, zcha,rem
    integer i, j, cha
    character*2 ccha
    
    i=0; 
    if(rank==0) then; 
       write(6,*)' reading  cnt.ini ; format : ch, x, y, z '; call flush(6); 
    endif
    open(44,file='cnt.ini',status='old')
    
    i=0
    do 
       read(44,*,end=11) ccha
       i= i+1
    enddo
11  rewind(44)

    na = i; if(rank==0)write(6,*)' na assigned to be = ',na
    if(na==0) stop ' na is zero ... '
    allocate(cnt(3,na),cnt_old(3,na),ch(na),zch(na),zch_ch(n118),stat=i); if(i/=0)stop ' cnt '

    i=0
    do 
       read(44,*,end=99) ccha,x,y,z
       i=i+1
       cnt(:,i) = (/x,y,z/) 
       !cnt(:,i) = cnt(:,i) -0.5d0*(/ dx*nx,dy*ny,dz*nz /) ! removed
       call label_to_atom_and_charge(ccha, cha, zcha)
       
       ch(i)       = cha
       zch(i)      = zcha
       zch_ch(cha) = zcha
    enddo
    
99  continue
    
    rnel      = sum(zch) + (-chrg)  ! 
    rnel_orig = rnel
    rnel_neutral = sum(zch)

    if(rank==0)write(6,*)' rnel=',real(rnel),' as: sum(zch) ',sum(zch),' -net charge ',real(-chrg)

  end subroutine read_cnt
  
  subroutine set_flg_pp
    use atoms, only : kbflg
    implicit none
    kbflg       = 0
    kbflg(1:18) = 1 ! overriden below for many atoms

    kbflg(1)    = 1 ! not needed
    kbflg(6)    = 1
    kbflg(8)    = 1

!    kbflg(28)   = 2
!    kbflg(52)   = 2
!    kbflg(74)   = 2
!    kbflg(79)   = 2 
    kbflg(:) = 1 ! changed, 10/22/2018, DN
   
  end subroutine set_flg_pp

  subroutine check_flg_pp
    use atoms, only : kbflg
    implicit none
    if(any(kbflg(ch(:)) == 0))stop ' problem : no kbflg for at least one charge used '
  end subroutine check_flg_pp

  subroutine map_cnt
    use atoms, only : na, matop, ch =>ch, mapat,mapai
    use atoms, only : kbflg
    use mpi_lib_ours, only : rank
    implicit none
    integer, parameter :: nPT = 109
    integer            :: used_atom(1:nPT)
    integer            :: ma, cha, ia,i,rep
    
    allocate(mapai(na),stat=i); if(i/=0)stop ' mapai '

    used_atom = 0
    do ia=1,na
       used_atom(ch(ia))= 1
    end do
    
    do rep=1,2
       ma = 0
       do cha=1,nPT
          if(used_atom(cha)==1) then
             ma = ma+1
             if(rep==2) mapat(ma) = cha
          endif
       enddo
       matop = ma
       if(rep==1) allocate(mapat(matop),stat=i); if(i/=0) stop ' mapat '
    end do

   do ia=1,na
      do ma=1,matop
         if(ch(ia)==mapat(ma)) mapai(ia) = ma
      end do
   end do
   
   if(rank==0) then
      write(6,*)' matop ',matop
      write(9000,*)' mapai ',mapai(1:na); call flush(9000)
      do ma=1,matop
         if(any(mapai==ma)) then
            write(6,*)' number atoms of type, ',ma,' and charge ',mapat(ma), ' is ',count(mapai==ma)
         endif
      enddo
      call flush(6)
   end if
   
 end subroutine map_cnt

 subroutine map_kb_extended
   use atoms, only : na, matop, ch =>ch, mapat
   use atoms, only : kbflg, iap_list
   implicit none
   integer            :: ma, cha, iap
   iap_list(:) = 0
   iap = 0
   do ma=1,matop
      cha = mapat(ma)
      if(kbflg(cha)==2) then
         iap = iap+1
         iap_list(ma) = iap
         write(6,*)' th ',iap,'-th type of atom with kb_extended, has nuclear-charge ',cha
      end if
   end do
 end subroutine map_kb_extended
end subroutine prep_cnt


     
