module vloc_modu
  implicit none
  save
  real*8 :: vloc_c
  real*8, allocatable ::  vloc_tot(:), rho_core(:)
end module vloc_modu
