subroutine pp_make
  implicit none
  logical, save :: first=.true.

  if(.not.first) return
  first=.false.
  call pp_d_prep
  call make_map_pp_grd
  call vloc_tuma_prep
  call make_rho_core
end subroutine pp_make

