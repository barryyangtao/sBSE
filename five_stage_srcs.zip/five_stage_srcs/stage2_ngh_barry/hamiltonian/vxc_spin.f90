subroutine vxc_spin_core_corrected(dens_sp, vxc, n, nspin)
  use vloc_modu,  only : rho_core
  use main_param, only : dv, functional
  use simple_mpi, only : rank
  implicit none
  integer n, nspin, is, st
  integer, save :: i1=1
  real*8 dens_sp(n, nspin), vxc(n,nspin)
  real*8, allocatable :: densa(:,:)

  if(i1==1)then
     i1=-1
     if(rank==0) write(6,*)' integral abs rho_core ',sum(abs(rho_core))*dv
  end if

  allocate(   densa(n, nspin), stat=st)
  call check0(st,' densa vxca')
  do is=1,nspin
     densa(:,is) = dens_sp(:,is) + rho_core/dble(nspin)  
  enddo
  !if(nspin==1 )write(900,*) densa(:,1)  !REMOVE LATER
  !if(nspin==2 )then 
  !  read(900,*) densa(:,1)  !REMOVE LATER
  !  densa(:,1) = 0.5d0*densa(:,1)
  !  densa(:,2) = densa(:,1)
  !endif
  select case(functional)
  case('lda')
    call vxc_spin_pwlda(densa, vxc, n, nspin) 
  case('pbe')
    call vxc_spin_pbe(densa, vxc, n, nspin) 
  case default
    write(6,*)' ERROR, stopping, functional should be lda or pbe, not  ',functional
    stop
  end select
  !if(maxval(rho_core)>1d-12) then
  !   do is=1,nspin
  !      densa(:,is) = rho_core/dble(nspin)
  !   enddo
  !   call vxc_spin(densa, vxca, n, nspin)
  !    vxc = vxc - vxca ! -- corrected -- DN 
  !endif
  deallocate(densa)
end subroutine vxc_spin_core_corrected

subroutine vxc_spin_pwlda(dens_sp, vxc, n, nspin)
  use main_param, only : gm=>gam_bnl, dv, ampbare, ampw
  implicit none
  integer n, nspin, st
  real*8 dens_sp(n, nspin), vxc(n, nspin)
  real*8, allocatable :: va(:,:), dens2(:,:), exc(:) ! x or c

  allocate( va(nspin,n), dens2(nspin,n), exc(n), stat=st);   call check0(st, ' vx vcn ')
  dens2 = transpose(dens_sp)
  if(gm>1d-8) then
    call get_vx_gamma_spin_epsilon_lda(dens2, n, nspin, va, gm, ampbare, ampw)
  else
    call lda_libxc_x(dens2, n, nspin, va, exc) 
  endif
  vxc = transpose(va)
  call lda_libxc_c(dens2, n, nspin, va, exc) 
  vxc = vxc + transpose(va) 
  deallocate(va, dens2, exc)
end subroutine vxc_spin_pwlda

subroutine vxc_spin_pbe(dens_sp, vxc, n, nspin)
  use main_param, only : gm=>gam_bnl, dv, ampbare, ampw
  use neargap,      only : nx, ny, nz, dx, dy, dz
  implicit none
  integer n, nspin, st, nsig
  real*8 dens_sp(n, nspin), vxc(n, nspin)
  real*8, allocatable :: va(:,:), dens2(:,:), sigma(:,:), exc(:), dens_mix(:) ! x or c
  real*8,  parameter  :: toll_sigma = 1d-11
  
  allocate( va(nspin,n), dens2(nspin,n), exc(n), dens_mix(n), stat=st);   call check0(st, ' vx vcn ')
  call prep_sigma
  dens2 = transpose(dens_sp)
  if(gm>1d-8) then
    call get_vx_gamma_spin_epsilon_pbe(dens2, sigma, n, nsig, nspin, va, gm, ampbare, ampw)
  else
    call pbe_libxc_x(dens2, sigma, n, nsig, nspin, va, exc) 
  endif
  vxc = transpose(va)
  call pbe_libxc_c(dens2, sigma, n, nsig, nspin, va, exc) 
  vxc = vxc + transpose(va)
  deallocate(va, dens2, exc, dens_mix)
  
contains
  subroutine prep_sigma
    implicit none
    if(nspin==1) then
       nsig = 1
       allocate(sigma(1,n),stat=st); if(st/=0) stop 'sigma pbe nspin=1'
       call grad(nx, dx, ny, dy, nz, dz, dens_sp, exc)
       sigma(1,:) = exc
       if(any(sigma/=sigma)) stop "NAN IN GRADS!"
       where(abs(sigma).lt.toll_sigma) sigma=0.d0 ! DN, abs needed
       sigma = sigma**2.d0 ! dont erase: maybe need to have 0.25
    else if(nspin==2) then
       nsig = 3
       allocate(sigma(3,n),stat=st); if(st/=0) stop 'sigma pbe nspin=2'
       dens_mix = dens_sp(:,1)*dens_sp(:,1)
       call grad(nx, dx, ny, dy, nz, dz, dens_mix, exc); sigma(1,:) = exc
       dens_mix = dens_sp(:,1)*dens_sp(:,2)            
       call grad(nx, dx, ny, dy, nz, dz, dens_mix, exc); sigma(2,:) = exc
       dens_mix = dens_sp(:,2)*dens_sp(:,2)           
       call grad(nx, dx, ny, dy, nz, dz, dens_mix, exc); sigma(3,:) = exc
    endif
  end subroutine prep_sigma
end subroutine vxc_spin_pbe
