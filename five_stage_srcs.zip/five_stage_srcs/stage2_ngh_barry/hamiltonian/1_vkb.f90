module vkb_modu
  use main_param, only : vk, vkb
  implicit none
  save
end module vkb_modu

