subroutine hsub_prep
  use h0_modu, only : called_hsub_prep
  implicit none
  called_hsub_prep=.true.
  call time_print(' starting ')
  call make_atoms_list
  call prep_cnt
  call pp_make
  !call make_dens0
  call prep_ek
end subroutine hsub_prep





  
