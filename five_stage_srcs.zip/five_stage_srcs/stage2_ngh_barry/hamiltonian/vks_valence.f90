subroutine make_vks_valence_noxc
  use main_param, only : n
  use h0_modu, only : vksvalence_noxc, dens, dens0core
  implicit none
  integer st
  if(.not.allocated(vksvalence_noxc)) then
     allocate(vksvalence_noxc(n), stat=st)
     call check0(st,' vksvalence ')
  else
     call check(size(vksvalence_noxc),n,' szvksvalence ')
  endif
  call vks_sub_valence_noxc(dens,dens0core,vksvalence_noxc,n)  

end subroutine make_vks_valence_noxc

subroutine vks_sub_valence(dens,denscore,vks,n)
  use vloc_modu, only : vloc_tot
  implicit none
  integer, parameter :: nspin_loc=1
  logical, save      :: first=.true.
  integer n,i,st
  real*8 dens(n), denscore(n), vks(n)
  real*8, allocatable :: vxc(:)

  vks=0 
  call dens_to_vh(dens,vks)
  vks = vks + vloc_tot
 
  allocate(vxc(n), stat=st); if(st/=0) stop ' vxc '
  call vxc_spin_core_corrected(dens,vxc,n,nspin_loc)
  vks = vks + vxc

  call time_print(' post vks_sub ')
end subroutine vks_sub_valence

subroutine vks_sub_valence_noxc(dens,denscore,vks_noxc,n)
  use vloc_modu, only : vloc_tot
  implicit none
  integer, parameter :: nspin_loc=1
  logical, save      :: first=.true.
  integer n,i,st
  real*8 dens(n), denscore(n), vks_noxc(n)
  real*8, allocatable :: vxc(:)

  vks_noxc=0 
  call dens_to_vh(dens,vks_noxc)
  vks_noxc = vks_noxc + vloc_tot
 
!  allocate(vxc(n), stat=st); if(st/=0) stop ' vxc '
!  call vxc_spin_core_corrected(dens,vxc,n,nspin_loc)
!  vks = vks + vxc

  call time_print(' post vks_noxc_sub ')
end subroutine vks_sub_valence_noxc
