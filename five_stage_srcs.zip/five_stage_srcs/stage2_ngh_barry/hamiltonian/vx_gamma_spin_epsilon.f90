subroutine  get_vx_gamma_spin_epsilon_lda(dens_sp, n, nspin, vx, gm, ampbare, ampw)
  implicit none
  integer n, nspin, st
  real*8 dens_sp(nspin,n), vx(nspin,n), gm, ampbare, ampw
  real*8, allocatable, dimension(:,:) :: vg0 ! vx_short(gamma=0)
  real*8, allocatable, dimension(:)   :: ex 

  allocate(vg0(nspin,n), ex(n), stat=st)
  call check0(st,' vg0 ')

  call lda_sr_libxc_x(dens_sp, n, nspin, vx, ex,gm) 
  call lda_libxc_x(dens_sp, n, nspin, vg0, ex)       !gamma=0

  vx = vg0*(1-ampbare-ampw)+ampw*vx
end subroutine get_vx_gamma_spin_epsilon_lda

subroutine  get_vx_gamma_spin_epsilon_pbe(dens_sp, sigma, n, nsig, nspin, vx, gm, ampbare, ampw)
  implicit none
  integer n, nspin, st, nsig
  real*8 dens_sp(nspin,n), vx(nspin,n), sigma(nsig,n), gm, ampbare, ampw
  real*8, allocatable, dimension(:,:) :: vg0 ! vx_short(gamma=0)
  real*8, allocatable, dimension(:)   :: ex ! work array

  allocate(vg0(nspin,n), ex(n), stat=st)
  call check0(st,' vg0 ')

  call pbe_sr_libxc_x(dens_sp, sigma, n, nsig, nspin, vx, ex,gm) 
  call pbe_libxc_x(dens_sp, sigma, n, nsig, nspin, vg0, ex)  ! gamma=0

  vx = vg0*(1-ampbare-ampw)+ampw*vx
end subroutine get_vx_gamma_spin_epsilon_pbe
