subroutine elname(ccha_inp,ic)
  use atoms, only : an => atom_name, un=> atom_upper_name
  implicit none
  character(2) :: ccha, ccha_inp
  integer      :: ic
  integer      :: j
  logical      :: found
  
  ccha(1:2)  = ccha_inp(1:2)
  if( ccha=='  ') stop ' ERROR: element with empty name '

  !
  ! convert ' H'  to 'H ' -- not needed, but keep
  !
  if (ccha(1:1)==' ') then
     ccha(1:1) = ccha(2:2)
     ccha(2:2) = ' '
  end if

  found = .false.
  ic = -99
  atom_type : do j=1,size(an)
     if(ccha==an(j).or.ccha==un(j)) then
        if(found)stop ' read-atom is fit to more than 1 atom-types '
        found=.true.
        ic = j
     endif
  end do atom_type
  if(.not.found) then
     write(6,*)' Error: atom from name in PP, ',ccha,', does not fit any element '
     stop
  end if
  if(ic<1) stop ' Error: didnt find atom ' ! superflous, but always check.
end subroutine elname


