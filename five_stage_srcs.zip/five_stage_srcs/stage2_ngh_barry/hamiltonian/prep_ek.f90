subroutine prep_ek
  use main_param, only : nx, ny, nz, dx, dy, dz,  ekcut
  use h0_modu, only : ek
  implicit none
  real*8 pi, dk(3), kv(3)
  integer ix, iy, iz, st, i

  pi=dacos(-1d0)
  
  if(allocated(ek)) stop ' problem ek allocated '
  allocate(ek(nx*ny*nz), stat=st);  if(st/=0) stop ' problem ek '
  
  dk = 2d0*pi / dble( (/ nx*dx, ny*dy, nz*dz /) )
  
  i=0
  do iz=1, nz
     do iy=1, ny
        do ix=1, nx
           kv =  (/ (ix-1)*dk(1), (iy-1)*dk(2), (iz-1)*dk(3) /)
           if(kv(1)>pi/dx) kv(1) = kv(1) - 2d0*pi/dx
           if(kv(2)>pi/dy) kv(2) = kv(2) - 2d0*pi/dy
           if(kv(3)>pi/dz) kv(3) = kv(3) - 2d0*pi/dz
           i=i+1
           ek(i) = min(sum(kv**2)/2d0, ekcut)
        enddo
     enddo
  enddo
  

end subroutine prep_ek
