subroutine pp_d_allocate
  use atoms, only : na
  use nl,  only : nproj_max
  use nl, only : nrpp, nrppmx, ngs
  use nl, only : lpploc, lpptop, lpp, lmx
  use nl, only : rrpp, vpploc, racut_a  
  use nl, only : phipp, nproj
  use nl, only : rho_core_a, core_correction
  use nl, only : matop
  use nl, only : dij_diag
  implicit none
  integer st
  call check_lele(50,nrppmx,10000, '50-nrppmx-1e4 ')
  
  allocate( ngs(                             na), stat=st); call check0(st,' ngs        ')
  allocate( core_correction(              matop), stat=st); call check0(st,' core_correction ')
  allocate( lpploc(                       matop), stat=st); call check0(st,' lpploc     ')
  allocate( lpptop(                       matop), stat=st); call check0(st,' lpploc     ')
  allocate( nrpp(                         matop), stat=st); call check0(st,' nrpp       ')
  allocate( racut_a(                      matop), stat=st); call check0(st,' racut_a    ')
  allocate( rrpp(      nrppmx,            matop), stat=st); call check0(st,' rrpp       ')
  allocate( rho_core_a(nrppmx,            matop), stat=st); call check0(st,' rho_core_a ')
  allocate( vpploc(    nrppmx,            matop), stat=st); call check0(st,' vpploc     ')
  allocate( lpp(               nproj_max, matop), stat=st); call check0(st,' lpp        ')
  allocate( nproj(                        matop), stat=st); call check0(st,' nproj      ')
  allocate( phipp(     nrppmx, nproj_max, matop), stat=st); call check0(st,' phipp      ')
  allocate( dij_diag(          nproj_max, matop), stat=st); call check0(st,' dij_diag   ')
  nrpp = 0 ! to be checked later that nrpp>0, i.e., all entries were read.
  core_correction = .false.
end subroutine pp_d_allocate
