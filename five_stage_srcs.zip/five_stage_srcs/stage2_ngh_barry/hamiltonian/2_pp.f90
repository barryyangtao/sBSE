module nl
  use atoms,  only : matop, mapat
  use kb_mod, only : nlm, lloc_at
  use kb_mod, only : map_kb_grid, rgn
  use kb_mod, only : ngs, ngsmall
  use kb_mod, only : nrppmx => nrmax
  use kb_mod, only : nrpp => nr
  use kb_mod, only : rrpp => rr
  use kb_mod, only : lpploc => lloc_at
  use kb_mod, only : lpptop => lmax_at
  use kb_mod, only : vpploc => vloc
  use kb_mod, only : rho_core_a
  use kb_mod, only : core_correction
  use kb_mod, only : lmx =>lmax
  implicit none
  save
  integer, parameter :: nproj_max = 12
  integer :: nsuper_nl
  integer, allocatable :: nproj(:)
  integer, allocatable :: lpp(:,:)
  integer, allocatable :: i_indx_nl(:)
  integer, allocatable :: l_indx_nl(:)
  integer, allocatable :: m_indx_nl(:)
  real*8               :: aa
  real*8,  allocatable :: racut_a(:)
  real*8,  allocatable :: phipp( :,:,:)
  real*8,  allocatable :: dij_diag(:,:)
  real*8,  allocatable :: pkb_many(:,:)
end module nl
