subroutine print_core_x_correction
  use neargap
  use simple_mpi, only : rank
  implicit none
  integer i
  if(rank==0) then
     write(6,*)' core exchange correction by state in eV '
     do i=ixlow,ixhigh
        write(6,*)iscf,i,real(dxcore(i,i,:)*Hartree_to_eV),' iscf, i(m.o.), core_x_eV(i,i,1:nsp) '
     enddo
  end if
end subroutine print_core_x_correction
