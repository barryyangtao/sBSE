subroutine read_param
  use neargap
  use neargap, only : icorec    =>icore_correct   ! NEW 7/5/2023
  use neargap, only : acoverage=>alpha_coverage
  use neargap, only : actionij =>action_rhoij
  use simple_mpi, only : nodes, rank, bcast_r8, bcast_i, sync_mpi
  implicit none
  integer st
  real*8 echeby
  call read_main
  call process_param
  call read_functional
contains
  subroutine read_main
    open(7,file='nearg.inp',status='old')
    call fetch_r(ekcut,    'ekcut    ',7)
    call fetch_r(kcut_vw,  'kcut_vw  ',7)
    call fetch_i(nalpha,   'nalpha   ',7)
    call fetch_r(acoverage,'acoverage',7)
    call fetch_r(gamW,     'gammaW   ',7)
    call fetch_r(ampW,     'ampW     ',7)
    call fetch_r(ampbare,  'ampbare  ',7)
    call fetch_L(periodic, 'periodic ',7)
    call fetch_i(nsp,      'nsp      ',7)
    select case(nsp);
    case(1); call fetch_r(charge,   'charge   ',7)
    case(2);
       call fetch_r(chargeU,  'chargeU  ',7)
       call fetch_r(chargeD,  'chargeD  ',7)
       charge = chargeU+chargeD
    case default
       stop ' nsp should be 1 or 2 '
    end select
    
    call fetch_i(nv,       'nv       ',7)
    call fetch_i(nc,       'nc       ',7)
    call fetch_i(icorec,   'icore_c  ',7) ! NEW modified 7/5/2023
    call fetch_i(nstocore, 'nstocore ',7)
    call fetch_i(nxcore,   'nxcore   ',7)
    call fetch_r(tp,       'Tp       ',7)
    call fetch_i(nscf,     'nscf     ',7)
    call fetch_r(mix,      'mix      ',7)
    call fetch_L(printpsi, 'printpsi ',7)
    
    ! dont close 7
    open(60,file='status.inp',status='old')
    call fetch_ch(actionij,'actionij ',60)
    close(60)
  end subroutine read_main
  
  subroutine process_param
    ntot = nv+nc

    if(icorec.le.0.or.nxcore<1) then
       core_correct=.false.
    else
       core_correct=.true.
    endif
    
    !if(nsp==1.and.abs(charge)>1d-8) stop ' use charged systems only with nsp=2 '
    if(charge>6.or.charge<-6) stop ' charge should be -6 to 6 '

    n_valence_tot = -charge + 2* nv  
    call check_le(ceiling(n_valence_tot),2*ntot,' chargetot, 2*ntot ')
  
    beta=1/tp 
    
    if(periodic) then;  scale_vh=1
    else; scale_vh=2
    end if
  
    if(nalpha==0) stop ' need to use alpha compression now '
    
    select case(actionij)
    case('prep','preprun','prepwriterun','read'); continue
    case default; stop ' action_rhoij is wrong '
    end select

    if(nstocore<-1) stop ' nstocore should be -1,0,or>0 '

    ! nxcore is number of neargap states for which we apply core exchange. 
    nxcore = max(nxcore, 0)

    nxcore_c = nxcore/2    ! arbitary valence,conduction division
    nxcore_v = nxcore - nxcore_c
    
    nxcore_v = min(nv, nxcore_v)
    nxcore_c = min(nc, nxcore_c)
    
    if(rank==0) write(6,*)' nxcore_v, nxcore_c (possibly modified) ',nxcore_v, nxcore_c
    
    if(nxcore>0) then
       if(nxcore_v<1.or.nxcore_c<1) stop ' nxcore_v, nxcore_c shouldnt be 0 '
       ixlow  = nv-nxcore_v+1
       ixhigh = nv+nxcore_c
       if(rank==0) write(6,*)' ixlow, ixhigh ',ixlow,ixhigh
       call check(ixhigh-ixlow+1,nxcore,' ixhigh-ixlow+1, nxcore ')
    endif

    if(nv+nc<nodes) then
       if(rank==0) write(6,*)' problem, run with fewer nodes than nv+nc= ',nv+nc
       call sync_mpi
       stop
    endif

    call check_lele(1,nsp,2,' one-nsp-two ')

  end subroutine process_param

  subroutine read_functional
    !use mpi_lib_ours, only : sync_mpi,bcast_char30
    implicit none
    integer i
    character*8 cha
    if(rank==0) write(6,*)' give me functional '
    read(7,*) cha, functional
    if(cha/='func'.and.cha/='"func"') then
       write(6,*)' problem, needs: "func", then functional (lda, pbe), not ',cha,functional
       stop
    endif
    if(rank==0) write(6,*)cha,functional

    select case(functional)
    case('lda','pbe')
       continue
    case default
       write(6,*)' ERROR, stopping : functional isnt lda nor pbe but ',functional
    end select
  end subroutine read_functional
end subroutine read_param
