subroutine set_sign_comb
  use simple_mpi, only  : rank, scatter_i
  use neargap
  implicit none
  integer st,ik
  integer, allocatable :: iarray(:)
  allocate(sign_comb(ncomb), sign_comb1(ncomb1), iarray(nncomb), stat=st)
  call check0(st,' sign_comb ')

  call check(nk_low+na_pos+na_neg,ncomb,' nklow+napos+naneg, ncomb  ')

  do ik=1,nk_low
     if(vwktot_low(ik).ge.0) then
        sign_comb(ik) = 1
     else
        sign_comb(ik) = -1 
     end if
  end do

  sign_comb(nk_low+1:       nk_low+na_pos       ) =  1 ! alphas associated with positive vwk
  sign_comb(nk_low+na_pos+1:nk_low+na_pos+na_neg) = -1 ! alphas associated with negative vwk

  iarray = 0
  iarray(1:ncomb)  = sign_comb
  call scatter_i(iarray, sign_comb1, ncomb1, 0)
  
  !where(sign_comb1<0) sign_comb1=0 ! erase
  
end subroutine set_sign_comb
