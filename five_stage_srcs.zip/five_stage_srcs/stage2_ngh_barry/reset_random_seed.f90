subroutine reset_random_seed ! resets seed to the root one used in first time called.
  use rand88_fast_module, only : seed
  implicit none
  integer, save :: seed_reset(4)
  logical, save :: first=.true.

  if(first) then
     first=.false.
     seed_reset = seed
    ! call bcast_i(seed_reset, size(seed_reset),0)
  end if

  seed = seed_reset
end subroutine reset_random_seed
  
  
