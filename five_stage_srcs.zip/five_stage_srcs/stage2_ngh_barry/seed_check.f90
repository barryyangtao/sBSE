subroutine seed_check
  use rand88_fast_module, only : seed
  use simple_mpi, only : rank, bcast_i
  implicit none
  integer, save :: seed_tmp(4)
  seed_tmp = seed
  call bcast_i(seed_tmp, size(seed_tmp), 0)
  if(any(seed/=seed_tmp)) stop ' error, seed not uniform ;'
end subroutine seed_check
